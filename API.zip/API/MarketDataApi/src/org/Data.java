package org;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

//import com.gargoylesoftware.htmlunit.javascript.host.file.File;
import java.io.File.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

public class Data {

	public static Properties ReadGlobalFileData() {

		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream("./data/globaldatafile.properties");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		Properties prop = new Properties();
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return prop;

	}

}
