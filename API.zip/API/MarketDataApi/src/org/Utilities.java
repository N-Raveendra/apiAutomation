package org;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public final class Utilities {


	public static String trimEnd(String input, String charsToTrim)
	{
		return input.replaceAll("[" + charsToTrim + "]+$", "");		
	}	
	
	public static String trimStart(String input, String charsToTrim)
	{
		return input.replaceAll("^[" + charsToTrim + "]+", "");	
	}

	public static String trim(String input, String charsToTrim)
	{
		return input.replaceAll("^[" + charsToTrim + "]+|[" + charsToTrim + "]+$", "");	
	}
		
	public static String combinePaths(String...paths) {
		String target = "";
		for(String path : paths) {			
			target = String.format("%s/%s", trimEnd(target, "/"), trimStart(path,"/") );
		}
		return trimEnd(target, "/");
		
	}
	
	public static String getFileContents(String filePath) throws IOException {
		Scanner scanner = new Scanner( new File(filePath) );
		String fileContents = scanner.useDelimiter("\\A").next();
		scanner.close();		
		return fileContents;
	}
	
	public static  Properties ReadGlobalFileData ()  {


		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream("./data/globaldatafile.properties");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		Properties prop = new Properties();
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}

	return prop;
		
}

}
