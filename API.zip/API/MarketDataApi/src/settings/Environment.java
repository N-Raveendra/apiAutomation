package settings;

public enum Environment {
	Unknown, localHost, QA, QAProxy, UAT, UATProxy, Prod, ProdProxy, KMSQA
}

