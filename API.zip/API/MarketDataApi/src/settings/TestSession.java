package settings;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.Data;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.testng.annotations.BeforeClass;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

public class TestSession {
	
	DateTimeFormatter isoDateFormatter=ISODateTimeFormat.dateTimeParser().withOffsetParsed();
	
	static final String APPLICATION_JSON = "application/json";
	private static final String APPLICATION_XML = "application/xml";

	static Header acceptJson = new Header("Accept", APPLICATION_JSON);
	static Header acceptXml = new Header("Accept", APPLICATION_XML);

	private String apiSessionToken = null;

	private EnvironmentConfiguration config = null;
	private DateTime sessionExpiry = DateTime.now(DateTimeZone.UTC).minusMinutes(5); //start with expired, force a new token  
	private String sessionClient = null;

	private String lfbasicSchema = "lfBasic-schema.json";
	/*private String ProxyCookieName = "BCSI-AC-0026a082e2bc94a8";
	private String ProxyCookieValue = "25F3639200000005UrYMXgyj6GEhGfBppxqP15RCJDMIAAAABQAAAKABBwCAcAAAAAAAAKQIAAA=";*/
	
	private Map<String, String> cookies = null;

	private volatile static TestSession _sessionInstance = null;
	private TestSession() { };
	/*
	public static TestSession getSession(Environment environment, String version, String clientId) {
		if (null == _sessionInstance) {
			synchronized(TestSession.class) {
				if (null == _sessionInstance) {
					_sessionInstance = new TestSession(environment, version, clientId);
				}
			}
		}
		return _sessionInstance;
	}*/
	
	public static TestSession getSession(TestConfiguration config) {
		if (null == _sessionInstance) {
			synchronized(TestSession.class) {
				if (null == _sessionInstance) {
					_sessionInstance = new TestSession(config);					
				}
			}
		}
		return _sessionInstance;		
		//return getSession(config.environment, config.apiVersion, config.clientID);	
	}
	
	/*
	private TestSession(String testEnvironment , String version, String clientId) {
		//this(Configuration.getEnvironment(environment), version, clientId);
		
		this(new TestConfiguration() 
		{{
			environment = Configuration.getEnvironment(testEnvironment);
			apiVersion = version;
			clientID = clientId;			
		}}
	);	
	}
		
	private TestSession(Environment testEnvironment, String version, String clientId) {
		this(new TestConfiguration() 
			{{
				environment = testEnvironment;
				apiVersion = version;
				clientID = clientId;			
			}}
		);		
		config = new Configuration(testEnvironment, version);		
		sessionClient = clientId;		
		setUp();
	}*/
	
	private TestSession(TestConfiguration testConfig) {
		config = new EnvironmentConfiguration(testConfig.environment, testConfig.apiVersion);		
		sessionClient = testConfig.clientID;
		cookies = testConfig.cookies;
		setUp();
	}
	
	public String getCurrentEnvironment() {
		return config.getCurrentEnvironment().toString();
	}
	
	public String getCurrentUrlBase() {
		return config.getUrlBase();
	}	

	public String getApiKey() {
		return config.getApiKey();
	}

	public String getSessionToken() {
		synchronized (TestSession.class) {
			boolean refreshSession = false;
			if (null == apiSessionToken) {
				//System.out.println(">>>>>apiSessionToken is NULL");
				refreshSession = true;
			}
			else{
				DateTime now = DateTime.now(DateTimeZone.UTC).minusSeconds(3);
				if (sessionExpiry.isBefore(now)) {
					//System.out.println(">>>>>apiSessionToken expired");
					refreshSession = true;				
				}
			}
			
			if (refreshSession) {
				establishSession();
			}
		}
		return apiSessionToken;
	}

	public String getClient() {
		return sessionClient;		
	}

	public void setUp() {

		RestAssured.baseURI = config.getUrlBase();
		RestAssured.basePath = config.apiVersion;
//		RestAssured.Proxy = config.Proxy;
	}

	public RequestSpecification  getBaseRequest(RequestSpecBuilder builder) {
		if (null == builder) {
			builder = new RequestSpecBuilder();
		}
		
		//add any cookies in the default - proxy, autho etc. 
		
		for (Map.Entry<String, String> entry : cookies.entrySet()) {			
			builder.addCookie(entry.getKey(), entry.getValue());
		}
		builder.addHeader("x-bypass-cache", "true");
		builder.setProxy("IN03CBCSG01.org.nasdaqomx.com", 8080);
		return 
				given().relaxedHTTPSValidation()
				.spec(builder.build());
				//.cookie(ProxyCookieName, ProxyCookieValue);
	}
	
	
	public RequestSpecification getAuthorizedRequest() {
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("apiKey", config.getApiKey());
		headers.put("Accept", APPLICATION_JSON);
		
		RequestSpecBuilder rb = new RequestSpecBuilder();
		rb.addHeaders(headers);
		return getBaseRequest (rb);
	}
	
	
	public RequestSpecification getAuthenticatedRequest() {
		return getAuthorizedRequest().header("MktSession", getSessionToken());
	}

	private void establishSession() {
		String basicSchemaLocation = Paths.get(config.getSchemaLocation(), lfbasicSchema).toString();
		String endpoint = String.format("/%s/session", getClient());
		//RestAssured.requestSpecification.proxy("US01CBCSG02.org.nasdaqomx.com", 8080);
		Response response = getAuthorizedRequest().
				when().
				get(endpoint).
				then().
				assertThat().
				statusCode(200).log().ifError()
				.assertThat().body(matchesJsonSchema(new File(basicSchemaLocation)))
				// .and().assertThat().body(matchesJsonSchema(new
				// File(sessionSchemaLocation)))
				.extract().response();

		apiSessionToken = response.path("result.token");
		String expiryValue = response.path("result.expires"); 
		sessionExpiry = isoDateFormatter.parseDateTime(expiryValue);
		
	}
}
