package settings;

public class EnvironmentConfiguration {
	
	private String localHost = "http://127.0.0.1/MarketDataApi/";
	
	private String QA_Origin = "https://irapi.corporate-ir-qa.net/"; 
	private String QA_Proxy = "https://nasdaqir-qa.apigee.net/ir/";
	//private String QA_Origin = "http://xml.corporate-ir-qa.net/";
	//private String QA_Proxy = "https://thomsonreuters-lfqa.apigee.net/ir/";
	
	private String UAT_Origin = "https://irapi.corporate-ir-uat.net/";
	private String UAT_Proxy = "https://nasdaqir-uat.apigee.net/ir/";
	//private String UAT_Proxy = "https://thomsonreuters-lfuat.apigee.net/ir/";
	
	private String Prod_Origin = "https://irapi.corporate-ir.net/";
	private String Prod_Proxy = "https://nasdaqir-prod.apigee.net/ir/";		
	//private String Prod_Internal = "https://irapi.pro.lfmdapi.gcs.nadq.pub/";
	
	private String KMS_QA = "https://irkms.corporate-ir-qa.net/";
	
	private String Local_ApiKey = "PYwbO3MC3rdsAFI1muGorkc6xzsaCRRJ";
	private String QA_ApiKey = "OGYhGufoaQIALzl0fkrqkaXSKj647t07";
	private String UAT_ApiKey = "OGYhGufoaQIALzl0fkrqkaXSKj647t07";	
	private String Prod_ApiKey = "OGYhGufoaQIALzl0fkrqkaXSKj647t07";
	//private String QA_ApiKey = "PYwbO3MC3rdsAFI1muGorkc6xzsaCRRJ";
	//private String UAT_ApiKey = "PYwbO3MC3rdsAFI1muGorkc6xzsaCRRJ";	
		
	
	private Environment currentEnvironment = Environment.Unknown;
	
	String apiVersion; // = "v1";
	
	EnvironmentConfiguration(Environment targetEnvironment, String targetApiVersion) {
		if (targetEnvironment == Environment.Unknown ) {
			throw new UnsupportedOperationException("This Environment is not supported");
		}
		currentEnvironment = targetEnvironment;
		apiVersion = targetApiVersion;
	}	
	
	Environment getCurrentEnvironment() {
		return currentEnvironment;
	}
	
	String getSchemaLocation() 
	{
		return String.format("%s\\%s", System.getProperty("user.dir"), "schemas");
	}
	
	String getApiKey() {
		switch (currentEnvironment) {
		case localHost:
			return Local_ApiKey;
		case QA:
		case QAProxy:
			return QA_ApiKey;
		case UAT:
		case UATProxy:
			return UAT_ApiKey;
		case Prod:
		case ProdProxy:
			return Prod_ApiKey;
		case KMSQA:
			return QA_ApiKey;
		default:
				throw new UnsupportedOperationException("This Environment is not supported");
		}
	}
	
	String getUrlBase() {		
		switch (currentEnvironment) {
		case localHost:
			return localHost;
		case QA:
			return QA_Origin;
		case QAProxy:
			return QA_Proxy;
		case UAT:
			return UAT_Origin;
		case UATProxy:
			return UAT_Proxy;
		case Prod:
			return Prod_Origin;
		case ProdProxy:
			return Prod_Proxy;
		case KMSQA:
			return KMS_QA;
		
		default:
				throw new UnsupportedOperationException("This Environment is not supported");
		}
	}
	
	public static Environment getEnvironment(String envType) {
		switch (envType.toUpperCase()){
		case "LOCALHOST":
			return Environment.localHost;
		case "QA":
			return Environment.QA;
		case "QAPROXY":
			return Environment.QAProxy;
		case "UAT":
			return Environment.UAT;
		case "UATPROXY":
			return Environment.UATProxy;
		case "PROD":
			return Environment.Prod;
		case "PRODPROXY":
			return Environment.ProdProxy;
		case "KMSQAOrigin":
			return Environment.KMSQA;
		default:
			throw new UnsupportedOperationException("This Environment is not supported");
		}
	}
}
