package settings;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TestConfiguration {
	
	@JsonFormat(shape= JsonFormat.Shape.STRING)
    public Environment environment;
	
    public String clientID;
    public String apiVersion;
    public Map<String, String> cookies = new HashMap<String, String>();
   
}



