package main;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Map;

import org.Utilities;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

import settings.Environment;

public class HelloMktApi {

	static final String APPLICATION_JSON = "application/json";
	private static final String APPLICATION_XML = "application/xml";

	static Header acceptJson = new Header("Accept", APPLICATION_JSON);
	static Header acceptXml = new Header("Accept", APPLICATION_XML);

	static String apikey = "PYwbO3MC3rdsAFI1muGorkc6xzsaCRRJ";
	// private String sesssionToken= "";
	private static String schemaLocation = String.format("%s\\%s", System.getProperty("user.dir"), "schemas");

	public static void main(String args[]) throws JsonParseException, JsonMappingException, IOException {
		
		/*ObjectMapper mapper = new ObjectMapper();
		
		TestConfiguration config = new TestConfiguration();
		config.apiVersion= "v1";
		config.clientID = "104414";
		config.environment = Environment.QA;
		config.cookies.put("one",  "1");
		config.cookies.put("two",  "2");
		
		String jsonInString = mapper.writeValueAsString(config);
		System.out.println(jsonInString);
		//Object to JSON in file		
		TestConfiguration configR = mapper.readValue(jsonInString, TestConfiguration.class);
		
		for (Map.Entry<String, String> entry : configR.cookies.entrySet()) {			
			System.out.println(String.format("%s : %s",entry.getKey(), entry.getValue()));
		}
		
		TestConfiguration config1 = mapper.readValue(new File("C:\\Dev\\TFS_IR_WebHosting\\QA\\Scripts-Automation\\Leapfrog\\SandBox\\MarketDataApi\\src\\main\\config.json"), TestConfiguration.class);
		System.out.println(mapper.writeValueAsString(config1));
		*/
		
		
		
		RestAssured.baseURI = "http://xml.corporate-ir-qa.net/v1/";
		try {
			DateTime sessionExpiry = DateTime.now(DateTimeZone.UTC).plusSeconds(5);
			boolean isExpired = sessionExpiry.isBefore(DateTime.now(DateTimeZone.UTC).minusSeconds(6));			
			System.out.println(sessionExpiry);
			System.out.println(isExpired);
			
			isExpired = sessionExpiry.isAfter(DateTime.now(DateTimeZone.UTC).plusSeconds(3));
			System.out.println(isExpired);
			
			HelloMktApi cls = new HelloMktApi();
			String token = cls.GetSession();
			//cls.TestQuotes(token);
			cls.testPost(token);
		} catch (Exception ex) {
			ex.printStackTrace();
		}		
		
	}

	public void setUp() throws Exception {

		RestAssured.baseURI = "http://xml.corporate-ir-qa.net/";
		RestAssured.basePath = "/v1/";
	}

	public RequestSpecification baseRequest() {
		return given()
				.relaxedHTTPSValidation()
				.header(acceptJson)
				.header("apiKey", apikey)
				.contentType(ContentType.JSON)
				.cookie("BCSI-AC-0026a082e2bc94a8",
						"2575CDBA000000056u+nlHyWA45Hv6Jq3x/R/4Giv0aAAAAABQAAAPB5dwCAcAAABQAAAPqAAAA=");

	}

	public String GetSession() {
		
		String basicSchemaLocation = Paths.get(schemaLocation, "lfBasic-schema.json").toString();
		String sessionSchemaLocation = Paths.get(schemaLocation, "session-schema.json").toString();
		System.out.println(sessionSchemaLocation);

		Response response = baseRequest()
				.when()
					.get("/565711/session")
				.then()
					.assertThat().statusCode(200)
					.and().assertThat().body(matchesJsonSchema(new File(basicSchemaLocation)))
					.and().assertThat().body(matchesJsonSchema(new File(sessionSchemaLocation)))
				.extract()
					.response();

		System.out.println(response.prettyPrint());
		System.out.println(response.getStatusCode());
		String token = response.path("result.token");
		System.out.println(token);
		return token;

	}

	public void TestQuotes(String sessionToken) {
		String basicSchemaLocation = Paths.get(schemaLocation, "lfBasic-schema.json").toString();
		//String quotesSchemaLocation = Paths.get(schemaLocation, "quotes-schema.json").toString();
		
		ResponseSpecBuilder rsb = new ResponseSpecBuilder();
		rsb.expectBody(matchesJsonSchema(new File(basicSchemaLocation)))
			//.expectBody(matchesJsonSchema(new File (quotesSchemaLocation)))
			;
		
		Response response = baseRequest().
				given()
					.header("MktSession", sessionToken)
					
				.when()
					.get("/565711/market/quotes")
				.then()
					.assertThat().statusCode(200)
					.spec(rsb.build())
//					.and().assertThat().body(matchesJsonSchema(new File(basicSchemaLocation)))
//					//.and().assertThat().body(matchesJsonSchema(new File(quotesSchemaLocation)))
				.extract()
					.response();
		
		System.out.println(response.prettyPrint());
	}
	
	public void testPost(String sessionToken){
		String executionResult = null;
		
		// put file in the correct location.
		String inputJsonLocation = Paths.get(schemaLocation, "workflow", "post_InputBody.json").toString();
		inputJsonLocation = "./schemas/workflow/post_InputBody.json";
		Response responsePost ;
	 		try {
				
	 			responsePost = baseRequest().
					given()						
						.header("MktSession", sessionToken)
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.post("/46679/Workflow/Alerts/lists/subscriptions").
					
				then().
				extract()
					.response();
	 			
	 			responsePost.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
}



