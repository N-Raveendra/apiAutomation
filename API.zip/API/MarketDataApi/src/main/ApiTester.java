package main;

import api.ApiRequestType;
import api.BootStrapper;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import api.workflow.IWorkflowRequest;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;

import org.Utilities;
import org.apache.http.HttpStatus;
import settings.Environment;
import settings.TestConfiguration;
import settings.TestSession;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;


public class ApiTester {

	static String testClientId = "117565"; //"414401";
	public static void main(String args[]) throws Exception {
	
		/*String isoDate = "2016-02-19T04:52:57.2574538Z";
		DateTime result=null;
		DateTimeFormatter fmt=ISODateTimeFormat.dateTimeParser().withOffsetParsed();
		DateTime sessionExpiry=fmt.parseDateTime(isoDate); //.withZoneRetainFields(DateTimeZone.forID("Etc/UTC"));
		
		DateTime sessionExpiryA = DateTime.now(DateTimeZone.UTC).minusMinutes(5);
		//2016-02-19 04:49:51.667
		System.out.println(sessionjExpiry.isAfterNow());
		
		*/
		TestConfiguration config = new TestConfiguration() 
		{{
			environment = Environment.QA;
			apiVersion = "v1";
			clientID = testClientId;
			cookies.put("BCSI-AC-0026a082e2bc94a8", "25F3639200000005z2+vgrP/vTBG7N7i/FcjHifEQDgUAAAABQAAAKxgEgCAcAAAAAAAANoWAAA=");
		}};
		//TestSession session = TestSession.getSession(config); 
		BootStrapper.setup(config); //setup session & environment

		doQuotesTest();
		//doEstimatesTest();
		//doAlertSubscriptionTest();
		
		System.out.println("done.");
	}
	
	private static void doQuotesTest() {
		//QUOTES
		IMarketDataRequest quotesReq = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "quotes");
		quotesReq.validateUnauthorizedStatus();
		quotesReq.validateForbiddenStatus();
		
		RequestSpecBuilder sp = new RequestSpecBuilder();
		sp.addQueryParam("x",  "1");
		sp.addQueryParam("y",  "2");
		
		
		ValidatableResponse res =  quotesReq.get("", sp, HttpStatus.SC_OK, null);		
		//res.log().body();		
		
		ResponseSpecBuilder rsb = new ResponseSpecBuilder();		
		rsb
			.expectBody(matchesJsonSchema(new File(quotesReq.getBasicLF_SchemaPath())))
			//.expectBody(matchesJsonSchema(new File(quotesReq.buildSchemaPath("quotes-schema.json"))))
			;
		
		ValidatableResponse res1 =  quotesReq.get("", sp, HttpStatus.SC_OK, rsb);
		res1.log().body();			
	}
	
	private static void doEstimatesTest() {
		//ESTIMATES
		IMarketDataRequest estimatesReq = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "estimates");
		
		estimatesReq.validateUnauthorizedStatus();
		estimatesReq.validateForbiddenStatus();
		
		RequestSpecBuilder sp1 = new RequestSpecBuilder();
		sp1.addQueryParam("x",  "1");
		sp1.addQueryParam("y",  "2");
		
		
		ValidatableResponse estResp =  estimatesReq.get( "", sp1, HttpStatus.SC_OK, null);		
		//res.log().body();		
		
		ResponseSpecBuilder rsb = new ResponseSpecBuilder();		
		rsb
			.expectBody(matchesJsonSchema(new File(estimatesReq.getBasicLF_SchemaPath())))
			//.expectBody(matchesJsonSchema(new File(quotesReq.buildSchemaPath("estimates-schema.json"))))
			;
		
		ValidatableResponse estResp1 =  estimatesReq.get( "", sp1, HttpStatus.SC_OK, rsb);
		estResp1.log().body();	

		
		//estimates/StockInfo

		estResp1 =  estimatesReq.get( "stockinfo", sp1, HttpStatus.SC_OK, rsb);
		estResp1.log().body();
	}
	
	private static void doAlertSubscriptionTest() {
		
		IWorkflowRequest subscriptionReq = (IWorkflowRequest) RequestFactory.Get(ApiRequestType.WorkFlow, "Alerts");
		
		String path = Paths.get(subscriptionReq.buildSchemaPath("post_InputBody.json")).toString();
		
		String inputJsonLocation  = "./schemas/workflow/post_InputBody.json";		
		String jsonContent;
		try {
			jsonContent = Utilities.getFileContents(inputJsonLocation);
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
		System.out.println(jsonContent);
		ValidatableResponse resp = subscriptionReq.post("46679","/lists/subscriptions", jsonContent, null, HttpStatus.SC_CREATED, null);
		
		
	}
}



