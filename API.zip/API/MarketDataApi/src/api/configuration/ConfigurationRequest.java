package api.configuration;

import java.nio.file.Paths;

import api.RequestBase;
import settings.TestSession;

public class ConfigurationRequest extends RequestBase implements IConfigurationRequest{
	
	public ConfigurationRequest(TestSession session, String clientId, String reqBasePath) {
		super(session);
		setClientId(clientId);
		basePath = String.format("%s/configuration/%s",super.basePath, reqBasePath).replace("//",  "/");
	}
	
	
	@Override
	public String getSchemaPath() {
		return Paths.get(super.getSchemaPath(), "configuration").toString();
	}

}

 