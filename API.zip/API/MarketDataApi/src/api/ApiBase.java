package api;

import java.nio.file.Paths;

import org.Utilities;
import org.apache.http.HttpStatus;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import com.jayway.restassured.specification.RequestSpecification;
import com.jayway.restassured.specification.ResponseSpecification;

import settings.TestSession;


public abstract class ApiBase implements IBaseRequest, IGet {
	
	TestSession _session;
	public ApiBase(TestSession session) {		
		_session = session;
	}
	
	public String basePath = "";
	
	public String getSchemaPath() {
		return Paths.get(System.getProperty("user.dir"), "schemas").toString();
	}
	
	public String buildSchemaPath(String fileName) {
		return Paths.get(getSchemaPath(), fileName).toString();
		
	}
	
	public final String getBasicLF_SchemaPath() {
		return Paths.get(System.getProperty("user.dir"), "schemas", "lfBasic-schema.json").toString();
	}
	
	public TestSession currentSession()
	{
		return _session;
	}

	public void validateUnauthorizedStatus(String target) {

        //System.out.println("Thread id is: " + Thread.currentThread().getId());
		currentSession().getBaseRequest(null).
			given()
				.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
				.log().path()
				//.log().headers()
				//.expect().statusCode(HttpStatus.SC_UNAUTHORIZED)
			.when()
				//.get(target)
				.get(Utilities.combinePaths(target, basePath))
			.then()
				.log().status()
				//.log().everything()
				//.assertThat()
				.statusCode(HttpStatus.SC_UNAUTHORIZED)
			.extract()
				.response();
	}
	
	public void validateForbiddenStatus(String target) {
		//System.out.println("Thread id is: " + Thread.currentThread().getId());
		currentSession().getAuthorizedRequest().				
				given()
					.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
					.log().path()
					//.log().headers()
					//.expect().statusCode(HttpStatus.SC_FORBIDDEN)
				.when()
					//.get(target)
					.get(Utilities.combinePaths(target, basePath))
				.then()
					.log().status()
					//.log().everything()
					//.assertThat()
					.statusCode(HttpStatus.SC_FORBIDDEN)
				.extract()
					.response();
			//Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_FORBIDDEN);		
	}
	

	//@Override
	public ValidatableResponse get(String clientId, String suffixToBase, RequestSpecBuilder reqSpecBuilder,
			int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) {
		//System.out.println("Thread id is: " + Thread.currentThread().getId());
		//String testUrl = String.format("%s%s%s", RestAssured.baseURI, RestAssured.basePath, target);
				//System.out.println(String.format("Checking '%s' for status code %s", testUrl, statusCode));

				if (null == reqSpecBuilder) {
					reqSpecBuilder = new RequestSpecBuilder();
				}
				
				if (null == responseSpecBuilder){
					responseSpecBuilder = new ResponseSpecBuilder ();
				}
				
				RequestSpecification reqSpec = reqSpecBuilder.build();
				ResponseSpecification respSpec = responseSpecBuilder.build();
				
				ValidatableResponse response = 
				currentSession().getAuthenticatedRequest()
						.spec(reqSpec)
						.given()
							.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
							.log().path()//.log().headers()
						.when()
							.get(Utilities.combinePaths(clientId, basePath, suffixToBase))
						.then()//.log().status()
							.statusCode(statusCodeToCheck)
							.spec(respSpec);
						//.extract()
							//.response();
				return response;
	}
	
	
	//@Override
	public void validateGet(String clientId, String suffixToBase, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) {
		//System.out.println("Thread id is: " + Thread.currentThread().getId());
		if (null == reqSpecBuilder) {
			reqSpecBuilder = new RequestSpecBuilder();
		}
		
		if (null == responseSpecBuilder){
			responseSpecBuilder = new ResponseSpecBuilder ();
		}
		
		RequestSpecification reqSpec = reqSpecBuilder.build();
		ResponseSpecification respSpec = responseSpecBuilder.build();
		
		currentSession().getAuthenticatedRequest()
			.spec(reqSpec) //any customization
			.given()
				.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
				.log().path()//.log().headers()
			.when()
				//.get(getEndPoint(clientId) + suffixToBase)
				.get(Utilities.combinePaths(clientId, basePath, suffixToBase))
			.then()//.log().status()//.log().body()
				.statusCode(statusCodeToCheck)
				.spec(respSpec);
		
	}

	 
}
