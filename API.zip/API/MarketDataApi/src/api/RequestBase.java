package api;

import java.nio.file.Paths;
import java.util.Properties;

import org.Data;
import org.Utilities;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import com.jayway.restassured.specification.RequestSpecification;
import com.jayway.restassured.specification.ResponseSpecification;

import settings.TestSession;


public abstract class RequestBase implements IBaseRequest, IGet, IPut, IPost, IDelete {
	
	
	private String _clientId = "";
	TestSession _session;
	public RequestBase(TestSession session) {		
		_session = session;
	}
	
	public String basePath = "";
	
	public void setClientId(String clientId) {
		_clientId = clientId;
	}
	
	protected String getClientId() {
		return _clientId;
	}
	
	public String getSchemaPath() {
		return Paths.get(System.getProperty("user.dir"), "schemas").toString();
	}
	
	public String buildSchemaPath(String fileName) {
		return Paths.get(getSchemaPath(), fileName).toString();
		
	}
	
	public final String getBasicLF_SchemaPath() {
		return Paths.get(System.getProperty("user.dir"), "schemas", "lfBasic-schema.json").toString();
	}
	
	public TestSession currentSession()
	{
		return _session;
	}

	public String getCurrentApiKey() {
		return currentSession().getApiKey();
	}
	
	public String getCurrentSessionToken(){
		return currentSession().getSessionToken();
	}
	
	public RequestSpecification getBaseRequest() {
		return currentSession().getBaseRequest(null);
	}
	
	public RequestSpecification getAuthorizedRequest() {
		return currentSession().getAuthorizedRequest();
	}
	
	public RequestSpecification getAuthenticatedRequest() {
		return currentSession().getAuthenticatedRequest();
	}
	
	public void validateUnauthorizedStatus() {
		//System.out.println("Thread id is: " + Thread.currentThread().getId());
		getBaseRequest().
			given()
				.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
				.log().path()
				//.log().headers()
				//.expect().statusCode(HttpStatus.SC_UNAUTHORIZED)
			.when()
				//.get(target)
				.get(Utilities.combinePaths(getClientId(), basePath))
			.then()
				.log().status()
				//.log().everything()
				//.assertThat()
				.statusCode(HttpStatus.SC_UNAUTHORIZED)
			.extract()
				.response();
	}
	
	public void validateForbiddenStatus() {
		//System.out.println("Thread id is: " + Thread.currentThread().getId());
		getAuthorizedRequest().				
				given()
					.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
					.log().path()
					//.log().headers()
					//.expect().statusCode(HttpStatus.SC_FORBIDDEN)
				.when()
					//.get(target)
					.get(Utilities.combinePaths(getClientId(), basePath))
				.then()
					.log().status()
					//.log().everything()
					//.assertThat()
					.statusCode(HttpStatus.SC_FORBIDDEN)
				.extract()
					.response();
			//Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_FORBIDDEN);		
	}
	
	public ValidatableResponse get(String suffixToBase, RequestSpecBuilder reqSpecBuilder,
			int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) {
		return get(getClientId(), suffixToBase, reqSpecBuilder, statusCodeToCheck, responseSpecBuilder);
	}
	

	public ValidatableResponse put(String suffixToBase, String jsonContentToPost, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder)  {
		return put(getClientId(), suffixToBase, jsonContentToPost, reqSpecBuilder, statusCodeToCheck, responseSpecBuilder);
	}
	
	public ValidatableResponse post(String suffixToBase, String jsonContentToPost, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) 	{
		return  post(getClientId(), suffixToBase, jsonContentToPost, reqSpecBuilder, statusCodeToCheck, responseSpecBuilder);
	}
	
	public ValidatableResponse delete(String suffixToBase, RequestSpecBuilder reqSpecBuilder,
			int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) {
		return delete(getClientId(), suffixToBase, reqSpecBuilder, statusCodeToCheck, responseSpecBuilder);
	}
	
	
	public ValidatableResponse get(String clientId, String suffixToBase, RequestSpecBuilder reqSpecBuilder,
			int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) {
				//System.out.println("Thread id is: " + Thread.currentThread().getId());
				if (null == reqSpecBuilder) {
					reqSpecBuilder = new RequestSpecBuilder();
				}
				
				if (null == responseSpecBuilder){
					responseSpecBuilder = new ResponseSpecBuilder ();
				}
				
				RequestSpecification reqSpec = reqSpecBuilder.build();
				ResponseSpecification respSpec = responseSpecBuilder.build();
				
				ValidatableResponse response = 
					getAuthenticatedRequest()
						.spec(reqSpec)
						.given()
							.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
							.log().path()
							.log().ifValidationFails()
							//.log().headers()						
						.when()
							.get(Utilities.combinePaths(clientId, basePath, suffixToBase))
						.then()
							.log().ifValidationFails()
							//.log().status()
							.statusCode(statusCodeToCheck)							
							.spec(respSpec);							
						//.extract()
							//.response();
				return response;
	}
	
	
	public ValidatableResponse post(String clientId, String suffixToBase, String jsonContentToPost, 
			RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) {
				//System.out.println("Thread id is: " + Thread.currentThread().getId());
				if (null == reqSpecBuilder) {
					reqSpecBuilder = new RequestSpecBuilder();
				}
				
				if (null == responseSpecBuilder){
					responseSpecBuilder = new ResponseSpecBuilder ();
				}
				
				RequestSpecification reqSpec = reqSpecBuilder.build();
				ResponseSpecification respSpec = responseSpecBuilder.build();
				
				ValidatableResponse response = 
					getAuthenticatedRequest()
						.spec(reqSpec)
						.given()
							.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
							.log().path()//.log().headers()
							.log().ifValidationFails()
							.body(jsonContentToPost)
						.when()
							.post(Utilities.combinePaths(clientId, basePath, suffixToBase))
						.then()
							.log().ifValidationFails()
							.log().status()
							.log().body()
							.statusCode(statusCodeToCheck)
							.spec(respSpec);
						//.extract()
							//.response();
				return response;
		
	}
	

	public ValidatableResponse put(String clientId, String suffixToBase, String jsonContentToPost, 
			RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) {
				//System.out.println("Thread id is: " + Thread.currentThread().getId());
				if (null == reqSpecBuilder) {
					reqSpecBuilder = new RequestSpecBuilder();
				}
				
				if (null == responseSpecBuilder){
					responseSpecBuilder = new ResponseSpecBuilder ();
				}
				
				RequestSpecification reqSpec = reqSpecBuilder.build();
				ResponseSpecification respSpec = responseSpecBuilder.build();
				
				ValidatableResponse response = 
					getAuthenticatedRequest()
						.spec(reqSpec)
						.given()
							.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
							.log().path()//.log().headers()
							.log().ifValidationFails()
							.body(jsonContentToPost)
						.when()
							.put(Utilities.combinePaths(clientId, basePath, suffixToBase))
						.then()//.log().status()
							.log().ifValidationFails()
							.log().status()
							.log().body()
							.statusCode(statusCodeToCheck)
							.spec(respSpec);
						//.extract()
							//.response();
				return response;
		
	}

	public ValidatableResponse delete(String clientId, String suffixToBase, RequestSpecBuilder reqSpecBuilder,
			int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) {
	
				//System.out.println("Thread id is: " + Thread.currentThread().getId());
				if (null == reqSpecBuilder) {
					reqSpecBuilder = new RequestSpecBuilder();
				}
				
				if (null == responseSpecBuilder){
					responseSpecBuilder = new ResponseSpecBuilder ();
				}
				
				RequestSpecification reqSpec = reqSpecBuilder.build();
				ResponseSpecification respSpec = responseSpecBuilder.build();
				
				ValidatableResponse response = 
					getAuthenticatedRequest()
						.spec(reqSpec)
						.given()
							.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
							.log().path()//.log().headers()
							.log().ifValidationFails()
						.when()
							.delete(Utilities.combinePaths(clientId, basePath, suffixToBase))
						.then()
							.log().ifValidationFails()
							.log().status()
							.log().body()
							.statusCode(statusCodeToCheck)
							.spec(respSpec);
						//.extract()
							//.response();
				return response;
	}
	
	 
}
