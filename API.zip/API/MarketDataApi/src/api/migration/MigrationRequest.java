package api.migration;

import java.nio.file.Paths;

import api.RequestBase;
import settings.TestSession;

public class MigrationRequest extends RequestBase implements IMigrationRequest{
	
	public MigrationRequest(TestSession session, String clientId, String reqBasePath) {
		super(session);
		setClientId(clientId);
		basePath = String.format("%s/migration/%s",super.basePath, reqBasePath).replace("//",  "/");
	}
		
	
	@Override
	public String getSchemaPath() {
		return Paths.get(super.getSchemaPath(), "migration").toString();
	}

}

 