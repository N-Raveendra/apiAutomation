package api.kmsSites;

import java.nio.file.Paths;

import api.RequestBase;
import settings.TestSession;

public class KMSSiteRequest extends RequestBase implements IKMSSiteRequest{
	
	public KMSSiteRequest(TestSession session, String clientId, String reqBasePath) {
		super(session);
		setClientId(clientId);
		basePath = String.format("%s/sites/%s",super.basePath, reqBasePath).replace("//",  "/");
	}
	
	
	@Override
	public String getSchemaPath() {
		return Paths.get(super.getSchemaPath(), "kms").toString();
	}

}

 