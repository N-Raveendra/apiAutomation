package api.kmsSites;

import api.IBaseRequest;
import api.IDelete;
import api.IGet;
import api.IPost;
import api.IPut;

public interface IKMSSiteRequest extends IBaseRequest, IGet, IPut, IPost, IDelete {
	
}
