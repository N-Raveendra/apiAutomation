package api;
import settings.TestConfiguration;
import settings.TestSession;

public class BootStrapper { //public class BootStrapper implements ISuiteListener {
	public TestSession getApiTestSession() {
		return ApiTestSession;
	};
	
	private TestSession ApiTestSession;
	private String SessionClientId = "";
    private volatile static BootStrapper _instance; //
    
    private BootStrapper() {     	
    	if (_instance == null) {
    		synchronized(BootStrapper.class) {
    			if (_instance == null) {
    				_instance = this;
    				}
    			}
    		}
    	}
    
    public static BootStrapper getInstance() {
    	 if (_instance == null) {
    	  synchronized(BootStrapper.class) {
    	   if (_instance == null) {
    	    _instance = new BootStrapper();
    	   }
    	  }
    	 }
    	 return _instance;
    	}

    //Read more: http://javarevisited.blogspot.com/2014/05/double-checked-locking-on-singleton-in-java.html#ixzz40aHPOSlQ
    	
    public void  setSession(TestSession session) {
    	ApiTestSession = session;
    	setDefaultClientId(session.getClient());
    }  
    
    public void  setDefaultClientId(String APIAccessID) {
    	SessionClientId = APIAccessID;
    }  
    public String getDefaultClientId() {
    	return SessionClientId;
    }  
    
	public static void setup(TestConfiguration config) {
		TestSession session = TestSession.getSession(config);
		BootStrapper.getInstance().setSession(session);
	}
	
}
