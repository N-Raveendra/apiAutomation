package api;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;

public interface IPost {
	ValidatableResponse post(String suffixToBase, String jsonContentToPost, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder);
	ValidatableResponse post(String clientId, String suffixToBase, String jsonContentToPost, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder);
}