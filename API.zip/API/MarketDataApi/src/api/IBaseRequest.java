package api;

public interface IBaseRequest extends IApiRequest {		
	//void setClientId(String clientId);
	String getBasicLF_SchemaPath();
	String getSchemaPath() ;
	String buildSchemaPath(String fileName);	
		

	
	void validateUnauthorizedStatus() ;
	void validateForbiddenStatus() ;

}