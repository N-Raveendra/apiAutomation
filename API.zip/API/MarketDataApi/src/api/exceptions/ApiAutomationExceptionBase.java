package api.exceptions;

public class ApiAutomationExceptionBase extends Exception
{

	private static final long serialVersionUID = 8070741577168770766L;

		public ApiAutomationExceptionBase()
		{
		}

		public ApiAutomationExceptionBase(String message)
		{
			super(message);
		}

		public ApiAutomationExceptionBase(Throwable cause)
		{
			super(cause);
		}

		public ApiAutomationExceptionBase(String message, Throwable cause)
		{
			super(message, cause);
		}

		public ApiAutomationExceptionBase(String message, Throwable cause, 
                                           boolean enableSuppression, boolean writableStackTrace)
		{
			super(message, cause, enableSuppression, writableStackTrace);
		}

}