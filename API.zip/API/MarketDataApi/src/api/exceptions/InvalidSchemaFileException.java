package api.exceptions;


public class InvalidSchemaFileException extends ApiAutomationExceptionBase
{

	private static final long serialVersionUID = -7396671101851305198L;

	public InvalidSchemaFileException()
	{
	}

	public InvalidSchemaFileException(String message)
	{
		super(message);
	}

	public InvalidSchemaFileException(Throwable cause)
	{
		super(cause);
	}

	public InvalidSchemaFileException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public InvalidSchemaFileException(String message, Throwable cause, 
                                       boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

}

