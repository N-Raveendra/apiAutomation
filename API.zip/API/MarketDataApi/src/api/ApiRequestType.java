package api;

public enum ApiRequestType {
	MarketData, Configuration, WorkFlow, Migration,kmsSites,IRService
}