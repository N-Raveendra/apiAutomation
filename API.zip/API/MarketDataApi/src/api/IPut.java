package api;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;

public interface IPut {
	ValidatableResponse put(String suffixToBase, String jsonContentToPost, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder);
	ValidatableResponse put(String clientId, String suffixToBase, String jsonContentToPost, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder);
}