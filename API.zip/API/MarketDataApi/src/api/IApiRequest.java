package api;

import com.jayway.restassured.specification.RequestSpecification;

public interface IApiRequest {
	RequestSpecification getBaseRequest();
	RequestSpecification getAuthorizedRequest();
	RequestSpecification getAuthenticatedRequest();
	String getCurrentApiKey();
	String getCurrentSessionToken();
	
}