package api;

import javax.lang.model.type.UnknownTypeException;

import api.configuration.ConfigurationRequest;
import api.configuration.IConfigurationRequest;
import api.irservice.IIRServiceRequest;
import api.irservice.IRServiceRequest;
import api.kmsSites.KMSSiteRequest;
import api.kmsSites.IKMSSiteRequest;
import api.market.IMarketDataRequest;
import api.market.MarketDataRequest;
import api.migration.IMigrationRequest;
import api.migration.MigrationRequest;
import api.workflow.IWorkflowRequest;
import api.workflow.WorkflowRequest;
import settings.TestSession;

public class RequestFactory {
	private static TestSession testSession = null;
	public static IApiRequest Get(ApiRequestType typeOfRequest, String basePath) {
		
		if (null == testSession) {
			synchronized (RequestFactory.class) {
				if (null == testSession) {
					testSession = BootStrapper.getInstance().getApiTestSession();
				}				
			}
		}
		
		switch(typeOfRequest){
			case Configuration:
				return (IConfigurationRequest) new ConfigurationRequest(testSession, BootStrapper.getInstance().getDefaultClientId(), basePath);
			
			case MarketData:
				return (IMarketDataRequest) new MarketDataRequest(testSession, BootStrapper.getInstance().getDefaultClientId(), basePath);
				
			case WorkFlow:
				return (IWorkflowRequest) new WorkflowRequest(testSession, BootStrapper.getInstance().getDefaultClientId(), basePath);

			case Migration:
				return (IMigrationRequest) new MigrationRequest(testSession, BootStrapper.getInstance().getDefaultClientId(), basePath);
				
			case kmsSites:
				return (IKMSSiteRequest) new KMSSiteRequest(testSession, BootStrapper.getInstance().getDefaultClientId(), basePath);
			
			case IRService:
				return (IIRServiceRequest) new IRServiceRequest(testSession, BootStrapper.getInstance().getDefaultClientId(), basePath);
			default:
				throw new UnknownTypeException(null, "Not supporeted");
			
		}
	}
}