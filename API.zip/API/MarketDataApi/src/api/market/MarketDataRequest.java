package api.market;

import java.nio.file.Paths;

import api.RequestBase;
import settings.TestSession;

public class MarketDataRequest extends RequestBase implements IMarketDataRequest{
	
	public MarketDataRequest(TestSession session, String clientId, String reqBasePath) {
		super(session);
		setClientId(clientId);
		basePath = String.format("%s/market/%s",super.basePath, reqBasePath).replace("//",  "/");
	}
		
	
	@Override
	public String getSchemaPath() {
		return Paths.get(super.getSchemaPath(), "market").toString();
	}

}

 