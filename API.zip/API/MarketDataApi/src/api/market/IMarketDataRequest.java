package api.market;

import api.IBaseRequest;
import api.IDelete;
import api.IGet;
import api.IPost;
import api.IPut;

public interface IMarketDataRequest extends IBaseRequest, IGet, IPut, IPost, IDelete {
	
}