package api;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;

public interface IDelete {	
	ValidatableResponse delete(String suffixToBase, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder);
	ValidatableResponse delete(String clientId, String suffixToBase, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder);
}