package api.irservice;

import java.nio.file.Paths;

import api.RequestBase;
import settings.TestSession;

public class IRServiceRequest extends RequestBase implements IIRServiceRequest{
	
	public IRServiceRequest(TestSession session, String clientId, String reqBasePath) {
		super(session);
		setClientId(clientId);
		basePath = String.format("%s//%s",super.basePath, reqBasePath).replace("//",  "/");
	}
	
	
	@Override
	public String getSchemaPath() {
		return Paths.get(super.getSchemaPath(), "irservice").toString();
	}

}

 