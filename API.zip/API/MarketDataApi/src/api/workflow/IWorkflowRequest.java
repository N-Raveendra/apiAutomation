package api.workflow;

import api.IBaseRequest;
import api.IDelete;
import api.IPost;
import api.IPut;
import api.IGet;

public interface IWorkflowRequest extends IBaseRequest, IPut, IPost, IDelete, IGet {
	
}
