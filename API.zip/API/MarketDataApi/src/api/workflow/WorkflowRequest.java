package api.workflow;

import java.nio.file.Paths;

import api.RequestBase;
import settings.TestSession;

public class WorkflowRequest extends RequestBase implements IWorkflowRequest{
	
	public WorkflowRequest(TestSession session, String clientId, String reqBasePath) {
		super(session);
		setClientId(clientId);
		basePath = String.format("%s/workflow/%s",super.basePath, reqBasePath).replace("//",  "/");
	}
	
	@Override
	public String getSchemaPath() {
		return Paths.get(super.getSchemaPath(), "workflow").toString();
	}

}

 