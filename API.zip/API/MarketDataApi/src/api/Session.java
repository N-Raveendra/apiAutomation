package api;

import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import com.jayway.restassured.specification.RequestSpecification;
import com.jayway.restassured.specification.ResponseSpecification;

import settings.TestSession;

public class Session extends RequestBase  {

	public Session(TestSession session) {
		super(session);
		basePath = String.format("/%s/session",  super.basePath).replaceAll("//", "/");
		
	}

	private String getEndPoint(String clientId) {		
		return String.format("%s%s", clientId, basePath).replaceAll("//", "/");
	}
	
	public ValidatableResponse getResponse(String clientId, RequestSpecBuilder reqSpecBuilder, int statusCodeToCheck, ResponseSpecBuilder responseSpecBuilder) {

		//String testUrl = String.format("%s%s%s", RestAssured.baseURI, RestAssured.basePath, target);
		//System.out.println(String.format("Checking '%s' for status code %s", testUrl, statusCode));

		if (null == reqSpecBuilder) {
			reqSpecBuilder = new RequestSpecBuilder();
		}
		
		if (null == responseSpecBuilder){
			responseSpecBuilder = new ResponseSpecBuilder ();
		}
		
		RequestSpecification reqSpec = reqSpecBuilder.build();
		ResponseSpecification respSpec = responseSpecBuilder.build();
		
		ValidatableResponse response = 
		currentSession().getAuthorizedRequest()
				.spec(reqSpec) 
				.given()
				.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080)
				.log().path()//.log().headers()
					.expect().statusCode(statusCodeToCheck)
				.when()
					.get(getEndPoint(clientId))
				.then().log().status()
					.assertThat().statusCode(statusCodeToCheck)
					.spec(respSpec);
				//.extract()
					//.response();
		return response;
		
	}
	/*
	public ValidatableResponse getResponse(String clientId, int statusCodeToCheck, String schemaFilePath) throws InvalidSchemaFileException {
	
		
		ValidatableResponse response = 
		currentSession().getAuthenticatedRequest().
				given().log().path()
					.expect().statusCode(statusCodeToCheck)
				.when()
					.get(getEndPoint(clientId))
				.then().log().status()
					.assertThat().statusCode(statusCodeToCheck);
				//.extract()
					//.response();
		if (null != schemaFilePath) {
			File schemaFile = new File(schemaFilePath);
			if (schemaFile.exists())
			{
				response = response.assertThat().body(matchesJsonSchema(schemaFile));
			}
			else {
				throw new InvalidSchemaFileException(String.format("Schema file '%s' is invalid", schemaFilePath));
			}
		}
		return response;
		
	}*/

	public void validateGet(String clientId, int statusCodeToCheck) {
		currentSession().getAuthorizedRequest().
		given()
		.relaxedHTTPSValidation().proxy("IN03CBCSG01.org.nasdaqomx.com", 8080).and()
		.log().path()//.log().headers()
			.expect().statusCode(statusCodeToCheck)
		.when()
			.get(getEndPoint(clientId))
		.then().log().status()
			.assertThat().statusCode(statusCodeToCheck);
		
	}
}