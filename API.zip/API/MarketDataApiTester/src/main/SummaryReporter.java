package main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.testng.IReporter;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.xml.XmlSuite;

import api.BootStrapper;
import settings.TestSession;

public class SummaryReporter implements IReporter {
	private PrintWriter mOut;

	public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
		String tzId = TimeZone.getDefault().getID();
		DateTime dt = DateTime.now(DateTimeZone.forID(tzId)); // new DateTime();
		DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd_hh_mm-a");	
		
		String outputFolder = String.format("%s\\Summary",  outputDirectory );
		String reportFile = String.format("summary-report-%s.html", fmt.print(dt));
		new File(outputFolder).mkdirs();
		try {
			mOut = new PrintWriter(new BufferedWriter(new FileWriter(new File(outputFolder, reportFile))));
		} catch (IOException e) {
			System.out.println("Error in creating writer: " + e);
		}
		
		fmt = DateTimeFormat.forPattern("yyyy-MM-dd hh:mm a");
	 
		 
		TestSession session = BootStrapper.getInstance().getApiTestSession(); 
		String envDetails = String.format("<h5>Environment: %s</h5>", session.getCurrentEnvironment());
		String envUrlBase = String.format("<h5>Base URL: %s</h5>", session.getCurrentUrlBase());
		String execDateTime = String.format("<h5>Executed at: %s (%s)</h5>", fmt.print(dt),tzId);
		startHtml("Market Data API Test Execution Report");
		print(envDetails);
		print(envUrlBase);
		print(execDateTime);
		//print(String.format("<H4>No. of Suites run : %s</H4>",suites.size()));
		startTable(Arrays.asList("Suite Name", "Passed", "Failed", "Skipped", "Total", "Time(s)", "Success %"));		
		for (ISuite suite : suites) {
			//skip logging test setup/initialize
			if (suite.getName().equalsIgnoreCase("TestSetup")) {
				continue;
			}			
			//print("Suite>" + suite.getName());
			List<String> results = new ArrayList<>();			
			Map<String, ISuiteResult> suiteResults = suite.getResults();
			for (String testName : suiteResults.keySet()) {				
				
				ISuiteResult suiteResult = suiteResults.get(testName);
				ITestContext testContext = suiteResult.getTestContext();
				
				int passedCount = testContext.getPassedTests().size();
				int failedCount = testContext.getFailedTests().size();
				int skippedCount = testContext.getSkippedTests().size();
				int totalRunCount = passedCount + failedCount;
				float successPercent = 100 * ((float)passedCount / (float)totalRunCount);
				long duration = ((testContext.getEndDate().getTime() - testContext.getStartDate().getTime()) / 1000 % 60);
				//System.out.println(String.format("%s => %s %s", suite.getName(), testContext.getEndDate().getTime(), testContext.getStartDate().getTime()));
				results.add(suite.getName());
				results.add(Integer.toString(passedCount).toString());
				results.add(Integer.toString(failedCount).toString());
				results.add(Integer.toString(skippedCount).toString());
				results.add(Integer.toString(totalRunCount).toString());
				results.add(String.valueOf(duration));
				results.add(String.format("%5.2f", successPercent));				
				addRow(results);
			}
		}
		endTable();
		print("<br/><input class=\"toggle-box\" id=\"header1\" type=\"checkbox\" ><label for=\"header1\">detailed results...</label><div><pre>");
		print("Suites run: " + suites.size());
		for (ISuite suite : suites) {
			print("Suite>" + suite.getName());
			Map<String, ISuiteResult> suiteResults = suite.getResults();
			for (String testName : suiteResults.keySet()) {
				print("    Test>" + testName);
				ISuiteResult suiteResult = suiteResults.get(testName);
				ITestContext testContext = suiteResult.getTestContext();
				print("        Failed>" + testContext.getFailedTests().size());
				IResultMap failedResult = testContext.getFailedTests();
				Set<ITestResult> testsFailed = failedResult.getAllResults();
				for (ITestResult testResult : testsFailed) {
					print("            " + testResult.getName());
					print("                " + testResult.getThrowable());
				}
				IResultMap passResult = testContext.getPassedTests();
				Set<ITestResult> testsPassed = passResult.getAllResults();
				print("        Passed>" + testsPassed.size());
				for (ITestResult testResult : testsPassed) {
					print("            " + testResult.getName() + ">took "
							+ (testResult.getEndMillis() - testResult.getStartMillis()) + "ms");
				}
				IResultMap skippedResult = testContext.getSkippedTests();
				Set<ITestResult> testsSkipped = skippedResult.getAllResults();
				print("        Skipped>" + testsSkipped.size());
				for (ITestResult testResult : testsSkipped) {
					print("            " + testResult.getName());
				}

			}
		}
		print("</pre></div");
		endHtml();
		mOut.flush();
		mOut.close();
	}

	private void print(String text) {
		//System.out.println(text);
		//mOut.println(text + "<br/>");
		mOut.println(text);
	}	

	private void startHtml(String title) {
		print("<html>");
		print("<head>");		
		print(String.format("<title>%s</title>", title));
		addCss();
		print("</head>");
		print("<body>");
		print(String.format("<body><h4>%s</h4>", title));
		
	}
	private void addCss() {		
		print(String.format("<style>%s</style>","body{background:#F9F9F9;font-family:\"Trebuchet MS\",Arial,Helvetica,sans-serif;font-size:1em;color:#555}.table-results{font-size:.8em;border-collapse:collapse;width:600}.table-results td,.table-results th{border:1px solid #ddd;text-align:left;padding:8px}.table-results tr:nth-child(even){background-color:#f2f2f2}.table-results tr:hover{background-color:#ddd}.table-results th{padding-top:10px;padding-bottom:10px;background-color:#1d1e27;color:#fff}h4,h5{margin-bottom:5px}h4{margin-top:2px}h5{margin-top:5px;font-weight:400}"));
		print(String.format("<style>%s</style>","pre{display:block;width:600;font:400 12px/22px Monaco,Monospace!important;color:#555;background-color:#fff;background-image:-webkit-repeating-linear-gradient(top,#ddd 0,#ddd 22px,#fff 22px,#fff 44px);background-image:-moz-repeating-linear-gradient(top,#ddd 0,#ddd 22px,#fff 22px,#fff 44px);background-image:-ms-repeating-linear-gradient(top,#ddd 0,#ddd 22px,#fff 22px,#fff 44px);background-image:-o-repeating-linear-gradient(top,#ddd 0,#ddd 22px,#fff 22px,#fff 44px);background-image:repeating-linear-gradient(top,#ddd 0,#ddd 22px,#fff 22px,#fff 44px);padding:0 1em;overflow:auto}"));		
		print(String.format("<style>%s</style>",".toggle-box{display:none}.toggle-box+label{cursor:pointer;display:block;font-weight:700;line-height:21px;margin-bottom:5px}.toggle-box+label+div{display:none;margin-bottom:10px}.toggle-box:checked+label+div{display:block}.toggle-box+label:before{background-color:#4F5150;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px;color:#FFF;content:\"+\";display:block;float:left;font-weight:700;height:20px;line-height:20px;margin-right:5px;text-align:center;width:20px}.toggle-box:checked+label:before{content:\"\\2212\"}"));
		
	}
	private void startTable(List<String> tableHeaders) {
		print("<table class=\"table-results\">");
		print("<thead>");
		print("<tr>");
		for(String th : tableHeaders) {
			print(String.format("<th>%s</th>", th));
		}
		print("</tr>");
		print("</thead>");
		print("<tbody>");
	}
	
	private void addRow(List<String> tableCols) {
		StringBuilder sb = new StringBuilder();
		sb.append("<tr>");
		for(String col : tableCols) {
			sb.append("<td>").append(col).append("</td>");
		}
		sb.append("</tr>");
		print(sb.toString());
	}

	private void endTable() {
		print("<tbody>");
		print("</table>");
	}
	private void endHtml() {
		print("</body></html>");
	}
}