package main;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import api.BootStrapper;
import settings.TestConfiguration;

public class TestActivator {	

	@BeforeSuite(enabled=true, alwaysRun = true)
    @Parameters({"configFilePath"})
	public static void setup(String configFilePath) throws Exception, JsonMappingException, IOException {    
    	
		ObjectMapper mapper = new ObjectMapper();		
		String filePath = Paths.get(System.getProperty("user.dir"), configFilePath).toString();
		TestConfiguration config = mapper.readValue(new File(filePath), TestConfiguration.class);
		
		BootStrapper.setup(config);
 
	}
    
}
