package tests.irapiApigee;

import org.Data;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import java.io.InputStream;
import java.util.Properties;

import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.matcher.RestAssuredMatchers.matchesXsd;

public class Assets_Detail_NasdaqIR_Apigee_JSON extends Data{
	
	String nasdaqIRApigeeURL = "";
	String siteURL = "";
	String irAPIToken = "";
	String assetID="";
	String invalidAPI_URL="";
	String invalidAPIToken_URL="";
	String proxyAddress="";		
	String inputJsonLocation  = "./schemas/irapi/";	
	String invalidHubirapiToken = "";
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		
		Properties globalValues = ReadGlobalFileData();
		nasdaqIRApigeeURL = globalValues.getProperty("nasdaqIRApigeeURL");
		irAPIToken = globalValues.getProperty("irAPIToken");
		invalidHubirapiToken = globalValues.getProperty("invalidHubirapiToken");
		assetID = globalValues.getProperty("assetID");
		proxyAddress=globalValues.getProperty("proxyAddress");
		
		}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void nasdaqIrapiAssetsDetailJSON_200(){
	 	 
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(nasdaqIRApigeeURL +irAPIToken+ "/assets/"+assetID+"?_format=json").
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}


	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"irapi", "notFound", "full"})
	public void nasdaqIrapiAssetsDetailJSON_404(){
	 	 
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
						.get(nasdaqIRApigeeURL + irAPIToken +"/abc/assets/"+assetID+"?_format=json&page=1").	
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
		
	//-------------------------- Unauthorized irapi token-----------------------------
	@Test(groups={"irapi", "unAuthorized","full"})
	public void nasdaqIrapiAssetsDetailJSON_401(){
	 	 
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
						.get(nasdaqIRApigeeURL + invalidHubirapiToken +"/assets/"+assetID+"?_format=json&page=1").						
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_UNAUTHORIZED);			
		}

	
	//-------------------------- JSON Schema validation-----------------------------
	@Test(groups={"irapi", "schemaValidationDetailed", "full"})
	    public void nasdaqIrapiAssetsDetailJSON_SchemaValidations(){
		String fileName = "irapi_assets_detail_mock_json_schema.json";
		String schemaPath = inputJsonLocation + fileName;
		
		ValidatableResponse valResp = 
				given()
					.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
				when()			
					.get(nasdaqIRApigeeURL + irAPIToken +"/assets/"+assetID+"?_format=json").			
				then().
					assertThat().statusCode(HttpStatus.SC_OK).
					assertThat().body(matchesJsonSchema(new File(schemaPath)));	
	    }       	
	
}
	
	