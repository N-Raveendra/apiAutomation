package tests.irLegacy;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.matcher.RestAssuredMatchers.matchesXsd;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import java.io.InputStream;

import org.Data;
import java.io.File;
import java.util.Properties;

public class NewsDetails_XML extends Data{
	
	String clientApiGCSDataURL = "";
	String siteURL = "";
	String irAPIToken = "";
	String newsID="";
	String invalidAPI_URL="";
	String invalidAPIToken_URL="";
	String proxyAddress="";
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		
		Properties globalValues = ReadGlobalFileData();
		clientApiGCSDataURL = globalValues.getProperty("clientLegacyURL");
		irAPIToken = globalValues.getProperty("irAPIToken");
		newsID = globalValues.getProperty("newsID");
		proxyAddress=globalValues.getProperty("proxyAddress");
		
		siteURL=clientApiGCSDataURL+irAPIToken+"/news/"+newsID;
		invalidAPI_URL=clientApiGCSDataURL + irAPIToken+"/newsInvalid"+newsID;
		invalidAPIToken_URL=clientApiGCSDataURL + irAPIToken+"ssdfdsf/news/"+newsID;
		System.out.println("legacy News API  : "+siteURL);
		}
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiNewsDetailsLookup_200(){
	 	 
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
//						    .log().all().
						when()			
							.get(siteURL).				
						then().	
						extract()
							.response();
			
							response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}
	
	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiNewsDetailsLookup_404(){
	 	 
		
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPI_URL).				
						then().	
						extract()
							.response();
					
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
		
	//-------------------------- Unsupported media type-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiNewsDetailsLookup_InvalidAPI_401(){
		
	
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPIToken_URL).							
						then().	
						extract()
							.response();
						
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_UNAUTHORIZED);			
		}
	
	
	
	
	//-------------------------- XML Schema validation-----------------------------
	@Test(groups={"irapi", "schemaValidationDetailed", "full"})
	    public void irapiNewsDetailsXML_SchemaValidations(){
	        InputStream xsd = Thread.currentThread().getContextClassLoader().getResourceAsStream("irapiNewsDetailsXMLschema.xsd");
	        
	    	given()
				.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
	        when().
	        	get(siteURL).
	        then().
	        		statusCode(200).
	        		body(matchesXsd(xsd));
	    } 

}	
	
	
	
	
	
	
	
