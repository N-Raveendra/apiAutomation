/*
package tests;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.security.Credentials;

import groovy.ui.SystemOutputInterceptor;


/*
public class n3aLogin {
	
	//System.o
	
	
	
	/*public static void main (String args[]) {
		String driverPath = "C:\\Chromedriver\\";
		 WebDriver driver;
		 String site_url = "https://puneeth.test-nasdaq.acsitefactory.com/saml_login";
		
 //  try {
		//WebDriver driver = new firefoxDriver();
			driver = new ChromeDriver();
			System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		
			driver.get(site_url);
			driver.findElement(By.id("userName")).sendKeys("a");
			driver.findElement(By.id("password")).sendKeys("b");
			driver.findElement(By.cssSelector("#loginFormPanel > button")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}*/
//}

/*			try{
				System.out.println("Checking Security Question Page is available or not");
				String instr = driver.findElement(By.cssSelector("#qnaTable>div:first-child>label")).getText();
				System.out.println("Security Question Page found");
				driver.findElement(By.cssSelector("#qnaTable>div:first-child>#Answer"))
						.sendKeys(instr.substring(instr.lastIndexOf(" ") + 1).replace("?", ""));
				String instr_2 = driver.findElement(By.cssSelector("#qnaTable>div:last-child>label")).getText();
				driver.findElement(By.cssSelector("#qnaTable>div:last-child>#Answer"))
						.sendKeys(instr_2.substring(instr_2.lastIndexOf(" ") + 1).replace("?", ""));
				driver.findElement(By.cssSelector("#verifyAnswers > span.SQcontinueButtonText")).submit();
//			}catch (Exception e) {
//				System.out.println("Security Question page is not available");
//			}
	}
	}
*/