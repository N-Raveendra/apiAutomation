package tests.kms;

import org.Data;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import static com.jayway.restassured.RestAssured.given;

import java.util.Properties;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;



public class KMS extends Data {
	
	String APIAccessCode = "";
	String DomainURL = "";
	String proxyAddress = "";
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		
		Properties globalValues = ReadGlobalFileData();
		APIAccessCode = globalValues.getProperty("APIAccessCode");
		DomainURL = globalValues.getProperty("DomainURL");
		proxyAddress = globalValues.getProperty("proxyAddress");
		
	}


	//https://irkms.corporate-ir.net  
//	String DomainURL = "https://irkms.corporate-ir-uat.net/v1/Sites/";
//	String APIAccessCode = "6325bcd5-bb43-40bb-ba40-b4484c6d314a";
	

	IMarketDataRequest marketRequest;	
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Quotes");
	}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"kms", "getOk", "smoke","full"})
	public void kmsTest200(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	System.out.println(apiKey);
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	System.out.println(mktSession);
		 	System.out.println(DomainURL+APIAccessCode+"/key");
		 	int statusCode = 0;
		 	
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080)
							//.relaxedHTTPSValidation().proxy("US01CBCSG02.org.nasdaqomx.com", 8080)
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.get(DomainURL + APIAccessCode+"/key").				
						then().	
						extract()
							.response();
							response.prettyPeek();
						
						statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);			
		}
	

	//-------------------------- 401 - Unauthorized Response validations-------------------
	@Test(groups={"kms", "smoke","full", "unAuthorized"})
	public void kmsTest401(){
	 	 
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.get(DomainURL + APIAccessCode+"/key").
							
						then().	
						extract()
							.response();
							response.prettyPeek();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_UNAUTHORIZED);			
		}
	

	//-------------------------- 403 - Forbidden Response validations----------------------
	@Test(groups={"kms", "forbidden","full"})
	public void kmsTest403(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	int statusCode = 0;
			
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080)
							.header("apiKey", apiKey)
							.header("Accept", "application/json").
						when()			
							.get(DomainURL+APIAccessCode+"/key").
							
						then().	
						extract()
							.response();
							response.prettyPeek();
							
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_FORBIDDEN);			
		}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	@Test(groups={"kms", "badRequests","full"})
	public void kmsTest400(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080)
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.get(DomainURL +APIAccessCode+ "abc/key").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_BAD_REQUEST);			
		}

	
	//-------------------------- 404 - Not Found Response validations----------------------
	@Test(groups={"kms", "notFound","smoke","full"})
	public void kmsTest404(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080)
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.get(DomainURL+APIAccessCode+"/keyssss").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}


	//-------------------------- 405 - Method Not Allowed validations-----------------------
	@Test(groups={"kms", "mthdNtAlwd","full"})
	public void kmsTest405put(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080)
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").and()
							.body("testInputForPut").
						when()			
							.put(DomainURL+APIAccessCode+"/key").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_METHOD_NOT_ALLOWED);			
		}
	
	
	@Test(groups={"kms", "mthdNtAlwd","full"})
	public void kmsTest405post(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080)
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").and()
							.body("testInputForPost").
						when()			
							.post(DomainURL+APIAccessCode+"/key").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_METHOD_NOT_ALLOWED);			
		}
	
	
	@Test(groups={"kms", "mthdNtAlwd","full"})
	public void kmsTest405delete(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080)
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.delete(DomainURL+APIAccessCode+"/key").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_METHOD_NOT_ALLOWED);			
		}


}
