package tests.migration;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import api.ApiRequestType;
import api.RequestFactory;
import api.migration.IMigrationRequest;


public class SecFilings_XBRL {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	String secAccessionNumberValid = "0000077476-15-000021";
	
	String secAccessionNumberInvalid = "0001104659-15-12345";

	IMigrationRequest migrationRequest;
	IMigrationRequest migrationRqst_IncompleteRoute;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		migrationRequest = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "SecFilings");
		migrationRqst_IncompleteRoute = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "SecFil");	
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationSecFilingsXBRL200() {
			
			//200 - OK test for migration/SecFilings XBRL end point
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			migrationRequest.get("/"+secAccessionNumberValid+ "/xbrl", reqSpec, HttpStatus.SC_OK, null);
			
		}
		

		//-------------------------- 401 - Unauthorized Response validations-------------------
		
		@Test(groups={"unAuthorized","full"})
		public void migrationSecFilingsXBRL401() {
			migrationRequest.validateUnauthorizedStatus();		
		}
		
		
		//-------------------------- 403 - Forbidden Response validations----------------------
		
		@Test(groups={"forbidden","full"})
		public void migrationSecFilingsXBRL403() {
			migrationRequest.validateForbiddenStatus();
		}
		
		
		//-------------------------- 400 - Bad Request Response validations--------------------
		
		@Test(groups={"badRequests","full"})
		public void migrationSecFilingsXBRLInvalidClient400() {
			
			//with Invalid client id, valid Accession number
			RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
			migrationRequest.get(badClient, "/"+secAccessionNumberValid+ "/xbrl", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
			
		}
		

		@Test(groups={"badRequests","full"})		
		public void migrationInvalidAccNum400() {
			
			//with invalid Accession number
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			migrationRequest.get("/"+secAccessionNumberInvalid+ "/xbrl", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
			
		}

				
		//-------------------------- 404 - Not Found Response validations--------------------
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationNews_InvalidAPIroute404() {
			
			// Invalid API route
			RequestSpecBuilder reqSB = new RequestSpecBuilder();
			migrationRequest.get("/"+secAccessionNumberValid+ "/zzz"+"/xbrl", reqSB, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationNews_IncompleteAPIroute404() {
			
			//Incomplete API Route
			RequestSpecBuilder reqSB = new RequestSpecBuilder();
			migrationRqst_IncompleteRoute.get("", reqSB, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		//-------------------------- 405 - Method Not Allowed validations-----------------------
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationNews_post_MthdNtAlwd405() {
			// Method not allowed for POST
			migrationRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationNews_put_MthdNtAlwd405() {
			// Method not allowed for PUT
			migrationRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationNews_delete_MthdNtAlwd405() {
			// Method not allowed for DELETE
			migrationRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
				
		//-------------------------- JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidation","smoke","full"})
		public void migrationNewsSchemaValidation() {
			
			//Request specification with query parameters
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			
			//Response specification with response body validations
			ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
			respSB.expectBody(matchesJsonSchema(new File(migrationRequest.getBasicLF_SchemaPath())));
			
			
			//Basic schema validations for migration SecFilings-XBRL end point
			migrationRequest.get("/"+secAccessionNumberValid+ "/xbrl", reqSpec, HttpStatus.SC_OK, respSB);

		}
		
		//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidationDetailed","full"})
		public void migration_SecFilingsXBRL_SchemaValidationDetailed() {
			
			RequestSpecBuilder reqSpecMigSecFilXBRL = new RequestSpecBuilder();
			
			
			String migrationSecFilXBRLSchemaLocation = Paths.get(migrationRequest.buildSchemaPath("/Migration_SecFilings_XBRL.json")).toString();		
			
			ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
			respSpecBuilder.expectBody(matchesJsonSchema(new File(migrationSecFilXBRLSchemaLocation)));
			
			
			//Basic schema validations for migration SecFilings-XBRL end point
			migrationRequest.get("/"+secAccessionNumberValid+ "/xbrl", reqSpecMigSecFilXBRL, HttpStatus.SC_OK, respSpecBuilder);


		}
		

}
