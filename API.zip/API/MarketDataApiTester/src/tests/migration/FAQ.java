package tests.migration;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import api.ApiRequestType;
import api.RequestFactory;
import api.migration.IMigrationRequest;

public class FAQ {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
		
	IMigrationRequest migrationRequest;
	IMigrationRequest migrationRqst_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		migrationRequest = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "FAQ");
		migrationRqst_IncompleteSeg = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "FA");
	}
	
	
	//Added by Puneeth 20160513
	//-------------------------- 200 - OK Response validations-----------------------------
	
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFAQ_200() {
			
			//200 - OK test for Migration FAQ - end point
			//No filter criteria for FAQ endpoint needed
			RequestSpecBuilder reqSpecFAQList = new RequestSpecBuilder();
			migrationRequest.get("", reqSpecFAQList, HttpStatus.SC_OK, null);
		}
		
				
		//-------------------------- 401 - Unauthorized Response validations-------------------
		
		@Test(groups={"unAuthorized","full"})
		public void migrationFAQ_401() {
			migrationRequest.validateUnauthorizedStatus();
		}
		
		
		//-------------------------- 403 - Forbidden Response validations----------------------
		
		@Test(groups={"forbidden","full"})
		public void migrationFAQ_403() {
			migrationRequest.validateForbiddenStatus();
		}

		
		//-------------------------- 400 - Bad Request Response validations--------------------
		
		@Test(groups={"badRequests","full"})
		public void migrationFAQ_InvalidClient400() {
			
			//with Invalid client id
			RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
			migrationRequest.get(badClient, "", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		
		//-------------------------- 404 - Not Found Response validations--------------------
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationFAQ_InvalidAPIroute404() {
			
			// For Invalid API route
			RequestSpecBuilder reqSpecFAQList = new RequestSpecBuilder();
			migrationRequest.get("/zzz", reqSpecFAQList, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationFAQ_IncompleteSegment404() {
			
			// For Incomplete API segment
			RequestSpecBuilder reqSpecFAQList = new RequestSpecBuilder();
			migrationRqst_IncompleteSeg.get("", reqSpecFAQList, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		
		//-------------------------- 404 - Not Found Response validations--------------------
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationFAQ_InvalidAPIroute404_1() {
			
			// For Invalid API route
			RequestSpecBuilder reqSpecFAQList = new RequestSpecBuilder();
			migrationRequest.get("/zzz", reqSpecFAQList, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationFAQ_IncompleteSegment404_2() {
			
			// For Incomplete API segment
			RequestSpecBuilder reqSpecFAQList = new RequestSpecBuilder();
			migrationRqst_IncompleteSeg.get("", reqSpecFAQList, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		//-------------------------- 405 - Method Not Allowed validations-----------------------
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationFAQ_post_MthdNtAlwd405() {
			
			migrationRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationFAQ_put_MthdNtAlwd405() {
			
			migrationRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationFAQ_delete_MthdNtAlwd405() {
			
			migrationRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
	//-------------------------- JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidation","smoke","full"})
		public void migrationFAQ_SchemaValidation() {
			
			RequestSpecBuilder reqSpecFAQList = new RequestSpecBuilder();
			
			//Response specification with response body validations
			ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
			respSB.expectBody(matchesJsonSchema(new File(migrationRequest.getBasicLF_SchemaPath())));
			
			
			//Basic schema validations for Migration FAQ for Phx end point
			migrationRequest.get("", reqSpecFAQList, HttpStatus.SC_OK, respSB);


		}
		
		
		//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidationDetailed","full"})
		public void migrationFAQ_SchemaValidationDetailed() {
			
			RequestSpecBuilder reqSpecMigrationFAQ = new RequestSpecBuilder();
			
			String MigrationFAQSchemaLocation = Paths.get(migrationRequest.buildSchemaPath("/Migration_FAQ_Phx.json")).toString();		
			
			ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
			respSpecBuilder.expectBody(matchesJsonSchema(new File(MigrationFAQSchemaLocation)));
			
			//Basic schema validations for Migration FAQ end point
			migrationRequest.get("", reqSpecMigrationFAQ, HttpStatus.SC_OK, respSpecBuilder);
		}
}
