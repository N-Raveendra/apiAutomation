package tests.migration;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import api.ApiRequestType;
import api.RequestFactory;
import api.migration.IMigrationRequest;

public class DividendsSplits {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
		
	IMigrationRequest migrationRequest;
	IMigrationRequest migrationRqst_IncompleteRoute;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		migrationRequest = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "DividendsAndSplits");		
		migrationRqst_IncompleteRoute = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "DividendsAndSpli");
	}
	
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	//Added by Puneeth - 20160502
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationDivSplits200() {
			
			//200 - OK test for Migration Dividends and Splits end point
			RequestSpecBuilder reqSpecDivSplits = new RequestSpecBuilder();
			reqSpecDivSplits.addQueryParam("dlu", "1456790400").and()
								.addQueryParam("limit", "1");
			
			migrationRequest.get("", reqSpecDivSplits, HttpStatus.SC_OK, null);	
		}
		
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationDivSplitsWithoutDLU200() {
			
			//200 - OK test for Migration Dividends and Splits end point		
			//without DLU 
			RequestSpecBuilder reqSpecNoDLU = new RequestSpecBuilder();
			reqSpecNoDLU.addQueryParam("limit", "1");
			
			migrationRequest.get("", reqSpecNoDLU, HttpStatus.SC_OK, null);
		}
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationDivSplitsWithoutLimit200() {
			//200 - OK test for Migration Dividends and Splits end point		
			//without Limit
			RequestSpecBuilder reqSpecNoLimit = new RequestSpecBuilder();
			reqSpecNoLimit.addQueryParam("dlu", "1456790400");
			
			migrationRequest.get("", reqSpecNoLimit, HttpStatus.SC_OK, null);
		}
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationDivSplitsWithoutLimitAndDlu200() {
			//200 - OK test for Migration Dividends and Splits end point		
			//without Limit and DLU
			RequestSpecBuilder reqSpecNoLimitDlu = new RequestSpecBuilder();
					
			migrationRequest.get("", reqSpecNoLimitDlu, HttpStatus.SC_OK, null);
		}
		
		//-------------------------- 401 - Unauthorized Response validations-------------------
		
		@Test(groups={"unAuthorized","full"})
		public void migrationDivSplits401() {
			migrationRequest.validateUnauthorizedStatus();
		}
		
		
		//-------------------------- 403 - Forbidden Response validations----------------------
		
		@Test(groups={"forbidden","full"})
		public void migrationDivSplits403() {
			migrationRequest.validateForbiddenStatus();
		}

		
		//-------------------------- 400 - Bad Request Response validations--------------------
		
		@Test(groups={"badRequests","full"})
		public void migrationDivSplitsInvalidClient400() {
			
			//with Invalid client id
			RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
			reqSpecInvalidClient.addQueryParam("DLU", "1456790400").and()
						  .addQueryParam("limit", "1");
			
			migrationRequest.get(badClient, "", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationDivSplitsInvalidDLU400() {
			
			//with invalid DLU - DLU date prior to 1 Jan, 1970(any negative)
			RequestSpecBuilder reqSpecOldDLU = new RequestSpecBuilder();
			reqSpecOldDLU.addQueryParam("dlu", "-121132800").and()
							.addQueryParam("limit", "1");
			
			migrationRequest.get("", reqSpecOldDLU, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationDivSplitsFutureDLU400() {
			
			//with Future DLU - DLU date that is later than today's date Year - 2022
			RequestSpecBuilder reqSpecOldDLU = new RequestSpecBuilder();
			reqSpecOldDLU.addQueryParam("dlu", "1652033612").and()
							.addQueryParam("limit", "1");
			
			migrationRequest.get("", reqSpecOldDLU, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationDivSplitsVeryOldDLU400() {
			
			//with Future DLU - DLU date that is later than today's date Year - 2022
			RequestSpecBuilder reqSpecOldDLU = new RequestSpecBuilder();
			reqSpecOldDLU.addQueryParam("dlu", "-52033612").and()
							.addQueryParam("limit", "1");
			
			migrationRequest.get("", reqSpecOldDLU, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationDivSplitsInvalidLimit400() {
			
			//Invalid Limit-anything alphanumeric
			RequestSpecBuilder reqSpecOldDLU = new RequestSpecBuilder();
			reqSpecOldDLU.addQueryParam("dlu", "1430936012").and()
							.addQueryParam("limit", "1abc");
			
			migrationRequest.get("", reqSpecOldDLU, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationDivSplitsNegativeLimit400() {
			
			//Invalid Limit-anything negative
			RequestSpecBuilder reqSpecNegativeLimit = new RequestSpecBuilder();
			reqSpecNegativeLimit.addQueryParam("dlu", "1430936012").and()
							.addQueryParam("limit", "-2");
			
			migrationRequest.get("", reqSpecNegativeLimit, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationDivSplitsLimitAsZero400() {
			
			//Limit passed as ZERO
			RequestSpecBuilder reqSpecOldDLU = new RequestSpecBuilder();
			reqSpecOldDLU.addQueryParam("dlu", "1430936012").and()
							.addQueryParam("limit", "0");
			
			migrationRequest.get("", reqSpecOldDLU, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		//-------------------------- 404 - Not Found Response validations--------------------
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationDivSplits_InvalidAPIroute404() {
			
			// For Invalid API route
			RequestSpecBuilder reqSpecDivSplits = new RequestSpecBuilder();
			reqSpecDivSplits.addQueryParam("dlu", "1456790400").and()
						  .addQueryParam("limit", "1");
			
			migrationRequest.get("/zzz", reqSpecDivSplits, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationDivSplits_IncompleteAPIroute404() {
			//Incomplete API Route
			RequestSpecBuilder reqSB = new RequestSpecBuilder();
			reqSB.addQueryParam("dlu", "1426068035").and()
				.addQueryParam("limit", "1");
			migrationRqst_IncompleteRoute.get("", reqSB, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		//-------------------------- 405 - Method Not Allowed validations-----------------------
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationDivSplits_post_MthdNtAlwd405() {
			
			migrationRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationDivSplits_put_MthdNtAlwd405() {
			
			migrationRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationDivSplits_delete_MthdNtAlwd405() {
			
			migrationRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}

		//-------------------------- JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidation","smoke","full"})
		public void migrationDivSplitsSchemaValidation() {
			
			RequestSpecBuilder reqSpecDivSplits = new RequestSpecBuilder();
			reqSpecDivSplits.addQueryParam("dlu", "1456790400").and()
						  .addQueryParam("limit", "1");
			
			
			//Response specification with response body validations
			ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
			respSB.expectBody(matchesJsonSchema(new File(migrationRequest.getBasicLF_SchemaPath())));
			
			
			//Basic schema validations for Migration Dividends and Splits end point
			migrationRequest.get("", reqSpecDivSplits, HttpStatus.SC_OK, respSB);


		}
		

		//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidationDetailed","full"})
		public void migrationDivSplits_SchemaValidationDetailed() {
			
			RequestSpecBuilder reqSpecMigrationAssets = new RequestSpecBuilder();
			reqSpecMigrationAssets.addQueryParam("dlu", "1456790400").and()
			.addQueryParam("limit", "1");
			
			//Needs modification
			String MigrationDivSplitsSchemaLocation = Paths.get(migrationRequest.buildSchemaPath("/Migration_Div-Splits.json")).toString();		
			
			ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
			respSpecBuilder.expectBody(matchesJsonSchema(new File(MigrationDivSplitsSchemaLocation)));
			
			
			//Basic schema validations for Latest SEC Filings end point
			migrationRequest.get("", reqSpecMigrationAssets, HttpStatus.SC_OK, respSpecBuilder);


		}

	
}
