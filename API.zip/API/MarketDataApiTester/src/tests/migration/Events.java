package tests.migration;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import api.ApiRequestType;
import api.RequestFactory;
import api.migration.IMigrationRequest;

public class Events {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
		
	IMigrationRequest migrationRequest;
	IMigrationRequest migrationRqst_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		migrationRequest = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "events");
		migrationRqst_IncompleteSeg = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "even");
	}
	
	
	//Added by Puneeth on 20160519
	//-------------------------- 200 - OK Response validations-----------------------------
	
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationEventsWithDLUAndLimit200() {
			
			//200 - OK test for Migration Events end point
			//with limit and dlu
			RequestSpecBuilder reqSpecEvents = new RequestSpecBuilder();
			reqSpecEvents.addQueryParam("dlu", "1426068035").and()
						.addQueryParam("limit", "2");
			migrationRequest.get("", reqSpecEvents, HttpStatus.SC_OK, null);
			
		}
				
				
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationEventsWithoutdlu200() {
			
			//without dlu
			RequestSpecBuilder reqSpecNodlu = new RequestSpecBuilder();
			reqSpecNodlu.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecNodlu, HttpStatus.SC_OK, null);
				
		}
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationEventsDluAsZero200() {
			
			//dlu passed as 0
			RequestSpecBuilder reqSpecDluZero = new RequestSpecBuilder();
			reqSpecDluZero.addQueryParam("dlu", "0").and()
						.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecDluZero, HttpStatus.SC_OK, null);
				
		}
				
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationEventsWithoutLimit200() {
			
			//Missing limit
			RequestSpecBuilder reqSpecEvents = new RequestSpecBuilder();
			reqSpecEvents.addQueryParam("dlu", "1426068035");
			migrationRequest.get("", reqSpecEvents, HttpStatus.SC_OK, null);

		}
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationEventsNoFilter200() {
			
			//Missing limit and DLU
			RequestSpecBuilder reqSpecEvents = new RequestSpecBuilder();
			migrationRequest.get("", reqSpecEvents, HttpStatus.SC_OK, null);

		}
		
		//-------------------------- 401 - Unauthorized Response validations-------------------
		
		@Test(groups={"unAuthorized","full"})
		public void migrationEvents401() {
			migrationRequest.validateUnauthorizedStatus();
		}
		
		
		//-------------------------- 403 - Forbidden Response validations----------------------
		
		@Test(groups={"forbidden","full"})
		public void migrationEvents403() {
			migrationRequest.validateForbiddenStatus();
		}

		
		//-------------------------- 400 - Bad Request Response validations--------------------
		
		@Test(groups={"badRequests","full"})
		public void migrationEventsInvalidClient400() {
			
			//with Invalid client id
			RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
			reqSpecInvalidClient.addQueryParam("dlu", "1426068035").and()
						  		.addQueryParam("limit", "1");
			migrationRequest.get(badClient, "", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		
		@Test(groups={"badRequests","full"})		
		public void migrationEventsFutureDlu400() {
			
			//with FUTURE dlu
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("dlu", "1652515544").and()
					  		.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		
		@Test(groups={"badRequests","full"})
		public void migrationEventsVeryOldDlu400() {
			
			//with invalid - VERY OLD dlu
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("dlu", "-55619539").and()
					  		.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationEventsAlphaNumericDlu400() {
			
			//with ALPHANUMERIC dlu
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("dlu", "abc123").and()
					  		.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationEventsAlphaNumericLimit400() {
			
			//Alphanumeric Limit	
			RequestSpecBuilder reqSpecInvalidLimit = new RequestSpecBuilder();
			reqSpecInvalidLimit.addQueryParam("dlu", "1463213144").and()
					  		.addQueryParam("limit", "abc123");
			migrationRequest.get("", reqSpecInvalidLimit, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationEventsLimitAsZero400() {
			
			//Limit	as ZERO
			RequestSpecBuilder reqSpecInvalidLimit = new RequestSpecBuilder();
			reqSpecInvalidLimit.addQueryParam("dlu", "1463213144").and()
					  		.addQueryParam("limit", "0");
			migrationRequest.get("", reqSpecInvalidLimit, HttpStatus.SC_BAD_REQUEST, null);
				
		}
	

		//-------------------------- 404 - Not Found Response validations--------------------
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationEvents_InvalidAPIroute404() {
			
			// For Invalid API route
			RequestSpecBuilder reqSpecEvents = new RequestSpecBuilder();
			reqSpecEvents.addQueryParam("dlu", "1426068035").and()
		  					.addQueryParam("limit", "1");
			migrationRequest.get("/zzz", reqSpecEvents, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationEvents_IncompleteSegment404() {
			
			// For Incomplete API segment
			RequestSpecBuilder reqSpecEvents = new RequestSpecBuilder();
			reqSpecEvents.addQueryParam("dlu", "1426068035").and()
		  					.addQueryParam("limit", "1");
			migrationRqst_IncompleteSeg.get("", reqSpecEvents, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		//-------------------------- 405 - Method Not Allowed validations-----------------------
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationEvents_post_MthdNtAlwd405() {
			
			migrationRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationEvents_put_MthdNtAlwd405() {
			
			migrationRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationEvents_delete_MthdNtAlwd405() {
			
			migrationRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}

		//-------------------------- JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidation","smoke","full"})
		public void migrationEventsSchemaValidation() {
			
			RequestSpecBuilder reqSpecEvents = new RequestSpecBuilder();
			reqSpecEvents.addQueryParam("dlu", "1426068035").and()
		  					.addQueryParam("limit", "1");
			
			
			//Response specification with response body validations
			ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
			respSB.expectBody(matchesJsonSchema(new File(migrationRequest.getBasicLF_SchemaPath())));
			
			
			//Basic schema validations for Events end point
			migrationRequest.get("", reqSpecEvents, HttpStatus.SC_OK, respSB);
		}
		
		
		//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidationDetailed","full"})
		public void migrationEvents_SchemaValidationDetailed() {
			
			RequestSpecBuilder Events = new RequestSpecBuilder();
			Events.addQueryParam("dlu", "1426068035").and()
			.addQueryParam("limit", "1");
			
			//Needs modification
			String MigrationPhxGovComSchemaLocation = Paths.get(migrationRequest.buildSchemaPath("/Migration_Events.json")).toString();		
			
			ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
			respSpecBuilder.expectBody(matchesJsonSchema(new File(MigrationPhxGovComSchemaLocation)));
			
			//Basic schema validations for Events end point
			migrationRequest.get("", Events, HttpStatus.SC_OK, respSpecBuilder);
		}
}
