package tests.migration;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import api.ApiRequestType;
import api.RequestFactory;
import api.migration.IMigrationRequest;


public class NewsCategories {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";

	IMigrationRequest migrationRequest;		// variable for migration request
	IMigrationRequest migrationRqst_IncompleteRoute;		// variable for incomplete migration route
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		migrationRequest = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "NewsCategories");
		migrationRqst_IncompleteRoute = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "");	
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationNewsCat200() {
			
			//200 - OK test for migration/NewsCategories end point
			//with valid dlu and limit
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			reqSpec.addQueryParam("dlu", "1426068035").and()
					.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpec, HttpStatus.SC_OK, null);
			
		}
		
		@Test(groups={"getOk","full", "migration"})
		public void migrationNewsCatWithoutdlu200() {
			
			//without dlu, with limit
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			reqSpec.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpec, HttpStatus.SC_OK, null);
			
		}
		
		@Test(groups={"getOk","full", "migration"})
		public void migrationNewsCatWithoutLimit200() {
			
			//without limit, with dlu
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			reqSpec.addQueryParam("dlu", "1426068035");
			migrationRequest.get("", reqSpec, HttpStatus.SC_OK, null);
			
		}
		
		@Test(groups={"getOk","full", "migration"})
		public void migrationNewsCatWithoutQueryParam200() {
			
			//without any of the query parameter
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			migrationRequest.get("", reqSpec, HttpStatus.SC_OK, null);
			
		}
				
		
		//-------------------------- 401 - Unauthorized Response validations-------------------
		
		@Test(groups={"unAuthorized","full"})
		public void migrationNewsCat401() {
			migrationRequest.validateUnauthorizedStatus();		
		}
		
		
		//-------------------------- 403 - Forbidden Response validations----------------------
		
		@Test(groups={"forbidden","full"})
		public void migrationNewsCat403() {
			migrationRequest.validateForbiddenStatus();
		}
		
		
		//-------------------------- 400 - Bad Request Response validations--------------------
		
		@Test(groups={"badRequests","full"})
		public void migrationNewsCatInvalidClient400() {
			
			//with Invalid client id, valid dlu and valid limit
			RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
			reqSpecInvalidClient.addQueryParam("dlu", "1426068035").and()
								.addQueryParam("limit", "1");
			migrationRequest.get(badClient, "", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
			
		}
		

		@Test(groups={"badRequests","full"})		
		public void migrationNewsCatFutureDlu400() {
			
			//with future dlu and valid limit
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("dlu", "1522751003").and()
							.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
			
		}

		
		@Test(groups={"badRequests","full"})
		public void migrationNewsCatVeryOldDlu400() {
			
			//with dlu date older than Jan-01-1970 and valid limit
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("dlu", "-618494248").and()
							.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
			
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationNewsCat_AlphaNumDlu400() {
			
			//with Alphanumeric dlu and valid limit
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			reqSpec.addQueryParam("dlu", "sdfd11").and()
					.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
			
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationNewsCat_AlphaNumLimit400() {
			
			//with valid dlu and Alphanumeric limit
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			reqSpec.addQueryParam("dlu", "1426068035").and()
					.addQueryParam("limit", "abc123");
			migrationRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
			
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationNewsCat_NegativeLimit400() {
			
			//with valid dlu and Negative limit
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			reqSpec.addQueryParam("dlu", "1426068035").and()
					.addQueryParam("limit", "-1");
			migrationRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
			
		}
		
				
		//-------------------------- 404 - Not Found Response validations--------------------
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationNewsCat_InvalidAPIroute404() {
			
			// Invalid API route
			RequestSpecBuilder reqSB = new RequestSpecBuilder();
			reqSB.addQueryParam("dlu", "1426068035").and()
				.addQueryParam("limit", "1");
			migrationRequest.get("/zzz", reqSB, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationNewsCat_IncompleteAPIroute404() {
			
			//Incomplete API Route
			RequestSpecBuilder reqSB = new RequestSpecBuilder();
			reqSB.addQueryParam("dlu", "1426068035").and()
				.addQueryParam("limit", "1");
			migrationRqst_IncompleteRoute.get("", reqSB, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		//-------------------------- 405 - Method Not Allowed validations-----------------------
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationNewsCat_post_MthdNtAlwd405() {
			// Method not allowed for POST
			migrationRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationNewsCat_put_MthdNtAlwd405() {
			// Method not allowed for PUT
			migrationRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationNewsCat_delete_MthdNtAlwd405() {
			// Method not allowed for DELETE
			migrationRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
				
		//-------------------------- JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidation","smoke","full"})
		public void migrationNewsCatSchemaValidation() {
			
			//Request specification with query parameters
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			reqSpec.addQueryParam("dlu", "1426068035").and()
					.addQueryParam("limit", "1");
			
			//Response specification with response body validations
			ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
			respSB.expectBody(matchesJsonSchema(new File(migrationRequest.getBasicLF_SchemaPath())));
			
			
			//Basic schema validations for NewsCategories end point
			migrationRequest.get("", reqSpec, HttpStatus.SC_OK, respSB);

		}
		
		//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidationDetailed","full"})
		public void migration_NewsCat_SchemaValidationDetailed() {
			
			RequestSpecBuilder reqSpecMigNewsCat = new RequestSpecBuilder();
			reqSpecMigNewsCat.addQueryParam("dlu", "1426068035").and()
						.addQueryParam("limit", "5");
			
			
			String migrationNewsCatSchemaLocation = Paths.get(migrationRequest.buildSchemaPath("/Migration_NewsCategories.json")).toString();		
			
			ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
			respSpecBuilder.expectBody(matchesJsonSchema(new File(migrationNewsCatSchemaLocation)));
			
			
			//Basic schema validations for NewsCategories end point
			migrationRequest.get("", reqSpecMigNewsCat, HttpStatus.SC_OK, respSpecBuilder);


		}
		

}

