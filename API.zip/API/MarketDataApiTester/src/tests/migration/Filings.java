package tests.migration;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import api.ApiRequestType;
import api.RequestFactory;
import api.migration.IMigrationRequest;

public class Filings {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
		
	IMigrationRequest migrationRequest;
	IMigrationRequest migrationRqst_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		migrationRequest = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "SecFilings");
		migrationRqst_IncompleteSeg = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "SecFiling");
	}
	
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilingsWithCIKList200() {
			
			//200 - OK test for latest SEC end point
			//with CIK list (2 CIKs), limit and dlu
			RequestSpecBuilder reqSpecCIKList = new RequestSpecBuilder();
			reqSpecCIKList.addQueryParam("CIKs", "77476||36104").and()
						  .addQueryParam("dlu", "1426068035").and()
						.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecCIKList, HttpStatus.SC_OK, null);
			
		}
		
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilingsWithSingleCIK200() {
			
			//200 - OK test for latest SEC end point		
			//with Single CIK, limit and dlu
			RequestSpecBuilder reqSpecSingleCIK = new RequestSpecBuilder();
			reqSpecSingleCIK.addQueryParam("CIKs", "1018724").and()
							.addQueryParam("dlu", "1426068035").and()
							.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecSingleCIK, HttpStatus.SC_OK, null);

		}
		
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilingsWithMultipleCIK200() {
			
			//with multiple CIKs, limit and dlu 
			RequestSpecBuilder reqSpecMultipleCIK = new RequestSpecBuilder();
			reqSpecMultipleCIK.addQueryParam("CIKs", "77476||36104||1018724").and()
							  .addQueryParam("dlu", "1426068035").and()
								.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecMultipleCIK, HttpStatus.SC_OK, null);

		}

		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilingsWithInvalidCIK200() {
			
			//with invalid CIKs and dlu and limit
			RequestSpecBuilder reqSpecMultipleCIK = new RequestSpecBuilder();
			reqSpecMultipleCIK.addQueryParam("CIKs", "7").and()
							  .addQueryParam("dlu", "1426068035").and()
								.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecMultipleCIK, HttpStatus.SC_OK, null);

		}
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilingsWithoutdlu200() {
			
			//without dlu
			RequestSpecBuilder reqSpecNodlu = new RequestSpecBuilder();
			reqSpecNodlu.addQueryParam("CIKs", "77476||36104").and()
						.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecNodlu, HttpStatus.SC_OK, null);
				
		}
				
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilingsWithoutLimit200() {
			
			//with valid CIKs and dlu and Missing limit
			RequestSpecBuilder reqSpecMultipleCIK = new RequestSpecBuilder();
			reqSpecMultipleCIK.addQueryParam("CIKs", "77476").and()
							  .addQueryParam("dlu", "1426068035");
			migrationRequest.get("", reqSpecMultipleCIK, HttpStatus.SC_OK, null);

		}
		
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilings_HTML_200() {
			
			//HTML version of migration/secfilings endpoint
			RequestSpecBuilder reqSpecMultipleCIK = new RequestSpecBuilder();
			
			migrationRequest.get("0001299933-15-000386/html", reqSpecMultipleCIK, HttpStatus.SC_OK, null);

		}
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilings_XLS_200() {
			
			//HTML version of migration/secfilings endpoint
			RequestSpecBuilder reqSpecMultipleCIK = new RequestSpecBuilder();

			migrationRequest.get("0001299933-15-000386/xls", reqSpecMultipleCIK, HttpStatus.SC_OK, null);

		}

		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilings_PDF_200() {
			
			//HTML version of migration/secfilings endpoint
			RequestSpecBuilder reqSpecMultipleCIK = new RequestSpecBuilder();
			
			migrationRequest.get("0001299933-15-000386/pdf", reqSpecMultipleCIK, HttpStatus.SC_OK, null);

		}

		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationFilings_RTF_200() {
			
			//HTML version of migration/secfilings endpoint
			RequestSpecBuilder reqSpecMultipleCIK = new RequestSpecBuilder();
			
			migrationRequest.get("0001299933-15-000386/rtf", reqSpecMultipleCIK, HttpStatus.SC_OK, null);

		}
		
		
		//-------------------------- 401 - Unauthorized Response validations-------------------
		
		@Test(groups={"unAuthorized","full"})
		public void migrationFilings401() {
			migrationRequest.validateUnauthorizedStatus();
		}
		
		
		//-------------------------- 403 - Forbidden Response validations----------------------
		
		@Test(groups={"forbidden","full"})
		public void migrationFilings403() {
			migrationRequest.validateForbiddenStatus();
		}

		
		//-------------------------- 400 - Bad Request Response validations--------------------
		
		@Test(groups={"badRequests","full"})
		public void migrationFilingsInvalidClient400() {
			
			//with Invalid client id
			RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
			reqSpecInvalidClient.addQueryParam("CIKs", "77476||36104").and()
						  		.addQueryParam("dlu", "1426068035").and()
						  		.addQueryParam("limit", "1");
			migrationRequest.get(badClient, "", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		
		@Test(groups={"badRequests","full"})		
		public void migrationSecFutureDlu400() {
			
			//with invalid dlu
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("CIKs", "77476||36104").and()
						  	.addQueryParam("dlu", "1651739433").and()
					  		.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		
		@Test(groups={"badRequests","full"})
		public void migrationFilingsVeryOldDlu400() {
			
			//with invalid - Old Dlu
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("CIKs", "77476||36104").and()
						  	.addQueryParam("dlu", "-55619539").and()
					  		.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationFilingsFutureDlu400() {
			
			//with invalid - Future Dlu
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("CIKs", "77476||36104").and()
						  	.addQueryParam("dlu", "1517388690").and()
					  		.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationFilingsAlphaNumericDlu400() {
			
			//with invalid dlu
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("CIKs", "77476||36104").and()
						  	.addQueryParam("dlu", "abc123").and()
					  		.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationFilingsAlphaNumericLimit400() {
			
			//Invalid Limit	
			RequestSpecBuilder reqSpecInvaliddlu = new RequestSpecBuilder();
			reqSpecInvaliddlu.addQueryParam("CIKs", "77476||36104").and()
						  	.addQueryParam("dlu", "1426068035").and()
					  		.addQueryParam("limit", "abc123");
			migrationRequest.get("", reqSpecInvaliddlu, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationFilingsWithoutCIK400() {
			
			//without CIK
			RequestSpecBuilder reqSpecNoCIK = new RequestSpecBuilder();
			reqSpecNoCIK.addQueryParam("dlu", "1426068035").and()
	  					.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecNoCIK, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		
		@Test(groups={"badRequests","full"})
		public void migrationFilingsWithoutQueryParm400() {
			
			//without CIK, limit and dlu
			migrationRequest.get("", null, HttpStatus.SC_BAD_REQUEST, null);
				
		}

		
		//-------------------------- 404 - Not Found Response validations--------------------
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationFilings_InvalidAPIroute404() {
			
			// For Invalid API route
			RequestSpecBuilder reqSpecCIKList = new RequestSpecBuilder();
			reqSpecCIKList.addQueryParam("CIKs", "77476||36104").and()
						  .addQueryParam("dlu", "1426068035").and()
		  					.addQueryParam("limit", "1");
			migrationRequest.get("/zzz", reqSpecCIKList, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		@Test(groups={"notFound","smoke","full"})
		public void migrationFilings_IncompleteSegment404() {
			
			// For Incomplete API segment
			RequestSpecBuilder reqSpecCIKList = new RequestSpecBuilder();
			reqSpecCIKList.addQueryParam("CIKs", "77476||36104").and()
						  .addQueryParam("dlu", "1426068035").and()
		  					.addQueryParam("limit", "1");
			migrationRqst_IncompleteSeg.get("", reqSpecCIKList, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		//-------------------------- 405 - Method Not Allowed validations-----------------------
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationFilings_post_MthdNtAlwd405() {
			
			migrationRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationFilings_put_MthdNtAlwd405() {
			
			migrationRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationFilings_delete_MthdNtAlwd405() {
			
			migrationRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}

		//-------------------------- JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidation","smoke","full"})
		public void migrationFilingsSchemaValidation() {
			
			RequestSpecBuilder reqSpecCIKList = new RequestSpecBuilder();
			reqSpecCIKList.addQueryParam("CIKs", "77476||36104").and()
						  .addQueryParam("dlu", "1426068035").and()
		  					.addQueryParam("limit", "1");
			
			
			//Response specification with response body validations
			ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
			respSB.expectBody(matchesJsonSchema(new File(migrationRequest.getBasicLF_SchemaPath())));
			
			
			//Basic schema validations for SEC Filings end point
			migrationRequest.get("", reqSpecCIKList, HttpStatus.SC_OK, respSB);


		}
		
		
		//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidationDetailed","full"})
		public void migrationFilings_SchemaValidationDetailed() {
			
			RequestSpecBuilder reqSpecMigrationFilings = new RequestSpecBuilder();
			reqSpecMigrationFilings.addQueryParam("CIKs", "77476").and()
			  .addQueryParam("dlu", "1426068035").and()
			.addQueryParam("limit", "1");
			
			//Needs modification
			String MigrationFilingsSchemaLocation = Paths.get(migrationRequest.buildSchemaPath("/Migration_SECFilings.json")).toString();		
			
			ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
			respSpecBuilder.expectBody(matchesJsonSchema(new File(MigrationFilingsSchemaLocation)));
			
			
			//Basic schema validations for Latest SEC Filings end point
			migrationRequest.get("", reqSpecMigrationFilings, HttpStatus.SC_OK, respSpecBuilder);
		}
}
