package tests.migration;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import api.ApiRequestType;
import api.RequestFactory;
import api.migration.IMigrationRequest;

public class Assets {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
		
	IMigrationRequest migrationRequest;
	IMigrationRequest migrationRequest_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		migrationRequest = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "Assets");
		migrationRequest_IncompleteSeg = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	//Added by Puneeth 20160502
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationAssets200() {
			
			//200 - OK test for Migration Assets end point		
			RequestSpecBuilder reqSpecAssets = new RequestSpecBuilder();
			reqSpecAssets.addQueryParam("dlu", "1456790400").and()
							.addQueryParam("limit", "1");
			migrationRequest.get("", reqSpecAssets, HttpStatus.SC_OK, null);
		}
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationAssetsWithoutDLU200() {
			
			//200 - OK test for Migration Assets end point		
			//without DLU
			RequestSpecBuilder reqSpecAssetsNoDLU = new RequestSpecBuilder();
			
			reqSpecAssetsNoDLU.addQueryParam("limit", "1");
			
			migrationRequest.get("", reqSpecAssetsNoDLU, HttpStatus.SC_OK, null);
		}
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationAssetsWithoutLimit200() {
			
			//200 - OK test for Migration Assets end point		
			//without LIMIT
			RequestSpecBuilder reqSpecAssetsNolimit = new RequestSpecBuilder();
			
			reqSpecAssetsNolimit.addQueryParam("dlu", "1456790400");
			
			migrationRequest.get("", reqSpecAssetsNolimit, HttpStatus.SC_OK, null);
		}
		
		@Test(groups={"getOk","smoke","full", "migration"})
		public void migrationAssetsWithoutLimitAndDlu200() {
			
			//200 - OK test for Migration Assets end point		
			//without LIMIT and DLU
			RequestSpecBuilder reqSpecAssetsNolimitNoDlu = new RequestSpecBuilder();
			
			//reqSpecAssetsNolimit.addQueryParam("dlu", "1456790400");
			
			migrationRequest.get("", reqSpecAssetsNolimitNoDlu, HttpStatus.SC_OK, null);
		}

		
		//-------------------------- 401 - Unauthorized Response validations-------------------
		
		@Test(groups={"unAuthorized","full"})
		public void migrationAssets401() {
			migrationRequest.validateUnauthorizedStatus();
		}
		
		
		//-------------------------- 403 - Forbidden Response validations----------------------
		
		@Test(groups={"forbidden","full"})
		public void migrationAssets403() {
			migrationRequest.validateForbiddenStatus();
		}

		
		//-------------------------- 400 - Bad Request Response validations--------------------
		
		@Test(groups={"badRequests","full"})
		public void migrationAssetsInvalidClient400() {
			
			//with Invalid client id
			RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
			reqSpecInvalidClient.addQueryParam("modifiedSince", "2016-03-01");
			migrationRequest.get(badClient, "", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
				
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationAssetsInvalidDLU400() {
			
			//with invalid DLU - DLU date prior to 1 Jan, 1970, a negative DLU and alphanumeric DLU
			RequestSpecBuilder reqSpecInvalidDLU = new RequestSpecBuilder();
			reqSpecInvalidDLU.addQueryParam("dlu", "121132800abc").and()
							.addQueryParam("limit", "1");
			
			migrationRequest.get("", reqSpecInvalidDLU, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationAssetsVOldDLU400() {
			
			//with Very Old DLU - DLU date prior to 1 Jan, 1970
			RequestSpecBuilder reqSpecOldDLU = new RequestSpecBuilder();
			reqSpecOldDLU.addQueryParam("dlu", "-121132800").and()
							.addQueryParam("limit", "1");
			
			migrationRequest.get("", reqSpecOldDLU, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationAssetsFutureDLU400() {
			
			//with Future DLU - DLU date that is later than today's date(2022)
			RequestSpecBuilder reqSpecFutureDLU = new RequestSpecBuilder();
			reqSpecFutureDLU.addQueryParam("dlu", "1646092800").and()
							.addQueryParam("limit", "1");
			
			migrationRequest.get("", reqSpecFutureDLU, HttpStatus.SC_BAD_REQUEST, null);
		}

		@Test(groups={"badRequests","full"})
		public void migrationAssetsInvalidLimit400() {
						
					//INVALID Limit - alphanumeric Limit passed
					RequestSpecBuilder reqSpecAssetsInvalidLimit = new RequestSpecBuilder();
					
					reqSpecAssetsInvalidLimit.addQueryParam("limit", "1abc").and()
											.addQueryParam("dlu", "143093601");
					
					migrationRequest.get("", reqSpecAssetsInvalidLimit, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		@Test(groups={"badRequests","full"})
		public void migrationAssetsNegativeLimit400() {
						
					//INVALID Limit - negative Limit passed
					RequestSpecBuilder reqSpecAssetsInvalidLimit = new RequestSpecBuilder();
					
					reqSpecAssetsInvalidLimit.addQueryParam("limit", "-2").and()
											.addQueryParam("dlu", "143093601");
					
					migrationRequest.get("", reqSpecAssetsInvalidLimit, HttpStatus.SC_BAD_REQUEST, null);
		}
		
		//-------------------------- 404 - Not Found Response validations--------------------
		
		//Invalid API Route
		@Test(groups={"notFound","smoke","full"})
		public void migrationAssets_InvalidAPIroute404() {
			
			// For Invalid API route
			RequestSpecBuilder reqSpecAssetsList = new RequestSpecBuilder();
			reqSpecAssetsList.addQueryParam("dlu", "1456790400").and()
								.addQueryParam("limit", "1");
			migrationRequest.get("/zzz", reqSpecAssetsList, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		//Incomplete API segment
		@Test(groups={"notFound","smoke","full"})
		public void migrationAssets_IncompleteSeg404() {
			
			// For Incomplete API segment
			RequestSpecBuilder reqSpecAssetsList = new RequestSpecBuilder();
			reqSpecAssetsList.addQueryParam("dlu", "1456790400").and()
								.addQueryParam("limit", "1");
			migrationRequest_IncompleteSeg.get("", reqSpecAssetsList, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
		//-------------------------- 405 - Method Not Allowed validations-----------------------
		
		//==================POST=======================
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationAssets_post_MthdNtAlwd405() {
			
			migrationRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);		
		}
		
		//==================PUT=======================
		
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationAssets_put_MthdNtAlwd405() {
			
			migrationRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		}
		
		//===================DELETE=======================
		@Test(groups={"mthdNtAlwd","full"})
		public void migrationAssets_delete_MthdNtAlwd405() {
			
			migrationRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		}

		//-------------------------- JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidation","smoke","full"})
		public void migrationAssetsSchemaValidation() {
			
			RequestSpecBuilder reqSpecAssetsList = new RequestSpecBuilder();
			reqSpecAssetsList.addQueryParam("dlu", "1451632452");
			
			
			//Response specification with response body validations
			ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
			respSB.expectBody(matchesJsonSchema(new File(migrationRequest.getBasicLF_SchemaPath())));
			
			
			//Basic schema validations for Migration Assets end point
			migrationRequest.get("", reqSpecAssetsList, HttpStatus.SC_OK, respSB);


		}
		
		//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
		
		@Test(groups={"schemaValidationDetailed","full"})
		public void migrationAssets_SchemaValidationDetailed() {
			
			RequestSpecBuilder reqSpecMigrationAssets = new RequestSpecBuilder();
			reqSpecMigrationAssets.addQueryParam("dlu", "1451632452");
			
			//Needs modification
			String MigrationAssetsSchemaLocation = Paths.get(migrationRequest.buildSchemaPath("/Migration_Assets.json")).toString();		
			
			ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
			respSpecBuilder.expectBody(matchesJsonSchema(new File(MigrationAssetsSchemaLocation)));
			
			
			//Basic schema validations for Assets end point
			migrationRequest.get("", reqSpecMigrationAssets, HttpStatus.SC_OK, respSpecBuilder);


		}
}
