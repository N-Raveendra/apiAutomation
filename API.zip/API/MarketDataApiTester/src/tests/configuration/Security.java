package tests.configuration;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.configuration.IConfigurationRequest;


public class Security {
	
	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IConfigurationRequest configurationRequest;
	IConfigurationRequest ConfigurationRqst_IncompleteRoute;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		configurationRequest = (IConfigurationRequest) RequestFactory.Get(ApiRequestType.Configuration, "Security");
		ConfigurationRqst_IncompleteRoute = (IConfigurationRequest) RequestFactory.Get(ApiRequestType.Configuration, "Secur");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "configuration"})
	public void configurationSecurity200() {	

		configurationRequest.get("", null, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations---------------------
	
	@Test(groups={"unAuthorized","full"})
	public void configurationSecurity401() {
		configurationRequest.validateUnauthorizedStatus();		
	}
	
	//-------------------------- 403 - Forbidden Response validations------------------------
	
	@Test(groups={"forbidden","full"})
	public void configurationSecurity403() {
		configurationRequest.validateForbiddenStatus();		
	}
	
	
	//-------------------------- 400 - Bad Request Response validations----------------------
	
	@Test(groups={"badRequests","full"})
	public void ConfigurationSecurity_InvalidClient400() {
		
		configurationRequest.get(badClient, "", null, HttpStatus.SC_BAD_REQUEST, null);	
		
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ConfigurationSecurity_post_MthdNtAlwd405() {
		
		configurationRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ConfigurationSecurity_put_MthdNtAlwd405() {
		
		configurationRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ConfigurationSecurity_delete_MthdNtAlwd405() {
		
		configurationRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	//-------------------------- 404 - Invalid Segment validations---------------------
	
			@Test(groups={"notFound","full"})
			public void ConfigurationSecurity_InvalidSegment404() {
				
				configurationRequest.get("abc", null, HttpStatus.SC_NOT_FOUND, null);	
			}
			
			@Test(groups={"notFound","smoke","full"})
			public void ConfigurationSecurity_IncompleteAPIroute404() {
				//Incomplete API Route
				RequestSpecBuilder reqSB = new RequestSpecBuilder();
				ConfigurationRqst_IncompleteRoute.get("", reqSB, HttpStatus.SC_NOT_FOUND, null);
				
			}
	
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void configurationSecurity_SchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(configurationRequest.getBasicLF_SchemaPath())));
		
		configurationRequest.get("", null, HttpStatus.SC_OK, respSB);
		
	}
	

	@Test(groups={"schemaValidationDetailed","full"})
	public void configurationSecurity_SchemaValidationDetailed() {
		
		String configSecuritySchemaLocation = Paths.get(configurationRequest.buildSchemaPath("configurationSecurity-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(configSecuritySchemaLocation)));
		
		configurationRequest.get( "", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}

}
