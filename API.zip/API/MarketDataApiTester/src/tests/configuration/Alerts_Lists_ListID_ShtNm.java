package tests.configuration;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.configuration.IConfigurationRequest;

/*
 * Added by Madhu
 * Configuration/Alerts/Lists/{ListID}/{ShortName} endpoint*/
public class Alerts_Lists_ListID_ShtNm {
	
	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	String ListID = "4"; //QA: 1	//Prod:29
	String ShortName = "en";
	String InvalidShortName = "ab";
	String InvalidListID = "99999";
	
	IConfigurationRequest configurationRequest;
	IConfigurationRequest ConfigurationRqst_IncompleteRoute;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		configurationRequest = (IConfigurationRequest) RequestFactory.Get(ApiRequestType.Configuration, "Alerts/Lists/");
		ConfigurationRqst_IncompleteRoute = (IConfigurationRequest) RequestFactory.Get(ApiRequestType.Configuration, "Alerts/Lis");
	}
	
	
	//-------------------------- 200 - OK Response validations------------------------------
	
	@Test(groups={"getOk","smoke","full", "configuration"})
	public void configAlerts_ShortName_200() {	

		configurationRequest.get(ListID+"/"+ShortName, null, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations--------------------
	
	@Test(groups={"unAuthorized","full"})
	public void configAlerts_ShortName_401() {
		configurationRequest.validateUnauthorizedStatus();		
	}
	
	//-------------------------- 403 - Forbidden Response validations-----------------------
	
	@Test(groups={"forbidden","full"})
	public void configAlerts_ShortName_403() {
		configurationRequest.validateForbiddenStatus();		
	}
	
	
	//-------------------------- 400 - Bad Request Response validations---------------------
	
	@Test(groups={"badRequests","full"})
	public void configAlerts_ShortName_InvalidClient_400() {
		
		configurationRequest.get(badClient, "", null, HttpStatus.SC_BAD_REQUEST, null);	
		
	}
	
	@Test(groups={"badRequests","full"})
	public void configAlerts_ShortName_InvalidShortName_400() {
		
		configurationRequest.get(ListID+"/"+InvalidShortName, null, HttpStatus.SC_BAD_REQUEST, null);	
		
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void configAlerts_ShortName_post_MthdNtAlwd405() {
		
		configurationRequest.post(ListID+"/"+ShortName,inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void configAlerts_ShortName_put_MthdNtAlwd405() {
		
		configurationRequest.put(ListID+"/"+ShortName,inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void configAlerts_ShortName_delete_MthdNtAlwd405() {
		
		configurationRequest.delete(ListID+"/"+ShortName, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	//-------------------------- 404 - Invalid Segment validations---------------------
	
	@Test(groups={"notFound","full"})
	public void configAlerts_ShortName_InvalidSegment404() {
		
		configurationRequest.get(ListID+"/"+ShortName+"/abc", null, HttpStatus.SC_NOT_FOUND, null);	
	}
	
	@Test(groups={"notFound","smoke","full"})
	public void configAlerts_ShortName_IncompleteAPIroute404() {
		//Incomplete API Route
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		ConfigurationRqst_IncompleteRoute.get("", reqSB, HttpStatus.SC_NOT_FOUND, null);
				
	}
	
	@Test(groups={"notFound","smoke","full"})
	public void configAlerts_ShortName_InvalidListID_404() {
		//Incomplete API Route
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		ConfigurationRqst_IncompleteRoute.get(InvalidListID+"/"+ShortName, reqSB, HttpStatus.SC_NOT_FOUND, null);
				
	}
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void configAlerts_ShortName_SchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(configurationRequest.getBasicLF_SchemaPath())));
		
		configurationRequest.get( ListID+"/"+ShortName, null, HttpStatus.SC_OK, respSB);
		
	}
	

	@Test(groups={"schemaValidationDetailed","full"})
	public void configAlerts_ShortName_SchemaValidationDetailed() {
		
		String configAlerts_ShortNameSchemaLocation = Paths.get(configurationRequest.buildSchemaPath("Alerts_Lists_ListID_ShortName-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(configAlerts_ShortNameSchemaLocation)));
		
		configurationRequest.get( ListID+"/"+ShortName, null, HttpStatus.SC_OK, respSpecBuilder);
		
	}

}
