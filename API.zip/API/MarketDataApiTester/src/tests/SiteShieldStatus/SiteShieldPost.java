package tests.SiteShieldStatus;

import org.Utilities;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.jayway.restassured.specification.RequestSpecification;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import java.io.IOException;
import java.nio.file.Paths;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;



public class SiteShieldPost {
	
	String APIAccessCode = "6325BCD5-BB43-40BB-BA40-B4484C6D314A";
	String DomainURL = "https://irkms.corporate-ir-qa.net/v1/Clients/";
	String CRMSiteId = "CCBN1";
	String ServiceEntitlementId = "4";
	//https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/4

	IMarketDataRequest marketRequest;	
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Quotes");
	}
	private static String schemaLocation = String.format("%s\\%s", System.getProperty("user.dir"), "schemas");
	
	/*@Test(groups={"siteshieldpost", "mthdNtAlwd","full"})
	public void SiteShield_201post() throws Exception{
	      Response myJson = given().contentType("application/json").body()
	    		  .when().post("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/4");
	    		  
		}*/
	
	//-------------------------- POST - 201 - POST Response validations---------------------------
	@Test(groups={"siteshield","full"})
	public void SiteShieldPost_201(){
		//String executionResult = null;
		
		// put file in the correct location.
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Post.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Post.json";
		Response responsePost ;
	 		try {
				
	 			responsePost = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.post("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/4").
					
				then().
				extract()
					.response();
	 			
	 			responsePost.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	
	//-------------------------- POST - 400 - Bad Request Response validations-----------------------
	@Test(groups={"siteshield", "badRequests", "full"})
	public void SiteShieldPost_400post_BadResponse(){
		//String executionResult = null;
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Post.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Post.json";
		Response responsePost ;
	 		try {
				
	 			responsePost = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.post("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/2").
					
				then().
				extract()
					.response();
	 			
	 			responsePost.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	@Test(groups={"siteshield", "mthdNtAlwd","full"})
	public void SiteShieldPost_get_MthdNtAlwd405(){
		//String executionResult = null;
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Post.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Post.json";
		Response responsePost ;
	 		try {
				
	 			responsePost = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.get("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/2").
					
				then().
				extract()
					.response();
	 			
	 			responsePost.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	@Test(groups={"siteshield", "mthdNtAlwd","full"})
	public void SiteShieldPost_put_MthdNtAlwd405(){
		//String executionResult = null;
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Post.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Post.json";
		Response responsePost ;
	 		try {
				
	 			responsePost = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.put("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/2").
					
				then().
				extract()
					.response();
	 			
	 			responsePost.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	@Test(groups={"siteshield", "mthdNtAlwd","full"})
	public void SiteShieldPost_delete_MthdNtAlwd405(){
		//String executionResult = null;
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Post.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Post.json";
		Response responsePost ;
	 		try {
				
	 			responsePost = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.delete("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/2").
					
				then().
				extract()
					.response();
	 			
	 			responsePost.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	//-------------------------- POST - 404 - Not Found Response validations--------------------------
	
	@Test(groups={"siteshield", "notFound", "full"})
	public void SiteShieldPost_NotFound404(){

		
		// put file in the correct location.
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Post.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Post.json";
		Response responsePost ;
	 		try {
				
	 			responsePost = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.post("https://irkms.corporate-ir-qa.net/v1/ClientsS/CCBN1/products/4").
					
				then().
				extract()
					.response();
	 			
	 			responsePost.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	
	@Test(groups={"siteshield", "notFound", "full"})
	public void SiteShieldPost_NotFound_incompleteRoute404(){

		
		// put file in the correct location.
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Post.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Post.json";
		Response responsePost ;
	 		try {
				
	 			responsePost = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.post("https://irkms.corporate-ir-qa.net/v1/Cli/CCBN1/products/4").
					
				then().
				extract()
					.response();
	 			
	 			responsePost.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	
	/*
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void siteshieldPost_SchemaValidations(){
//	 	 
//				ValidatableResponse valResp = 
//				given()
//				    .relaxedHTTPSValidation().
//				when()			
//					.post("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/2").			
//				then().
//					body(matchesJsonSchemaInClasspath("SiteShield_Post_Response_Schema.json"));
		
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Post.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Post.json";
		//Response responsePost ;
		String responsePost;
	 		try {
				
	 			responsePost = given()					
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.post("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/4").
					
				then().
					body(matchesJsonSchemaInClasspath("SiteShield_Post_Response_Schema.json"));
				
	 			responsePost.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	
	
	// put file in the correct location.

 		
	//-------------------------- Basic Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiNewsListJSON_BasicSchemaValidations(){
	 	 
				ValidatableResponse valResp = 
				given()
				    .relaxedHTTPSValidation().
				when()			
				.post("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/2").			
				then().
				body(matchesJsonSchemaInClasspath("lfBasic-schema.json"));
		}
	
}	
	
	*/
	
}
