package tests.SiteShieldStatus;

import org.Utilities;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.jayway.restassured.specification.RequestSpecification;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import java.io.IOException;
import java.nio.file.Paths;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;



public class SiteShieldPut {
	
	String APIAccessCode = "6325BCD5-BB43-40BB-BA40-B4484C6D314A";
	String DomainURL = "https://irkms.corporate-ir-qa.net/v1/Sites/";
	String InvalidAPIAccessCode = "6325BCD5-BB43-40BB-BA40";
	//https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/4

	IMarketDataRequest marketRequest;	
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Quotes");
	}
	private static String schemaLocation = String.format("%s\\%s", System.getProperty("user.dir"), "schemas");
	
	/*@Test(groups={"siteshieldPut", "mthdNtAlwd","full"})
	public void SiteShield_201Put() throws Exception{
	      Response myJson = given().contentType("application/json").body()
	    		  .when().Put("https://irkms.corporate-ir-qa.net/v1/Clients/CCBN1/products/4");
	    		  
		}*/
	
	//-------------------------- PUT - 200 - PUT Response validations---------------------------
	@Test(groups={"siteshield","full"})
	public void SiteShieldPut_200(){
		//String executionResult = null;
		
		// put file in the correct location.
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Put.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Put.json";
		Response responsePut ;
	 		try {
				
	 			responsePut = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.put(DomainURL + APIAccessCode + "/CMSState").
					
				then().
				extract()
					.response();
	 			
	 			responsePut.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	

	//-------------------------- Put - 400 - Bad Request Response validations-----------------------
	@Test(groups={"siteshield", "badRequests", "full"})
	public void SiteShieldPut_400_BadResponse(){
		//String executionResult = null;
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Put.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Put.json";
		Response responsePut ;
	 		try {
				
	 			responsePut = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
				.put(DomainURL + InvalidAPIAccessCode + "/CMSState").
					
				then().
				extract()
					.response();
	 			
	 			responsePut.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	@Test(groups={"siteshield", "mthdNtAlwd","full"})
	public void SiteShieldPut_get_MthdNtAlwd405(){
		//String executionResult = null;
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Put.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Put.json";
		Response responsePut ;
	 		try {
				
	 			responsePut = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.get(DomainURL + APIAccessCode + "/CMSState").
					
				then().
				extract()
					.response();
	 			
	 			responsePut.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	@Test(groups={"siteshield", "mthdNtAlwd","full"})
	public void SiteShieldPut_post_MthdNtAlwd405(){
		//String executionResult = null;
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Put.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Put.json";
		Response responsePut ;
	 		try {
				
	 			responsePut = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.post(DomainURL + APIAccessCode + "/CMSState").
					
				then().
				extract()
					.response();
	 			
	 			responsePut.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	@Test(groups={"siteshield", "mthdNtAlwd","full"})
	public void SiteShieldPut_delete_MthdNtAlwd405(){
		//String executionResult = null;
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Put.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Put.json";
		Response responsePut ;
	 		try {
				
	 			responsePut = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
					.delete(DomainURL + APIAccessCode + "/CMSState").
					
				then().
				extract()
					.response();
	 			
	 			responsePut.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	//-------------------------- PUT - 404 - Not Found Response validations--------------------------
	
	@Test(groups={"siteshield", "notFound", "full"})
	public void SiteShieldPut_NotFound404(){

		
		// put file in the correct location.
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Put.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Put.json";
		Response responsePut ;
	 		try {
				
	 			responsePut = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
				.put(DomainURL + APIAccessCode + "/CMSState/ABC").
					
				then().
				extract()
					.response();
	 			
	 			responsePut.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	
	@Test(groups={"siteshield", "notFound", "full"})
	public void SiteShieldPut_NotFound_incompleteRoute404(){

		
		// put file in the correct location.
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Put.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Put.json";
		Response responsePut ;
	 		try {
				
	 			responsePut = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
				.put(DomainURL + APIAccessCode).
					
				then().
				extract()
					.response();
	 			
	 			responsePut.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
	 		
	}
	
	
/*
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"siteshield", "getOk", "smoke","full"})
	public void siteshieldPut_SchemaValidations(){

				ValidatableResponse valResp = 
				given()
				    .relaxedHTTPSValidation().
				when()			
					.put(DomainURL + APIAccessCode + "/CMSState").		
				then().
					body(matchesJsonSchemaInClasspath("SiteShield_Put_JSON_Schema.json"));
		
		String inputJsonLocation = Paths.get(schemaLocation, "SiteShieldPost", "SiteShield_Put.json").toString();
		inputJsonLocation = "./schemas/SiteShieldPost/SiteShield_Put.json";
		//Response responsePost ;
		ValidatableResponse responsePut;
	 		try {
				
	 			responsePut = given()						
						.body(Utilities.getFileContents(inputJsonLocation)) //new File(inputJsonLocation)).
						.log().all().
				when()			
				.put(DomainURL + APIAccessCode + "/CMSState").
					
				then().
					body(matchesJsonSchemaInClasspath("SiteShield_Put_JSON_Schema.json"));
				
	 		//	responsePut.prettyPeek();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	
	
	// put file in the correct location.

 	/*	
	//-------------------------- Basic Schema validations-----------------------------
	@Test(groups={"siteshield", "getOk", "smoke","full"})
	public void SiteShieldPut_BasicSchemaValidations(){
	 	 
				ValidatableResponse valResp = 
				given()
				    .relaxedHTTPSValidation().
				when()			
				.put(DomainURL + APIAccessCode + "/CMSState").			
				then().
				body(matchesJsonSchemaInClasspath("lfBasic-schema.json"));
		}
	
}	
	
	*/
	
}
