package tests.SiteShieldStatus;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;



public class SiteShieldStatus { 
	
	String APIAccessCode = "6325bcd5-bb43-40bb-ba40-b4484c6d314a";
	String DomainURL = "https://irkms.corporate-ir-qa.net/v1/sites/";

	IMarketDataRequest marketRequest;	
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Quotes");
	}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"siteshield", "getOk", "smoke","full"})
	public void SiteShieldStatus_200(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
		 	
			Response response = 
						given()
						    .relaxedHTTPSValidation()
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.get(DomainURL + APIAccessCode+"/HubState").				
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);			
		}
	

	//-------------------------- 401 - Unauthorized Response validations-------------------
	@Test(groups={"siteshield", "smoke","full", "unAuthorized"})
	public void SiteShieldStatus_401(){
	 	 
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
						    .relaxedHTTPSValidation()
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.get(DomainURL + APIAccessCode+"/HubState").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_UNAUTHORIZED);			
		}
	

	//-------------------------- 403 - Forbidden Response validations----------------------
	@Test(groups={"siteshield", "forbidden","full"})
	public void SiteShieldStatus_403(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	int statusCode = 0;
			
			Response response = 
						given()
						    .relaxedHTTPSValidation()
							.header("apiKey", apiKey)
							.header("Accept", "application/json").
						when()			
							.get(DomainURL+APIAccessCode+"/HubState").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_FORBIDDEN);			
		}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	@Test(groups={"siteshield", "badRequests","full"})
	public void SiteShieldStatus_400(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
						    .relaxedHTTPSValidation()
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.get(DomainURL +APIAccessCode+ "abc/HubState").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_BAD_REQUEST);			
		}

	
	//-------------------------- 404 - Not Found Response validations----------------------
	@Test(groups={"siteshield", "notFound","smoke","full"})
	public void SiteShieldStatus_404(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
						    .relaxedHTTPSValidation()
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.get(DomainURL+APIAccessCode+"/HubStateSS").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}


	//-------------------------- 405 - Method Not Allowed validations-----------------------
	@Test(groups={"siteshield", "mthdNtAlwd","full"})
	public void SiteShieldStatus_405put(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
						    .relaxedHTTPSValidation()
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").and()
							.body("testInputForPut").
						when()			
							.put(DomainURL+APIAccessCode+"/HubState").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_METHOD_NOT_ALLOWED);			
		}
	
	
	@Test(groups={"siteshield", "mthdNtAlwd","full"})
	public void SiteShieldStatus_405post(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
						    .relaxedHTTPSValidation()
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").and()
							.body("testInputForPost").
						when()			
							.post(DomainURL+APIAccessCode+"/HubState").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_METHOD_NOT_ALLOWED);			
		}
	
	
	@Test(groups={"siteshield", "mthdNtAlwd","full"})
	public void SiteShieldStatus_405delete(){
	 	 
		 	String apiKey = marketRequest.getCurrentApiKey();
		 	String mktSession = marketRequest.getCurrentSessionToken();
		 	int statusCode = 0;
			
			Response response = 
						given()
						    .relaxedHTTPSValidation()
							.header("apiKey", apiKey)
							.header("mktSession", mktSession).and()
							.header("Accept", "application/json").
						when()			
							.delete(DomainURL+APIAccessCode+"/HubState").
							
						then().	
						extract()
							.response();
						
						statusCode = response.getStatusCode();
						Assert.assertEquals(statusCode, HttpStatus.SC_METHOD_NOT_ALLOWED);			
		}


}
