package tests.workflow;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import org.Utilities;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;

import api.ApiRequestType;
import api.RequestFactory;
import api.configuration.IConfigurationRequest;
import api.market.IMarketDataRequest;
import api.workflow.IWorkflowRequest;


public class Alerts {
	
	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";	
	
	IWorkflowRequest workFlowReq;
	IWorkflowRequest workFlowReq_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		workFlowReq = (IWorkflowRequest) RequestFactory.Get(ApiRequestType.WorkFlow, "alerts");
		workFlowReq_IncompleteSeg = (IWorkflowRequest) RequestFactory.Get(ApiRequestType.WorkFlow, "aler");
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-----------------------------
	@Test(groups={"unAuthorized","full"})
	public void workFlowAlertsLists401() {
		workFlowReq.validateUnauthorizedStatus();		
	}
	
	
	//-------------------------- 403 - Forbidden Response validations--------------------------------
	@Test(groups={"forbidden","full"})
	public void workFlowAlertsLists403() {
		workFlowReq.validateForbiddenStatus();		
	}
	
	
	//-------------------------- POST - 201 - Created Response validations---------------------------
	@Test(groups={"schemaValidation","schemaValidationDetailed","full", "getOk", "workflow"})
	public void alertsPost201() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsEmailBlast_post/alertsBody_Post.json")).toString();
		//String inputJsonLocation  = P "./schemas/workflow/post_InputBody.json";		
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		String alertsPOST_SchemaLocation = Paths.get(workFlowReq.buildSchemaPath("/schemaAlertsEmailBlast_post/alerts_Post_EmailBlast_Response_Schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(workFlowReq.getBasicLF_SchemaPath())))
					   .expectBody(matchesJsonSchema(new File(alertsPOST_SchemaLocation)));
		
		
		ValidatableResponse resp = workFlowReq.post( "", jsonContent, null, HttpStatus.SC_CREATED, respSpecBuilder);
				
	}
	
	
	//-------------------------- POST - 400 - Bad Request Response validations-----------------------
	@Test(groups={"badRequests", "full"})
	public void alertsPost_withoutBody400() throws IOException {		

		workFlowReq.post( "", " ", null, HttpStatus.SC_BAD_REQUEST, null);
				
	}
	
	@Test(groups={"badRequests", "full"})
	public void alertsPost_InvalidClient400() throws IOException {		

		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsEmailBlast_post/alertsBody_Post_withoutLangId.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		workFlowReq.post(badClient, "", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
				
	}
	
	@Test(groups={"badRequests", "full"})
	public void alertsPost_withoutLangId400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsEmailBlast_post/alertsBody_Post_withoutLangId.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		ValidatableResponse resp = workFlowReq.post( "", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
	
				
	}
	
	
	@Test(groups={"badRequests", "full"})
	public void alertsPost_withoutListId400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsEmailBlast_post/alertsBody_Post_withoutListId.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		ValidatableResponse resp = workFlowReq.post( "", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
				
	}
	
	
	@Test(groups={"badRequests", "full"})
	public void alertsPost_withoutFrmToSubBdy400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsEmailBlast_post/alertsBody_Post_withoutFrmToSubBdy.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		ValidatableResponse resp = workFlowReq.post( "", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
	
				
	}
	
	
	@Test(groups={"badRequests", "full"})
	public void alertsPost_emptyFrmToSubBdy400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsEmailBlast_post/alertsBody_Post_emptyFrmToSubBdy.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		ValidatableResponse resp = workFlowReq.post( "", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
	
				
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void alerts_get_MthdNtAlwd405() {
		
		workFlowReq.get("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void alerts_put_MthdNtAlwd405() {
		
		workFlowReq.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void alerts_delete_MthdNtAlwd405() {
		
		workFlowReq.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	/*
	@Test(groups={"testRun"})
	public void teststring() throws IOException{
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("alertSubscriptionBody_Post.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		jsonContent = jsonContent.replace("testEmailAddressInput", "sreekanth.hr@nasdaq.com");
		jsonContent = jsonContent.replace("shortNameInput", "en");
		
		System.out.println(jsonContent);		
	}
	*/
	//workFlowReq_IncompleteSeg
	//-------------------------- POST - 404 - Not Found Response validations--------------------------
	
		@Test(groups={"notFound", "full"})
		public void alertsPost_404() throws IOException {
			String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsEmailBlast_post/alertsBody_Post.json")).toString();	
			String jsonContent;
			jsonContent = Utilities.getFileContents(inputJsonLocation);	
			//Replace string in the JSON file to test data
			jsonContent = Utilities.getFileContents(inputJsonLocation);
			
			ValidatableResponse resp = workFlowReq.post( "/xxx", jsonContent, null, HttpStatus.SC_NOT_FOUND, null);
			
					
		}
		
		@Test(groups={"notFound", "full"})
		public void alertsPost_invalidSegment_404() throws IOException {
			String inputJsonLocation = Paths.get(workFlowReq_IncompleteSeg.buildSchemaPath("/inputBodyAlertsEmailBlast_post/alertsBody_Post.json")).toString();	
			String jsonContent;
			jsonContent = Utilities.getFileContents(inputJsonLocation);	
			//Replace string in the JSON file to test data
			jsonContent = Utilities.getFileContents(inputJsonLocation);
			
			ValidatableResponse resp = workFlowReq_IncompleteSeg.post( "", jsonContent, null, HttpStatus.SC_NOT_FOUND, null);
			
					
		}	

}
