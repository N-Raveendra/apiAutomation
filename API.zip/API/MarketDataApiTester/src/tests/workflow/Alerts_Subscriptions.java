package tests.workflow;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.Utilities;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;

import api.ApiRequestType;
import api.RequestFactory;
import api.configuration.IConfigurationRequest;
import api.market.IMarketDataRequest;
import api.workflow.IWorkflowRequest;

public class Alerts_Subscriptions{
	
	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	String validEmail = "madhukumar.sriranganath@nasdaq.com;puneeth.nath@nasdaq.com;sreekanth.hr@nasdaq.com";
	
	String batchIdNew = "";
	String batchIdUsed = "5bb307fc-537a-4e07-a714-e044b1eef3b6";
	
	
	String shortNameValid = "en";
	String shortNameInvalid = "invalidShortName";
	
	
	Map<String, String> tokens = new HashMap<String, String>();
	
	
	IWorkflowRequest workFlowReq;	
	IWorkflowRequest workFlowReq_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		workFlowReq = (IWorkflowRequest) RequestFactory.Get(ApiRequestType.WorkFlow, "alerts");
		workFlowReq_IncompleteSeg = (IWorkflowRequest) RequestFactory.Get(ApiRequestType.WorkFlow, "aler");
		initTokens();		
	}


	private void initTokens() {
		tokens.put("%%testEmailAddressInput%%", validEmail);
		tokens.put("%%shortNameInput%%", "en");
		tokens.put("%%testAutomationBatchIdInput%%", batchIdNew);
	}
	
	
	public String processTokens(String inputJson) {
		for (Map.Entry<String, String> entry : tokens.entrySet()) {
			inputJson = inputJson.replace(entry.getKey() , entry.getValue());
		}
		return inputJson;
	}
	
	//-------------------------- 401 - Unauthorized Response validations-----------------------------
	@Test(groups={"unAuthorized","full"})
	public void workFlow401() {
		workFlowReq.validateUnauthorizedStatus();		
	}
	
	
	//-------------------------- 403 - Forbidden Response validations--------------------------------
	@Test(groups={"forbidden","full"})
	public void workFlow403() {
		workFlowReq.validateForbiddenStatus();		
	}
	
	
	//-------------------------- POST - 201 - Created Response validations---------------------------
	@Test(groups={"schemaValidation","schemaValidationDetailed","full", "getOk", "workflow"})
	public void alertSubscriptionsPost201() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		String alertsSubscriptionsPOST_SchemaLocation = Paths.get(workFlowReq.buildSchemaPath("/schemaAlertsSubscriptions_post/alertsSubscriptions_Post-Response_Schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(workFlowReq.getBasicLF_SchemaPath())))
					   .expectBody(matchesJsonSchema(new File(alertsSubscriptionsPOST_SchemaLocation)));
		
		ValidatableResponse resp = workFlowReq.post( "/lists/subscriptions", processTokens(jsonContent), null, HttpStatus.SC_CREATED, respSpecBuilder);
		batchIdNew = resp.extract().path("result.BatchId").toString();
		System.out.println("Batch id created is " +batchIdNew);
	}

	
	//-------------------------- PUT - 200 - OK (Update) Response validations------------------------
	
	//Alert Subscriptions PUT
	@Test(groups={"schemaValidation","schemaValidationDetailed","full", "getOk", "workflow"}, dependsOnMethods="alertSubscriptionsPost201")
	public void alertSubscriptionsPut200() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_put/alertSubscriptionBody_Put.json")).toString();
		//String inputJsonLocation  = P "./schemas/workflow/post_InputBody.json";		
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		jsonContent = jsonContent.replace("%%testAutomationBatchIdInput%%", batchIdNew);
		
		String alertsSubscriptionsPUT_SchemaLocation = Paths.get(workFlowReq.buildSchemaPath("/schemaAlertsSubscriptions_put/alertsSubscriptions_Put-Response_Schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(workFlowReq.getBasicLF_SchemaPath())))
					   .expectBody(matchesJsonSchema(new File(alertsSubscriptionsPUT_SchemaLocation)));
		
		
		ValidatableResponse resp = workFlowReq.put( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_OK, respSpecBuilder);
				
	}
	
	//-------------------------- DELETE - 200 - OK (Unsubscribe-DELETE) Response validations----------------
	
	//Alert Subscriptions Unsubscribe single list
	@Test(groups={"schemaValidation","schemaValidationDetailed","full", "getOk", "workflow"}, dependsOnMethods="alertSubscriptionsPut200")
	public void alertSubscriptions_UnsubscribeList_Delete200() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_delete/alertsSubscriptionsBody_UnsubscribeList_delete.json")).toString();
		
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		jsonContent = jsonContent.replace("%%testEmailAddressInput%%", validEmail);
		
		String alertsSubscriptionsDelete_SchemaLocation = Paths.get(workFlowReq.buildSchemaPath("/schemaAlertsSubscriptions_delete/alertsSubscriptions_Delete-Response_Schema.json")).toString();		
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.setBody(jsonContent);
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(workFlowReq.getBasicLF_SchemaPath())))
					   .expectBody(matchesJsonSchema(new File(alertsSubscriptionsDelete_SchemaLocation)));
		
		
		workFlowReq.delete( "/lists/subscriptions", reqSpec, HttpStatus.SC_OK, respSpecBuilder);
	}
	
	
	
	//Alert Subscriptions Direct Unsubscribe lists
	@Test(groups={"schemaValidation","schemaValidationDetailed","full", "getOk", "workflow"}, dependsOnMethods="alertSubscriptions_UnsubscribeList_Delete200")
	public void alertSubscriptions_DirectUnsubscribe_Delete200() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_delete/alertsSubscriptionsBody_DirectUnsubscribe_delete.json")).toString();
		
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		jsonContent = jsonContent.replace("%%testEmailAddressInput%%", validEmail);
		
		String alertsSubscriptionsDelete_SchemaLocation = Paths.get(workFlowReq.buildSchemaPath("/schemaAlertsSubscriptions_delete/alertsSubscriptions_Delete-Response_Schema.json")).toString();		
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.setBody(jsonContent);
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(workFlowReq.getBasicLF_SchemaPath())))
					   .expectBody(matchesJsonSchema(new File(alertsSubscriptionsDelete_SchemaLocation)));
		
		
		workFlowReq.delete( "/lists/subscriptions", reqSpec, HttpStatus.SC_OK, respSpecBuilder);
	}
	
	
	//-------------------------- POST - 400 - Bad Request Response validations-----------------------
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPost_withoutShortName400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		//Replace string in JSON to test data
		jsonContent = jsonContent.replace("testEmailAddressInput", validEmail);
		jsonContent = jsonContent.replace("shortNameInput", "");
		
		workFlowReq.post( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPost_InvalidClient400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		//Replace string in JSON to test data
		jsonContent = jsonContent.replace("testEmailAddressInput", validEmail);
		jsonContent = jsonContent.replace("shortNameInput", "");
		
		workFlowReq.post(badClient, "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPost_invalidShortName400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		//Replace string in JSON to test data
		jsonContent = jsonContent.replace("testEmailAddressInput", validEmail);
		jsonContent = jsonContent.replace("shortNameInput", "invalidShortName");
		
		workFlowReq.post( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPost_withoutListLangsNode400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post_wihtoutListLangs.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		workFlowReq.post( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPost_withoutAlertsNode400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post_wihtoutAlertsNode.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		workFlowReq.post( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPost_withoutBaseURL400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post_wihtoutBaseURL.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		workFlowReq.post( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPost_withoutSubscriber400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post_wihtoutSubscriber.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		
		workFlowReq.post( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	//-------------------------- PUT - 400 - Bad Request Response validations------------------------
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPut_EmptyBatchId_400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_put/alertSubscriptionBody_Put.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		//Replace string in the JSON file to test data
		jsonContent = jsonContent.replace("testAutomationBatchIdInput", "");
		
		ValidatableResponse resp = workFlowReq.put( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
				
	}
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPut_InvalidClient_400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_put/alertSubscriptionBody_Put.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		//Replace string in the JSON file to test data
		jsonContent = jsonContent.replace("testAutomationBatchIdInput", "");
		
		ValidatableResponse resp = workFlowReq.put(badClient, "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
				
	}
	
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPut_InvalidBatchId_400() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_put/alertSubscriptionBody_Put.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		//Replace string in the JSON file to test data
		jsonContent = jsonContent.replace("testAutomationBatchIdInput", "invalidBatchId");
		
		ValidatableResponse resp = workFlowReq.put( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_BAD_REQUEST, null);
		
				
	}
	
	
	@Test(groups={"badRequests", "full"})
	public void alertSubscriptionsPut_WithoutBatchId_400() throws IOException {
		
		workFlowReq.put( "/lists/subscriptions", " { }", null, HttpStatus.SC_BAD_REQUEST, null);
				
	}
	
	
	//-------------------------- PUT - 404 - Not Found Response validations--------------------------
	
	@Test(groups={"notFound", "full"})
	public void alertSubscriptionsPut_404() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_put/alertSubscriptionBody_Put.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		//Replace string in the JSON file to test data
		jsonContent = jsonContent.replace("%%testAutomationBatchIdInput%%", batchIdUsed);
		
		ValidatableResponse resp = workFlowReq.put( "/lists/subscriptions/xxx", jsonContent, null, HttpStatus.SC_NOT_FOUND, null);
		
				
	}
	
	@Test(groups={"notFound", "full"})
	public void alertSubscriptionsPut_Incomplete_404() throws IOException {
		String inputJsonLocation = Paths.get(workFlowReq_IncompleteSeg.buildSchemaPath("/inputBodyAlertsSubscriptions_put/alertSubscriptionBody_Put.json")).toString();	
		String jsonContent;
		jsonContent = Utilities.getFileContents(inputJsonLocation);	
		//Replace string in the JSON file to test data
		jsonContent = jsonContent.replace("%%testAutomationBatchIdInput%%", batchIdUsed);
		
		ValidatableResponse resp = workFlowReq_IncompleteSeg.put( "/lists/subscriptions", jsonContent, null, HttpStatus.SC_NOT_FOUND, null);
		
				
	}
	
	
	//-------------------------- POST - 404 - Not Found Response validations--------------------------
	
		@Test(groups={"notFound", "full"})
		public void alertSubscriptionsPost_404() throws IOException {
			String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post.json")).toString();	
			String jsonContent;
			jsonContent = Utilities.getFileContents(inputJsonLocation);	

			//Replace string in the JSON file to test data
			jsonContent = jsonContent.replace("%%testAutomationBatchIdInput%%", batchIdUsed);
			
			ValidatableResponse resp = workFlowReq.post( "/lists/subscription", jsonContent, null, HttpStatus.SC_NOT_FOUND, null);
			
					
		}
		
		@Test(groups={"notFound", "full"})
		public void alertSubscriptionsPost_Incomplete_404() throws IOException {
			String inputJsonLocation = Paths.get(workFlowReq_IncompleteSeg.buildSchemaPath("/inputBodyAlertsSubscriptions_post/alertSubscriptionBody_Post.json")).toString();	
			String jsonContent;
			jsonContent = Utilities.getFileContents(inputJsonLocation);	
			//Replace string in the JSON file to test data
			jsonContent = jsonContent.replace("%%testAutomationBatchIdInput%%", batchIdUsed);
			
			ValidatableResponse resp = workFlowReq_IncompleteSeg.post( "/lists/subscription", jsonContent, null, HttpStatus.SC_NOT_FOUND, null);
			
					
		}
		
		
		//-------------------------- DELETE - 404 - Not Found Response validations--------------------------
	
			@Test(groups={"notFound", "full"})
			public void alertSubscriptionsDelete_404() throws IOException {
				String inputJsonLocation = Paths.get(workFlowReq.buildSchemaPath("/inputBodyAlertsSubscriptions_delete/alertsSubscriptionsBody_UnsubscribeList_delete.json")).toString();
				
				String jsonContent;
				jsonContent = Utilities.getFileContents(inputJsonLocation);	
				jsonContent = jsonContent.replace("%%testEmailAddressInput%%", validEmail);
				
				RequestSpecBuilder reqSpec = new RequestSpecBuilder();
				reqSpec.setBody(jsonContent);
				
				workFlowReq.delete( "/lists/subscriptions/sss", reqSpec, HttpStatus.SC_NOT_FOUND, null);
			}
			
			@Test(groups={"notFound", "full"})
			public void alertSubscriptionsDelete_IncompSegment_404() throws IOException {
				String inputJsonLocation = Paths.get(workFlowReq_IncompleteSeg.buildSchemaPath("/inputBodyAlertsSubscriptions_delete/alertsSubscriptionsBody_UnsubscribeList_delete.json")).toString();
				
				String jsonContent;
				jsonContent = Utilities.getFileContents(inputJsonLocation);	
				jsonContent = jsonContent.replace("%%testEmailAddressInput%%", validEmail);
				
				RequestSpecBuilder reqSpec = new RequestSpecBuilder();
				reqSpec.setBody(jsonContent);
				
				workFlowReq_IncompleteSeg.delete( "/lists/subscriptions", reqSpec, HttpStatus.SC_NOT_FOUND, null);
			}
			
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void alertSubscriptions_get_MthdNtAlwd405() {
		
		workFlowReq.get("/lists/subscriptions", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
		

	/*
	@Test(groups={"schemaValidation","smoke","full"})
	public void stockInfoSchemaValidation() {
		
		String estStockInfoSchemaLocation = Paths.get(marketRequest.buildSchemaPath("stockInfo-schema.json")).toString();		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())))
				.expectBody(matchesJsonSchema(new File(estStockInfoSchemaLocation )));
		
		marketRequest.validateGet(testClient, "/stockInfo", null, HttpStatus.SC_OK, respSpecBuilder);
	}
	*/
}