package tests;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.ResponseSpecBuilder;

import api.BootStrapper;
import api.Session;

public class SessionTests {

	String apiAccessID = "6325bcd5-bb43-40bb-ba40-b4484c6d314a";
	//8a10d47a-1527-4497-9517-390279713b32 --> PROD API Access USB - HRS09022016
	// "2c993793-761d-4de5-b07d-c1defb295bb2" --> API Access ID for QA PHX (Client - US Bancorp) - 20161019
	// "aea38f90-47df-42af-8092-37b59c418730" --> API Access ID for UAT PHX (Client - US Bancorp)
	// de814832-a2b4-44c9-b40e-861775e91c37 --> API Access ID for QA WC (Client - Intel)
	
	
	
	String badClientId = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	Session session ; //= new Session(BootStrapper.getInstance().getApiTestSession());
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		session = new Session(BootStrapper.getInstance().getApiTestSession());
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-----------------------------
	@Test(groups={"unAuthorized","full"})
	public void SessionUnauthorizedTest() {	
		session.setClientId(apiAccessID);
		session.validateUnauthorizedStatus();		
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"getOk","smoke","full"})
	public void SessionGetTest() {
		session.validateGet(apiAccessID, HttpStatus.SC_OK);	
	}
	
	
	//-------------------------- 400 - Bad Request validations-----------------------------
	@Test(groups={"badRequests","full"})
	public void SessionBadRequestTest() {
		session.validateGet(badClientId, HttpStatus.SC_BAD_REQUEST);		
	}
	
	//-------------------------- 400 - Bad Request validations-----------------------------
	@Test(groups={"schemaValidation","smoke","full"})
	public void SessionSchemaValidation() {
		
		String sessionSchemaLocation = Paths.get(session.buildSchemaPath("session-schema.json")).toString();		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(session.getBasicLF_SchemaPath())))
				.expectBody(matchesJsonSchema(new File(sessionSchemaLocation)));
		
		session.getResponse(apiAccessID, null, HttpStatus.SC_OK, respSpecBuilder);				
	}
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void session_post_MthdNtAlwd405() {
		
		session.post(apiAccessID, "",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void session_put_MthdNtAlwd405() {
		
		session.put(apiAccessID, "",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void session_Delete_MthdNtAlwd405() {
		
		session.delete(apiAccessID, "", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);		
		
	}
	
	
}