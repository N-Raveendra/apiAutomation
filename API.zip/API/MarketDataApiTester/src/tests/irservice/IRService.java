package tests.irservice;

import org.apache.http.HttpStatus;
import org.apache.http.client.fluent.Request;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.authentication.PreemptiveBasicAuthScheme;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.filter.session.SessionFilter;
import com.jayway.restassured.internal.assertion.Assertion;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;
import com.jayway.restassured.response.ValidatableResponse;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.MatcherAssert.assertThat;


import org.apache.commons.io.FileUtils;
//import org.apache.logging.log4j.*;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.Cookie;

import settings.TestConfiguration;

import java.awt.Robot;

import javax.swing.text.html.HTMLDocument.Iterator;


public class IRService {
                
   

                String siteURL = "https://admin:Passw0rd1!@5555581.test-nasdaq.acsitefactory.com";
                public  static WebDriver driver = null;
//                @BeforeTest
                public void initChromeDriver()
                {
                                System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//exe//chromedriver.exe");
                                
                                driver= new ChromeDriver();
                                driver.manage().window().maximize();
                                driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                                driver.manage().deleteAllCookies();
                                driver.get(siteURL+"/user/login");                
                
                }
                
                @Test (groups={"irservice", "getOk", "smoke","full"})

                public void irapicontentmonitorJSON_SchemaValidation() throws InterruptedException
                {
                                
                                
                                try{
                                                

                                initChromeDriver();
                                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                                driver.findElement(By.id("edit-name")).sendKeys("contentadmin");
                                driver.findElement(By.id("edit-pass")).sendKeys("ClEL6$$NHUsb");
                                driver.findElement(By.id("edit-submit")).click();
                                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                                Thread.sleep(10000);
                                
                                driver.get(siteURL+"irservice/contentmonitor?_format=json");
                                Thread.sleep(3000);
                                String innertext= driver.findElement(By.tagName("body")).getText() ;
                                String json = innertext;
                                System.out.println(json);
                                
                                 assertThat(json, matchesJsonSchemaInClasspath("contentMonitor.json"));
                                               
                                 if(innertext.indexOf("ScheduledContent") >= 0){
                                                System.out.println("Status code is 200 OK  : Pass" );
                                
                                                 System.out.println("ScheduledContent - Data point is available  : Pass" );
                                }
                                else
                                {
                                                System.out.println("ScheduledContent - Data point not available  : Fail" );
                                                
                                                 }
                                
                                 
                                 if(innertext.indexOf("ContentForReview") >= 0)
                                                System.out.println("ContentForReview - Data point is available  : Pass" );
                                else
                                                System.out.println("ContentForReview - Data point not available  : Fail" );
                                
                                 irapicontentmonitorJSON_404();
                }
                                catch(Exception e)
                                {
                                                e.printStackTrace();
                                }
                }
                
                
                //-------------------------- 404 - Not Found Response validations-----------------------------

                public void irapicontentmonitorJSON_404() throws InterruptedException{
                                                try{
                                                driver.get(siteURL+"irservice/contentmonitorS?_format=json");
                                                Thread.sleep(3000);
                                                String errorText= driver.findElement(By.tagName("body")).getText() ;
                                                System.out.println(errorText);
                                                
                                                
                                                                
                                                 if(errorText.indexOf(":404") >= 0 || errorText.indexOf("Invalid") >= 0 ||errorText.indexOf("No route found")>=0){
                                                                System.out.println("Status code is 404 OK  : Pass" );
//                                                            Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);
                                                                
                                                }
                                                else
                                                {
                                                                System.out.println("status code not expected  : Fail" );
                                                                
                                                                 }
                                                }
                                                
                                                catch(Exception e)
                                                {
                                                                e.printStackTrace();
                                                }
                                                }
                
                                
                                
                                
                
                @AfterTest
                public static void closeDriver() {
                                driver.quit();
                }
                
                

                
}
