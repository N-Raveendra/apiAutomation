package tests.marketData.stock;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;


public class LookUpWeekOf {

	String badClient = "999999";
	
	String symbolInput = "USB.N";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;	
	IMarketDataRequest marketRequestFrBdnUnAuth;	
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stock");
		
		//For Unauthorized and Forbidden cases
		marketRequestFrBdnUnAuth = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stock/Lookup/WeekOf");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void stockLookUpWeekOf200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("date", "2016-03-09");
		
		marketRequest.get("/Lookup/WeekOf", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void stockLookUpWeekOf_WithPastTradingDate200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
				.addQueryParam("date", "2015-11-02");
		
		marketRequest.get("/Lookup/WeekOf", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void stockLookUpWeekOf_WithPastNonTradingDate200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
				.addQueryParam("date", "2015-12-25");
		
		marketRequest.get("/Lookup/WeekOf", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void stockLookUpWeekOf401() {
		marketRequestFrBdnUnAuth.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void stockLookUpWeekOf403() {
		marketRequestFrBdnUnAuth.validateForbiddenStatus();
	}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpWeekOf_InvalidClientId400() {
		
		//For invalid client id
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("date", "2015-12-25");
		
		marketRequest.get(badClient, "/Lookup/WeekOf", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpWeekOf_WithInvalidDate400() {
		
		//For invalid date
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("date", "2015-121-021");
		
		marketRequest.get("/Lookup/WeekOf", null, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpWeekOf_InvalidSymbol400() {
		
		//For invalid Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("symbol", "abc.XYZInvalid").and()
		   	   .addQueryParam("date", "2015-12-02");
		
		marketRequest.get("/Lookup/WeekOf", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpWeekOf_FutureDate400() {
		
		//For Future Date
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("date", "2020-12-21");
		
		marketRequest.get("/Lookup/WeekOf", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpWeekOf_WithoutSymbol400() {
		
		//For Without Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("date", "2015-12-02");
		
		marketRequest.get("/Lookup/WeekOf", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpWeekOf_WithoutDate400() {
		
		//For Without Date
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput);
		
		marketRequest.get("/Lookup/WeekOf", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	//-------------------------- 404 - Not Found Response validations--------------------
	
	// Invalid API Route
	@Test(groups={"notFound","full"})
	public void stockLookUpWeekOf_InvalidRoute404() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("date", "2015-12-02");
		
		marketRequest.get("/oLookup/WeeksOf", reqSpec, HttpStatus.SC_NOT_FOUND, null);
	}
	
	// Incomplete API segment
	@Test(groups={"notFound","full"})
	public void stockLookUpWeekOf_IncompleteSeg404() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("date", "2015-12-02");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_NOT_FOUND, null);
	}
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stockLookUpWeekOf_post_MthdNtAlwd405() {
		
		marketRequest.post("/Lookup/WeekOf",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stockLookUpWeekOf_put_MthdNtAlwd405() {
			
		marketRequest.put("/Lookup/WeekOf",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stockLookUpWeekOf_delete_MthdNtAlwd405() {
			
		marketRequest.delete("/Lookup/WeekOf", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
	}
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void stockLookUpWeekOfSchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
		   	 .addQueryParam("date", "2015-12-02");

		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/Lookup/WeekOf", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void stockLookUpWeekOfWithNonTradingDate() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
	   	 	 .addQueryParam("date", "2015-12-25");

		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/Lookup/WeekOf", reqSB, HttpStatus.SC_OK, respSB);
	}
	

	
	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void stockLookUpWeekOf_SchemaValidationDetailed() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
		   	 .addQueryParam("date", "2015-12-02");

		//Location of JSON Schema file
		String stockLookUpWkOfSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/stock/stockLookup_WeekOf-schema.json")).toString();	
						
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(stockLookUpWkOfSchemaLocation )));
				
		marketRequest.get("/Lookup/WeekOf", reqSB, HttpStatus.SC_OK, respSB);
	}

	
	
	
}
