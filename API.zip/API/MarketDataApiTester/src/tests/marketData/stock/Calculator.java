package tests.marketData.stock;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class Calculator {
	
	String badClient = "999999";
	
	String symbolInput = "USB.N";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	
	IMarketDataRequest marketRequest;	
	IMarketDataRequest marketRequest_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stock/Calculator");
		marketRequest_IncompleteSeg = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stock");
	}
	

	//-------------------------- 200 - OK Response validations-----------------------------
	
	// with Shares as the filter
	@Test(groups={"getOk","smoke","full", "market"})
	public void stockCalculator_Shares_200() {
		
		RequestSpecBuilder stClcReqSpec = new RequestSpecBuilder();
		stClcReqSpec.addQueryParam("symbol", symbolInput).and()
					.addQueryParam("date", "2016-06-13").and()
					.addQueryParam("shares", "5");
		
		marketRequest.get("", stClcReqSpec, HttpStatus.SC_OK, null);
		
	}
	
	//with Value as the filter
	@Test(groups={"getOk","smoke","full", "market"})
	public void stockCalculator_Value_200() {
		
		RequestSpecBuilder stClcReqSpec = new RequestSpecBuilder();
		stClcReqSpec.addQueryParam("symbol", symbolInput).and()
					.addQueryParam("date", "2016-06-13").and()
					.addQueryParam("Value", "5");
		
		marketRequest.get("", stClcReqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void stockCalculator401() {
		marketRequest.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void stockCalculator403() {
		marketRequest.validateForbiddenStatus();
	}
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void stockCalculator_InvalidClientId400() {
		
		//For invalid client id
		RequestSpecBuilder stClcReqSpec = new RequestSpecBuilder();		
		stClcReqSpec.addQueryParam("symbol", symbolInput).and()
					.addQueryParam("date", "2016-06-13").and()
					.addQueryParam("shares", "5");
		
		marketRequest.get(badClient, "", stClcReqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockCalculator_InvalidShares400() { 
		 
		//For invalid Shares
		RequestSpecBuilder stClcRegSpecInvalidShares = new RequestSpecBuilder();
		stClcRegSpecInvalidShares = new RequestSpecBuilder();
		stClcRegSpecInvalidShares.addQueryParam("symbol", symbolInput).and()
					.addQueryParam("date", "2016-06-13").and()
					.addQueryParam("shares", "abcd");
				
		marketRequest.get("", stClcRegSpecInvalidShares, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockCalculatorWithoutShares400() {
		
		//For missing Shares
		RequestSpecBuilder stClcRegSpecMissingShares = new RequestSpecBuilder();
		stClcRegSpecMissingShares.addQueryParam("symbol", symbolInput).and()
								 .addQueryParam("date", "2016-06-13");
				
		marketRequest.get("", stClcRegSpecMissingShares, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockCalculator_InvalidDate400() {
		
		
		//For invalid Date
		RequestSpecBuilder stClcRegSpecInvalidDate = new RequestSpecBuilder();
		stClcRegSpecInvalidDate.addQueryParam("symbol", symbolInput).and()
								.addQueryParam("date", "20151202000").and()
								.addQueryParam("shares", "5");
						
		marketRequest.get("", stClcRegSpecInvalidDate, HttpStatus.SC_BAD_REQUEST, null);
	
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockCalculator_WithoutDate400() {
		
		//For missing Date
		RequestSpecBuilder stClcRegSpecMissingDate = new RequestSpecBuilder();		
		stClcRegSpecMissingDate.addQueryParam("symbol", symbolInput).and()
							   .addQueryParam("shares", "5");
						
		marketRequest.get("", stClcRegSpecMissingDate, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockCalculator_InvalidSymbol400() {
		
		//For invalid Symbol
		RequestSpecBuilder stClcRegSpecInvalidSymbol = new RequestSpecBuilder();
		stClcRegSpecInvalidSymbol.addQueryParam("symbol", "ABCDE").and()
								 .addQueryParam("date", "2016-06-13").and()
								 .addQueryParam("shares", "5");
								
		marketRequest.get("", stClcRegSpecInvalidSymbol, HttpStatus.SC_BAD_REQUEST, null);
						
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockCalculatorWithoutSymbol400() {
									
		//For missing Symbol
		RequestSpecBuilder stClcRegSpecMissingSymbol = new RequestSpecBuilder();		
		stClcRegSpecMissingSymbol.addQueryParam("date", "2016-06-13").and()
								 .addQueryParam("shares", "5");
								
		marketRequest.get("", stClcRegSpecMissingSymbol, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	@Test(groups={"badRequests","full"})
	public void stockCalculatorWithoutValueFilter400() {
									
		//Without Value filter
		RequestSpecBuilder stClcRegSpecMissingSymbol = new RequestSpecBuilder();		
		stClcRegSpecMissingSymbol.addQueryParam("symbol",symbolInput).and()
								.addQueryParam("date", "2016-06-13");
								
		marketRequest.get("", stClcRegSpecMissingSymbol, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	@Test(groups={"badRequests","full"})
	public void stockCalculatorWith_InvalidValueFilter400() {
									
		//with Invalid Value filter
		RequestSpecBuilder stClcRegSpecMissingSymbol = new RequestSpecBuilder();		
		stClcRegSpecMissingSymbol.addQueryParam("symbol",symbolInput).and()
								.addQueryParam("date", "2016-06-13").and()
								.addQueryParam("Values", "-5");
								
		marketRequest.get("", stClcRegSpecMissingSymbol, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	//-------------------------- 404 - Not Found Response validations--------------------
	
	// Invalid API Route
	@Test(groups={"notFound","smoke","full"})
	public void stockCalculator_Invalid_API_Route404() {
		
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
					.addQueryParam("date", "2016-06-13").and()
					.addQueryParam("shares", "5");
		
		marketRequest.get("/zzz", reqSB, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Incomplete API Segment
	@Test(groups={"notFound","full"})
	public void stockCalculator_IncompleteSeg404() {
		
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
					.addQueryParam("date", "2016-06-13").and()
					.addQueryParam("shares", "5");
		
		marketRequest_IncompleteSeg.get("", reqSB, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
		@Test(groups={"mthdNtAlwd","full"})
		public void stockCalculator_post_MthdNtAlwd405() {
			
			marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void stockCalculator_put_MthdNtAlwd405() {
			
			marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void stockCalculator_delete_MthdNtAlwd405() {
			
			marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void stockCalculatorSchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
					.addQueryParam("date", "2016-06-13").and()
					.addQueryParam("shares", "5");
				
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	

	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void stockCalculator_SchemaValidationDetailed() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
					.addQueryParam("date", "2016-06-13").and()
					.addQueryParam("shares", "5");
		
		//Location of JSON Schema file
		String stockCalculatorSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/stock/stock_calculator-schema.json")).toString();	
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(stockCalculatorSchemaLocation )));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}

	
	
	
	

}
