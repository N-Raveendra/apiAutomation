package tests.marketData.stock;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;


public class LookUp {

	String badClient = "999999";
	
	String symbolInput = "USB.N";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;	
	
	//Added by Puneeth 20160425
	IMarketDataRequest marketRequest404;
		
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stock/Lookup");
		
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void stockLookUp200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("date", "2015-12-29");
		
		marketRequest.get( "", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void stockLookUp401() {
		marketRequest.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void stockLookUp403() {
		marketRequest.validateForbiddenStatus();
	}
	
	//-------------------------- 404 - Not Found Response validations--------------------
	
		// Invalid API Route
		@Test(groups={"notFound","full"})
		public void stockLookUp404() {
			
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			reqSpec.addQueryParam("symbol", symbolInput).and()
				   .addQueryParam("date", "2016-06-13");
			
			//Added by Puneeth 20160425
			marketRequest404 = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stocks/Lookup");
			marketRequest404.get("", reqSpec, HttpStatus.SC_NOT_FOUND, null);
			//marketRequest.get( "", reqSpec, HttpStatus.SC_OK, null);
			
		}
		
		// Incomplete API route
		@Test(groups={"notFound","full"})
		public void stockLookUp_IncompleteSeg_404() {
			
			RequestSpecBuilder reqSpec = new RequestSpecBuilder();
			reqSpec.addQueryParam("symbol", symbolInput).and()
				   .addQueryParam("date", "2016-06-13");
			
			//Added by Madhu 20160620
			marketRequest404 = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stock");
			marketRequest404.get("", reqSpec, HttpStatus.SC_NOT_FOUND, null);
			
		}
		
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void stockLookUp_InvalidClientId400() {
		
		//For invalid client id
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("date", "2015-12-29");
		
		marketRequest.get(badClient, "", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUp_WithoutSymbol400() {
		
		//Without Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("date", "2015-12-29");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUp_WithoutDate400() {
		
		//Without Date
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("symbol", symbolInput);
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUp_InvalidDate400() {
		
		//With Invalid Date
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("date", "20155-12-2999");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUp_InvalidSymbol400() {
		
		//With Invalid Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", "abc.XYZInvalid").and()
			   .addQueryParam("date", "2015-12-29");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stockLookUp_post_MthdNtAlwd405() {
		
		marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stockLookUp_put_MthdNtAlwd405() {
		
		marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stockLookUp_delete_MthdNtAlwd405() {
		
		marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void stockLookUpSchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
			 .addQueryParam("date", "2015-12-29");

		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get( "", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	

	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void stockLookUp_SchemaValidationDetailed() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
			 .addQueryParam("date", "2015-12-29");

		//Location of JSON Schema file
		String stockLookUpSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/stock/stockLookUp-schema.json")).toString();	
				
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(stockLookUpSchemaLocation )));
				
		marketRequest.get( "", reqSB, HttpStatus.SC_OK, respSB);
	}

	
	
}
