package tests.marketData.stock;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;


public class LookUpYearEnd {

	String badClient = "999999";
	
	String symbolInput = "USB.N";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;
	IMarketDataRequest marketRequest404;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stock/Lookup/Yearly");
		marketRequest404 = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stock");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void stockLookUpYearEnd200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput);
		
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void stockLookUpYearEndWithDates200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
				.addQueryParam("start", "2010").and()
				.addQueryParam("end", "2015");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void stockLookUpYearEnd401() {
		marketRequest.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void stockLookUpYearEnd403() {
		marketRequest.validateForbiddenStatus();
	}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpYearEnd_InvalidClientId400() {
		
		//For invalid client id
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput);
		
		marketRequest.get(badClient, "", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpYearEnd_WithoutSymbol400() {
		
		marketRequest.get("", null, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpYearEnd_InvalidSymbol400() {
		
		//For invalid Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("symbol", "abc.XYZInvalid");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpYearEnd_InvalidStartYear400() {
		
		//For invalid Start year
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("start", "0000").and()
			   .addQueryParam("end", "2014");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stockLookUpYearEnd_InvalidEndYear400() {
		
		//For invalid end year
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("start", "2001").and()
			   .addQueryParam("end", "0000");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}

	//-------------------------- 404 - Not Found validations-------------------------------
	
	//Invalid API Route
	@Test(groups={"notFound","full"})
	public void stockLookUpYearEnd_InvalidAPIRoute_404() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("start", "2001").and()
			   .addQueryParam("end", "2016");
		
		marketRequest404.get("S/Lookup/Yearly", reqSpec, HttpStatus.SC_NOT_FOUND, null);
		 
	}
	
	// Incomplete API Segment
	@Test(groups={"notFound","full"})
	public void stockLookUpYearEnd_IncompleteSeg_404() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput).and()
			   .addQueryParam("start", "2001").and()
			   .addQueryParam("end", "2016");
		
		marketRequest404.get("", reqSpec, HttpStatus.SC_NOT_FOUND, null);
		 
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stockLookUpYearEnd_post_MthdNtAlwd405() {
		
		marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stockLookUpYearEnd_put_MthdNtAlwd405() {
		
		marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stockLookUpYearEnd_delete_MthdNtAlwd405() {
		
		marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void stockLookUpYearEndSchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput);

		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void stockLookUpYearEndWithStartEndYearSchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput).and()
		   	 .addQueryParam("start", "2010").and()
		     .addQueryParam("end", "2015");

		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}
	

	
	//-------------------------- Detailed JSON SCHEMA Validations--------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void stockLookUpYearEnd_SchemaValidationDetailed() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", symbolInput);

		//Location of JSON Schema file
		String stockLookUpYrEndSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/stock/stockLookup_YrEnd-schema.json")).toString();	
								
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(stockLookUpYrEndSchemaLocation )));
				
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}

	
	
	
}
