package tests.marketData;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;


public class InsiderOwnership {

	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;	
	IMarketDataRequest marketRequest_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Insiders/Ownership");
		marketRequest_IncompleteSeg = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Insiders");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void insiderOwnership200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("cik", "1001288");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void insiderOwnership401() {
		marketRequest.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void insiderOwnership403() {
		marketRequest.validateForbiddenStatus();
	}
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void insiderOwnership_InvalidClientId400() {
		
		//For invalid client id
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("cik", "1001288");
		
		marketRequest.get(badClient, "", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void insiderOwnership_InvalidCIK400() {
		
		//For invalid CIK
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("cik", "1001288_invalid");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	//-------------------------- 404 - Not Found validations-----------------------------
	//404 validations are added by Madhu
	
	@Test(groups={"notFound","full"})
	public void insiderOwnership_InvalidApi_Route_404() {
		
		//For invalid API Route
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("cik", "1001288");
		
		marketRequest.get("/zzz", reqSpec, HttpStatus.SC_NOT_FOUND, null);
		 
	}
	
	@Test(groups={"notFound","full"})
	public void insiderOwnership_Incomplete_Segment_404() {
		
		//For Incomplete API segment
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("cik", "1001288");
		
		marketRequest_IncompleteSeg.get("", reqSpec, HttpStatus.SC_NOT_FOUND, null);
		 
	}
		
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void insiderOwnership_post_MthdNtAlwd405() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("cik", "1001288");
		
		marketRequest.post("",inputJSON405, reqSpec, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void insiderOwnership_put_MthdNtAlwd405() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("cik", "1001288");
		
		marketRequest.put("",inputJSON405, reqSpec, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void insiderOwnership_delete_MthdNtAlwd405() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("cik", "1001288");
		
		marketRequest.delete("", reqSpec, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void insiderOwnershipSchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("cik", "1001288");

		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	
	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
		@Test(groups={"schemaValidationDetailed","full"})
		public void insiderOwnership_SchemaValidationDetailed() {
			
			//Building request specifications with the query parameters
			RequestSpecBuilder reqSB = new RequestSpecBuilder();
			reqSB.addQueryParam("cik", "1001288");

			String insiderOwnershipSchemaLocation = Paths.get(marketRequest.buildSchemaPath("insiderOwnership-schema.json")).toString();		
			
			ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
			respSpecBuilder.expectBody(matchesJsonSchema(new File(insiderOwnershipSchemaLocation)));
			
			marketRequest.get("", reqSB, HttpStatus.SC_OK, respSpecBuilder);
		}
	
	
	
}
