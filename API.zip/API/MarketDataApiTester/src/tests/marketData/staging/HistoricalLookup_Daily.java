package tests.marketData.staging;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.configuration.IConfigurationRequest;
import api.market.IMarketDataRequest;
import api.migration.IMigrationRequest;


public class HistoricalLookup_Daily {

	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;	
	IMigrationRequest MarketRequest_IncompleteRoute;

	//Added by Puneeth 20160425
	IMarketDataRequest marketRequest404;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Staging/Stock/Lookup");
		MarketRequest_IncompleteRoute = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "Staging/Stock/Loo");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "marketStaging"})
	public void Staging_stockLookUp200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", "USB.N").and()
			   .addQueryParam("date", "2015-12-29");
		
		marketRequest.get( "", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void Staging_stockLookUp401() {
		marketRequest.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void Staging_stockLookUp403() {
		marketRequest.validateForbiddenStatus();
	}
	
	//-------------------------- 404 - Not Found Response validations--------------------
	
			@Test(groups={"notFound","full"})
			public void Staging_stockLookUp404() {
				
				RequestSpecBuilder reqSpec = new RequestSpecBuilder();
				reqSpec.addQueryParam("symbol", "USB.N").and()
					   .addQueryParam("date", "2015-12-02");
				
			//Added by Puneeth 20160425
			marketRequest404 = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Stocks/Lookup");
			marketRequest404.get( "", reqSpec, HttpStatus.SC_NOT_FOUND, null);
				
			}
			
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void Staging_stockLookUp_InvalidClientId400() {
		
		//For invalid client id
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", "USB.N").and()
			   .addQueryParam("date", "2015-12-29");
		
		marketRequest.get(badClient, "", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void Staging_stockLookUp_WithoutSymbol400() {
		
		//Without Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("date", "2015-12-29");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void Staging_stockLookUp_WithoutDate400() {
		
		//Without Date
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("symbol", "USB.N");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void Staging_stockLookUp_InvalidDate400() {
		
		//With Invalid Date
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", "USB.N").and()
			   .addQueryParam("date", "20155-12-2999");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void Staging_stockLookUp_InvalidSymbol400() {
		
		//With Invalid Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", "abc.XYZInvalid").and()
			   .addQueryParam("date", "2015-12-29");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void Staging_stockLookUp_post_MthdNtAlwd405() {
		
		marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void Staging_stockLookUp_put_MthdNtAlwd405() {
		
		marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void Staging_stockLookUp_delete_MthdNtAlwd405() {
		
		marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void Staging_stockLookUpSchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", "USB.N").and()
			 .addQueryParam("date", "2015-12-29");

		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get( "", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	

	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void Staging_stockLookUp_SchemaValidationDetailed() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", "USB.N").and()
			 .addQueryParam("date", "2015-12-29");

		//Location of JSON Schema file
		String stockLookUpSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/staging/Staging_stockLookUp-schema.json")).toString();	
				
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(stockLookUpSchemaLocation )));
				
		marketRequest.get( "", reqSB, HttpStatus.SC_OK, respSB);
	}

	
	
}
