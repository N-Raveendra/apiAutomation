package tests.marketData.staging;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class HistoricalLookup_StockCalculator {
	
	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;	
	IMarketDataRequest marketRequest_IncmpltSegment ;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Staging/Stock/Calculator");
		marketRequest_IncmpltSegment = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Staging/Stock");
	}
	

	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"getOk","smoke","full", "marketStaging"})
	public void staging_stockCalc_WithShares200() {
		
		RequestSpecBuilder stgStckClcReqSpec = new RequestSpecBuilder();
		stgStckClcReqSpec.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("date", "2015-03-02").and()
					.addQueryParam("shares", "1");
		
		marketRequest.get("", stgStckClcReqSpec, HttpStatus.SC_OK, null);
		
	}
	
	@Test(groups={"getOk","smoke","full", "marketStaging"})
	public void staging_stockCalc_WithValue200() {
		
		RequestSpecBuilder stgStckClcReqSpec = new RequestSpecBuilder();
		stgStckClcReqSpec.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("date", "2015-03-02").and()
					.addQueryParam("Value", "1");
		
		marketRequest.get("", stgStckClcReqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void staging_stockCalculator401() {
		marketRequest.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void staging_stockCalculator403() {
		marketRequest.validateForbiddenStatus();
	}
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void staging_StckCalc_InvalidClientId400() {
		
		//For invalid client id
		RequestSpecBuilder stClcReqSpec = new RequestSpecBuilder();		
		stClcReqSpec.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("date", "2015-12-02").and()
					.addQueryParam("shares", "5");
		
		marketRequest.get(badClient, "", stClcReqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void staging_StckCalc_InvalidShares400() { 
		 
		//For invalid Shares
		RequestSpecBuilder stgStckClcRegSpecInvalidShares = new RequestSpecBuilder();
		stgStckClcRegSpecInvalidShares = new RequestSpecBuilder();
		stgStckClcRegSpecInvalidShares.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("date", "2015-12-02").and()
					.addQueryParam("shares", "abcd");
				
		marketRequest.get("", stgStckClcRegSpecInvalidShares, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void staging_StckCalc_WithoutShares400() {
		
		//For missing Shares
		RequestSpecBuilder stClcRegSpecMissingShares = new RequestSpecBuilder();
		stClcRegSpecMissingShares.addQueryParam("symbol", "USB.N").and()
								 .addQueryParam("date", "2015-12-02");
				
		marketRequest.get("", stClcRegSpecMissingShares, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void staging_StckCalc_InvalidDate400() {
		
		
		//For invalid Date
		RequestSpecBuilder stClcRegSpecInvalidDate = new RequestSpecBuilder();
		stClcRegSpecInvalidDate.addQueryParam("symbol", "USB.N").and()
								.addQueryParam("date", "20151202000").and()
								.addQueryParam("shares", "5");
						
		marketRequest.get("", stClcRegSpecInvalidDate, HttpStatus.SC_BAD_REQUEST, null);
	
	}
	
	
	@Test(groups={"badRequests","full"})
	public void staging_StckCalc_WithoutDate400() {
		
		//For missing Date
		RequestSpecBuilder stClcRegSpecMissingDate = new RequestSpecBuilder();		
		stClcRegSpecMissingDate.addQueryParam("symbol", "USB.N").and()
							   .addQueryParam("shares", "5");
						
		marketRequest.get("", stClcRegSpecMissingDate, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void staging_StckCalc_InvalidSymbol400() {
		
		//For invalid Symbol
		RequestSpecBuilder stClcRegSpecInvalidSymbol = new RequestSpecBuilder();
		stClcRegSpecInvalidSymbol.addQueryParam("symbol", "ABCDE").and()
								 .addQueryParam("date", "2015-12-02").and()
								 .addQueryParam("shares", "5");
								
		marketRequest.get("", stClcRegSpecInvalidSymbol, HttpStatus.SC_BAD_REQUEST, null);
						
	}
	
	
	@Test(groups={"badRequests","full"})
	public void staging_StckCalc_WithoutSymbol400() {
									
		//For missing Symbol
		RequestSpecBuilder stClcRegSpecMissingSymbol = new RequestSpecBuilder();		
		stClcRegSpecMissingSymbol.addQueryParam("date", "2015-12-02").and()
								 .addQueryParam("shares", "5");
								
		marketRequest.get("", stClcRegSpecMissingSymbol, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void staging_StckCalc_WithoutAnyFilters400() {
									
		//For without any of the filters
										
		marketRequest.get("", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	//-------------------------- 404 - Not Found Response validations--------------------
	
	@Test(groups={"badRequests","smoke","full"})
	public void staging_StckCalc_InvalidAPIroute404() {
		
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("date", "2015-12-02").and()
					.addQueryParam("shares", "5");
		
		marketRequest.get("/zzz", reqSB, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	@Test(groups={"badRequests","smoke","full"})
	public void staging_StckCalc_InCompltSeg404() {
		
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
				
		marketRequest_IncmpltSegment.get("", reqSB, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stagingStckCalc_post_MthdNtAlwd405() {
		
		marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stagingStckCalc_put_MthdNtAlwd405() {
		
		marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stagingStckCalc_delete_MthdNtAlwd405() {
		
		marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void staging_StckCalc_SchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("date", "2015-12-02").and()
					.addQueryParam("shares", "5");
				
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	

	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void staging_StckCalc_SchemaValidationDetailed() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("date", "2015-12-02").and()
					.addQueryParam("shares", "5");
		
		//Location of JSON Schema file
		String stg_stockCalculatorSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/staging/historicalLkupStaging_StckCalc.json")).toString();	
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(stg_stockCalculatorSchemaLocation )));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}



}
