package tests.marketData.staging;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class HistoricalLookup_Yearly {

	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;	
	
	// Used for Forbidden, Unauthorized and Schema validation scripts
	IMarketDataRequest marketRequestFrBdnUnAuth;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Staging/Stock/");
	
		//For Unauthorized and Forbidden cases
		marketRequestFrBdnUnAuth = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Staging/Stock/Lookup/Yearly");
	}
	

	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"getOk","smoke","full", "marketStaging"})
	public void stagingYearly200() {
		
		RequestSpecBuilder stagingYearlyReqSpec = new RequestSpecBuilder();
		stagingYearlyReqSpec.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("start", "2013").and()
					.addQueryParam("end", "2015");
		
		marketRequest.get("Lookup/Yearly", stagingYearlyReqSpec, HttpStatus.SC_OK, null);
		
	}
	
		
	@Test(groups={"getOk","smoke","full", "marketStaging"})
	public void stagingYearly_WithoutStart200() {
		
		//For missing Start date filter
		RequestSpecBuilder stgYearlyRegSpecWithoutStart = new RequestSpecBuilder();
		stgYearlyRegSpecWithoutStart.addQueryParam("symbol", "USB.N").and()
								 .addQueryParam("end", "2015");
				
		marketRequest.get("Lookup/Yearly", stgYearlyRegSpecWithoutStart, HttpStatus.SC_OK, null);
		
	}
	
	@Test(groups={"getOk","smoke","full", "marketStaging"})
	public void stagingYearly_WithoutEnd200() {
		
		//For missing End date filter
		RequestSpecBuilder stgYearlyRegSpecWithoutEnd = new RequestSpecBuilder();
		stgYearlyRegSpecWithoutEnd.addQueryParam("symbol", "USB.N").and()
								 .addQueryParam("start", "2010");
				
		marketRequest.get("Lookup/Yearly", stgYearlyRegSpecWithoutEnd, HttpStatus.SC_OK, null);
		
	}
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void stagingYearly401() {
		marketRequestFrBdnUnAuth.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void stagingYearly403() {
		marketRequestFrBdnUnAuth.validateForbiddenStatus();
	}
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void stagingYearly_InvalidClientId400() {
		
		//For invalid client id
		RequestSpecBuilder stagingYearlyReqSpec = new RequestSpecBuilder();		
		stagingYearlyReqSpec.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("start", "2013").and()
					.addQueryParam("end", "2015");
		
		marketRequest.get(badClient, "Lookup/Yearly", stagingYearlyReqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stagingYearly_WithOutSymbol400() { 
		 
		//For Without Symbol
		RequestSpecBuilder stgYearlyRegSpecWithOutSymbol = new RequestSpecBuilder();
		stgYearlyRegSpecWithOutSymbol = new RequestSpecBuilder();
		stgYearlyRegSpecWithOutSymbol.addQueryParam("start", "2013").and()
									.addQueryParam("end", "2015");
				
		marketRequest.get("Lookup/Yearly", stgYearlyRegSpecWithOutSymbol, HttpStatus.SC_BAD_REQUEST, null);
		
	}

		
	@Test(groups={"badRequests","full"})
	public void stagingYearly_InvalidSymbol400() {
		
		
		//For invalid Symbol
		RequestSpecBuilder stgYearlyRegSpecInvalidSymbol = new RequestSpecBuilder();
		stgYearlyRegSpecInvalidSymbol.addQueryParam("symbol", "N").and()
								.addQueryParam("start", "2013").and()
								.addQueryParam("end", "2015");
						
		marketRequest.get("Lookup/Yearly", stgYearlyRegSpecInvalidSymbol, HttpStatus.SC_BAD_REQUEST, null);
	
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stgYearly_InvalidStart400() {
		
		//For Invalid start date filter
		RequestSpecBuilder stgYearlyRegSpecInvalidStart = new RequestSpecBuilder();		
		stgYearlyRegSpecInvalidStart.addQueryParam("symbol", "USB.N").and()
								.addQueryParam("start", "2").and()
								.addQueryParam("end", "2015");
						
		marketRequest.get("Lookup/Yearly", stgYearlyRegSpecInvalidStart, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stgYearly_InvalidEnd400() {
		
		//For invalid End date filter
		RequestSpecBuilder stgYearlyRegSpecInvalidEnd = new RequestSpecBuilder();
		stgYearlyRegSpecInvalidEnd.addQueryParam("symbol", "USB.N").and()
								 .addQueryParam("start", "2010").and()
								 .addQueryParam("end", "5");
								
		marketRequest.get("Lookup/Yearly", stgYearlyRegSpecInvalidEnd, HttpStatus.SC_BAD_REQUEST, null);
						
	}
	
	
	@Test(groups={"badRequests","full"})
	public void stgYearly_WithoutAnyFilters400() {

		// For without any of the filters	
								
		marketRequest.get("Lookup/Yearly", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	//-------------------------- 404 - Not Found Response validations--------------------
	
	@Test(groups={"badRequests","smoke","full"})
	public void stgYearly_InvalidAPIroute404() {
		
		RequestSpecBuilder stgYearlyreqSBInvalidAPIroute = new RequestSpecBuilder();
		stgYearlyreqSBInvalidAPIroute.addQueryParam("symbol", "USB.N").and()
									 .addQueryParam("start", "2010").and()
									 .addQueryParam("end", "2015");
		
		marketRequest.get("zzz/Lookup/Yearly", stgYearlyreqSBInvalidAPIroute, HttpStatus.SC_NOT_FOUND, null);
	}			

	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stagingYearly_post_MthdNtAlwd405() {
		
		marketRequest.post("Lookup/Yearly",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stagingYearly_put_MthdNtAlwd405() {
		
		marketRequest.put("Lookup/Yearly",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void stagingYearly_delete_MthdNtAlwd405() {
		
		marketRequest.delete("Lookup/Yearly", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	

	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void stagingYearlySchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("start", "2012").and()
					.addQueryParam("end", "2015");
				
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("Lookup/Yearly", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	
	
	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void stagingYearly_SchemaValidationDetailed() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("symbol", "USB.N").and()
					.addQueryParam("start", "2010").and()
					.addQueryParam("end", "2015");
		
		//Location of JSON Schema file
		String stagingYearlySchemaLocation = Paths.get(marketRequest.buildSchemaPath("/staging/historicalLkupStaging_Yearly.json")).toString();	
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(stagingYearlySchemaLocation )));
		
		marketRequest.get("Lookup/Yearly", reqSB, HttpStatus.SC_OK, respSB);
	}
		
}