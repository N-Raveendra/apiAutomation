package tests.marketData;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class Filings {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	String secAccessionNumberValid = "0001018724-15-000006";
	//0001104659-15-080818
	String secAccessionNumberInvalid = "0001104659-15-12345";
	
	String secResource = "RFNFUT0xJlNFUT0mU1FERVNDPVNFQ1RJT05fQk9EWSZleHA9JnN1YnNpZD01Nw==";
	String secInvalidResource = "jjjjjgjgjhgjgjhgjhgjgjgjggjgjgjhghgjhjhjh";
	
	IMarketDataRequest marketRequest;
	IMarketDataRequest marketRequestFrBdnUnAuth;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "SecFilings");
		
		//For Unauthorized and Forbidden cases
		marketRequestFrBdnUnAuth = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "SecFilings/"+secAccessionNumberValid+"/toc");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketSecFilingssecFilings_AccNo_Toc200() {
		
		//secFilings_AccNo_Toc
		marketRequest.get("/"+secAccessionNumberValid+"/toc", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketSecFilingssecFilings_AccNo_html200() {
		
		//secFilings_AccNo_html
		marketRequest.get("/"+secAccessionNumberValid+"/html", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketSecFilingssecFilings_AccNo_Html_resource200() {
		
		//secFilings_AccNo_Html_resource
		marketRequest.get("/"+secAccessionNumberValid+"/html/"+secResource, null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketSecFilingssecFilings_AccNo_toc_xbrl200() {
		
		//secFilings_AccNo_toc_xbrl
		marketRequest.get("/"+secAccessionNumberValid+"/toc/xbrl", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketSecFilingssecFilings_AccNo_Xbrl_Resource200() {
		
		//secFilings_AccNo_Xbrl_Resource
		marketRequest.get("/"+secAccessionNumberValid+"/xbrl/"+secResource, null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"}, timeOut=60000)
	public void marketSecFilingssecFilings_AccNo_Xbrl_Viewer200() {
		
		//secFilings_AccNo_Xbrl_Viewer
		marketRequest.get("/"+secAccessionNumberValid+"/xbrl/viewer", null, HttpStatus.SC_OK, null);

	}

	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void marketSecFilings401() {
		marketRequestFrBdnUnAuth.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void marketSecFilings403() {
		marketRequestFrBdnUnAuth.validateForbiddenStatus();
	}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void marketSecFilings_AccNo_TocInvalidAN400() {
		
		//secFilings_AccNo_Toc - Invalid Accession Number
		marketRequest.get("/"+secAccessionNumberInvalid+"/toc", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketSecFilings_AccNo_htmlInvalidAN400() {
				
		//secFilings_AccNo_html - Invalid Accession Number
		marketRequest.get("/"+secAccessionNumberInvalid+"/html", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketSecFilings_AccNo_Html_resourceInvalidAN400() {
		
		//secFilings_AccNo_Html_resource - Invalid Accession Number
		marketRequest.get("/"+secAccessionNumberInvalid+"/html/"+secResource, null, HttpStatus.SC_BAD_REQUEST, null);

	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketSecFilings_AccNo_toc_xbrlInvalidAN400() {
			
		//secFilings_AccNo_toc_xbrl - Invalid Accession Number
		marketRequest.get("/"+secAccessionNumberInvalid+"/toc/xbrl", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketSecFilings_AccNo_Xbrl_ResourceInvalidAN400() {
	
		//secFilings_AccNo_Xbrl_Resource - Invalid Accession Number
		marketRequest.get("/"+secAccessionNumberInvalid+"/xbrl/"+secResource, null, HttpStatus.SC_BAD_REQUEST, null);
	
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketSecFilings_AccNo_Xbrl_ViewerInvalidAN400() {
		
		//secFilings_AccNo_Xbrl_Viewer - Invalid Accession Number
		marketRequest.get("/"+secAccessionNumberInvalid+"/xbrl/viewer", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	@Test(groups={"badRequests","full"})
	public void marketSecFilings_AccNo_html_Rsrc_InvalidResource400() {
		
		//secFilings_AccNo_Html_Resource - Invalid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/html/"+secInvalidResource, null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	@Test(groups={"badRequests","full"})
	public void marketSecFilings_AccNo_xbrl_Rsrc_InvalidResource400() {
		
		//secFilings_AccNo_Xbrl_Resource - Invalid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/xbrl/"+secInvalidResource, null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	// 404 Validations are added by Madhu
	
	//-------------------------- 404 - Not Found validations-----------------------
	
	//404 for {acc-no}/{TOC} endpoint
	// Invalid API Route 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_Toc_InvalidAPIroute_404() {
		
		//{acc-no}/{TOC}/zzz - Valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/toc/zzz", null, HttpStatus.SC_NOT_FOUND, null);
	}
	
	// Incomplete API Segment 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_Toc_Incomplete_Seg_404() {
		
		// {acc-no}/ - Valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/", null, HttpStatus.SC_NOT_FOUND, null);

	}
	//----------------------------------
	
	//404 for {acc-no}/{html} endpoint
	// Invalid API Route 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_html_InvalidAPIroute_404() {
		
		// {acc-no}/{html}/zzz - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/zzz/html", null, HttpStatus.SC_NOT_FOUND, null);
	}
	
	// Incomplete API Segment 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_html_Incomplete_Seg_404() {
		
		// {acc-no}/ht - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid, null, HttpStatus.SC_NOT_FOUND, null);

	}
	//----------------------------------
	
	
	//404 for {acc-no}/html/{resource} endpoint
	// Invalid API Route 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_html_resrc_InvalidAPIroute_404() {
		
		//secFilings_AccNo_Xbrl_Viewer - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/html/"+secResource+"/zzz", null, HttpStatus.SC_NOT_FOUND, null);
	}
	
	// Incomplete API Segment 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_html_resrc_Incomplete_Seg_404() {
		
		//secFilings_AccNo - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid, null, HttpStatus.SC_NOT_FOUND, null);

	}
	//----------------------------------
	
	// 404 for {acc-no}/toc/xbrl endpoint
	// Invalid API Route 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_toc_xbrl_InvalidAPIroute_404() {
		
		//secFilings_AccNo/toc/xbrl/zzz - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/toc/xbrl/zzz", null, HttpStatus.SC_NOT_FOUND, null);
	}
	
	// Incomplete API Segment 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_toc_xbrl_Incomplete_Seg_404() {
		
		//secFilings_AccNo/toc/xb - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/toc/xb", null, HttpStatus.SC_NOT_FOUND, null);

	}
	//-----------------------------------
	
	//404 for {acc-no}/xbrl/{resource} endpoint
	// Invalid API Route 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_xbrl_resrc_InvalidAPIroute_404() {
		
		//secFilings_AccNo/xbrl/resource/zzz - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/xbrl/"+secResource+"/zzz", null, HttpStatus.SC_NOT_FOUND, null);
	}
	
	// Incomplete API Segment 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_xbrl_resrc_Incomplete_Seg_404() {
		
		//secFilings_AccNo/xbr - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid, null, HttpStatus.SC_NOT_FOUND, null);

	}
	//-------------------------------------------
	
	//404 for {acc-no}/xbrl/viewer endpoint
	// Invalid API Route 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_xbrl_viewer_InvalidAPIroute_404() {
		
		//secFilings_AccNo/xbrl/viewer/zzz - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid+"/xbrl/viewer/zzz", null, HttpStatus.SC_NOT_FOUND, null);
	}
	
	// Incomplete API Segment 
	@Test(groups={"notFound","full"})
	public void marketSecFilings_AccNo_xbrl_viewer_Incomplete_Seg_404() {
		
		//secFilings_AccNo/xbrl/view - valid Accession Number
		marketRequest.get("/"+secAccessionNumberValid, null, HttpStatus.SC_NOT_FOUND, null);

	}
	
	
	
	
	
	
	
	
	
	
	//Added By Puneeth on 2016 Ap 19
	//-------------------------- 405 - Method Not Allowed validations-----------------------
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_AccNo_Toc_post_MthdNtAlwd405() {
			
			marketRequest.post("/"+secAccessionNumberValid+"/toc", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_AccNo_html_post_MthdNtAlwd405() {
			
			marketRequest.post("/"+secAccessionNumberValid+"/html", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_Html_resource_post_MthdNtAlwd405() {
			
			marketRequest.post("/"+secAccessionNumberValid+"/html/"+secResource, inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_toc_xbrl_post_MthdNtAlwd405() {
			
			marketRequest.post("/"+secAccessionNumberValid+"/toc/xbrl", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_Xbrl_Resource_post_MthdNtAlwd405() {
			
			marketRequest.post("/"+secAccessionNumberValid+"/xbrl/"+secResource, inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_Xbrl_Viewer_post_MthdNtAlwd405() {
			
			marketRequest.post("/"+secAccessionNumberValid+"/xbrl/viewer", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_AccNo_Toc_put_MthdNtAlwd405() {
			
			marketRequest.post("/"+secAccessionNumberValid+"/toc", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_AccNo_html_put_MthdNtAlwd405() {
			
			marketRequest.put("/"+secAccessionNumberValid+"/html", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_Html_resource_put_MthdNtAlwd405() {
			
			marketRequest.put("/"+secAccessionNumberValid+"/html/"+secResource, inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
			
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_toc_xbrl_put_MthdNtAlwd405() {
			
			marketRequest.put("/"+secAccessionNumberValid+"/toc/xbrl", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_Xbrl_Resource_put_MthdNtAlwd405() {
			
			marketRequest.put("/"+secAccessionNumberValid+"/xbrl/"+secResource, inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_Xbrl_Viewer_put_MthdNtAlwd405() {
			
			marketRequest.put("/"+secAccessionNumberValid+"/xbrl/viewer", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_AccNo_Toc_delete_MthdNtAlwd405() {
			
			marketRequest.delete("/"+secAccessionNumberValid+"/toc", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
		
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_AccNo_html_delete_MthdNtAlwd405() {
			
			marketRequest.delete("/"+secAccessionNumberValid+"/html", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
			
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_Html_resource_delete_MthdNtAlwd405() {
			
			marketRequest.delete("/"+secAccessionNumberValid+"/html/"+secResource, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
				
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_toc_xbrl_delete_MthdNtAlwd405() {
			
			marketRequest.delete("/"+secAccessionNumberValid+"/toc/xbrl", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
				
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_Xbrl_Resource_delete_MthdNtAlwd405() {
			
			marketRequest.delete("/"+secAccessionNumberValid+"/xbrl/"+secResource, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
			
	}
				
	@Test(groups={"mthdNtAlwd","full"})
	public void marketSecFilings_Xbrl_Viewer_delete_MthdNtAlwd405() {
			
			marketRequest.delete("/"+secAccessionNumberValid+"/xbrl/viewer", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
				
	}
		
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketSecFilings_AccNo_TocSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		
		//Basic schema validations for SEC Filings end points
		//secFilings_AccNo_Toc
		marketRequest.get("/"+secAccessionNumberValid+"/toc", null, HttpStatus.SC_OK, respSB);
	
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketSecFilings_AccNo_toc_xbrlSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		
		//Basic schema validations for SEC Filings end points
		//secFilings_AccNo_toc_xbrl
		marketRequest.get("/"+secAccessionNumberValid+"/toc/xbrl", null, HttpStatus.SC_OK, respSB);

	}
	
	
	
	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketSecFilings_AccNo_TocSchemaValidationDetailed() {
		
		String secTOC_SchemaLocation = Paths.get(marketRequest.buildSchemaPath("secFiling_TOC_schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(secTOC_SchemaLocation)));
		
		
		//Detailed schema validations for SEC Filings end points
		//secFilings_AccNo_Toc
		marketRequest.get("/"+secAccessionNumberValid+"/toc", null, HttpStatus.SC_OK, respSpecBuilder);
	
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketSecFilings_AccNo_toc_xbrlSchemaValidationDetailed() {
		
		String secTOCXbrl_SchemaLocation = Paths.get(marketRequest.buildSchemaPath("secFiling_TOC_XBRL_schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(secTOCXbrl_SchemaLocation)));
		
		
		//Detailed schema validations for SEC Filings end points
		//secFilings_AccNo_toc_xbrl
		marketRequest.get("/"+secAccessionNumberValid+"/toc/xbrl", null, HttpStatus.SC_OK, respSpecBuilder);

	}
	
}
