package tests.marketData.latest;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class Dividends {
	
	String badClient = "999999";	
	
	String symbolInput = "USB.N";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Latest/dividends");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "marketLatest"})
	public void marketLatestDividends200() {
		
		//with valid minDate
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-09-17T00:00:00").and()
			   .addQueryParam("symbol", symbolInput);
		
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void marketLatestDividends401() {
		marketRequest.validateUnauthorizedStatus();		
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void marketLatestDividends403() {
		marketRequest.validateForbiddenStatus();
		
	}
	
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void marketLatestDividends_InvalidClient400() {
		
		//with Invalid client id
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-09-17T00:00:00").and()
			   .addQueryParam("symbol", symbolInput);
		
		marketRequest.get(badClient, "", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestDividends_InvalidMinDate400() {
		
		//with invalid minDate
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "20155-019-117T00:00:00").and()
			   .addQueryParam("symbol", symbolInput);
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestDividends_WithoutMinDate400() {
		
		//without minDate
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("symbol", symbolInput);
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestDividends_InvalidSymbol400() {
		
		//with invalid Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-09-17T00:00:00").and()
			   .addQueryParam("symbol", "ABC.xyzInvalid");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestDividends_WithoutSymbol400() {
		
		//without Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-09-17T00:00:00");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestDividends_WithoutFilters400() {
		
		//without Query Parameters
		marketRequest.get("", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	//-------------------------- 404 - Not Found Response validations--------------------
	
	@Test(groups={"notFound","full"})
	public void marketLatestDividends_InvalidRoute404() {
		
		//with minDate and Symbol
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-09-17T00:00:00").and()
			   .addQueryParam("symbol", symbolInput);
		
		marketRequest.get("/abcInvalid/dividends", reqSpec, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
		@Test(groups={"mthdNtAlwd","full"})
		public void dividends_post_MthdNtAlwd405() {
			
			marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void dividends_put_MthdNtAlwd405() {
			
			marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void dividends_delete_MthdNtAlwd405() {
			
			marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketLatestDividends_SchemaValidation() {
		
		//Request specification with query parameters
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-09-17T00:00:00").and()
			    .addQueryParam("symbol", symbolInput);
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		
		//Basic schema validations 
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, respSB);


	}


	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketLatestDividends_SchemaValidationDetailed() {
		
		//Request specification with query parameters
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-09-17T00:00:00").and()
			    .addQueryParam("symbol", symbolInput);
		
		String latestDividendsSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/latest/dividends-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(latestDividendsSchemaLocation)));
		
		
		//Detailed schema validations 
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, respSpecBuilder);


	}

}
