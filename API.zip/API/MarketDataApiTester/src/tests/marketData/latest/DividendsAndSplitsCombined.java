package tests.marketData.latest;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;


public class DividendsAndSplitsCombined {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Latest/dividendsAndSplits");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "marketLatest"})
	public void marketLatestDividendsAndSplits200() {
		
		//with valid minDate
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-12-26");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void marketLatestDividendsAndSplits401() {
		marketRequest.validateUnauthorizedStatus();		
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void marketLatestDividendsAndSplits403() {
		marketRequest.validateForbiddenStatus();
		
	}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void marketLatestDividendsAndSplits_InvalidClient400() {
		
		//with Invalid client id
		RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
		reqSpecInvalidClient.addQueryParam("minDate", "2015-10-02");
		
		marketRequest.get(badClient, "", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestDividendsAndSplits_InvalidMinDate400() {
		
		//with invalid minDate
		RequestSpecBuilder reqSpecInvalidMinDate = new RequestSpecBuilder();
		reqSpecInvalidMinDate.addQueryParam("minDate", "2009-021-022");
		marketRequest.get("", reqSpecInvalidMinDate, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestDividendsAndSplits_WithoutMinDate400() {
		
		//without minDate
		marketRequest.get("", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	//-------------------------- 404 - Not Found Response validations--------------------
	
	@Test(groups={"notFound","full"})
	public void marketLatestDividendsAndSplits_InvalidRoute404() {
		
		//with Invalid client id
		RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
		reqSpecInvalidClient.addQueryParam("minDate", "2015-10-02");
		
		marketRequest.get("/abcInvalid/dividendsAndSplits", reqSpecInvalidClient, HttpStatus.SC_NOT_FOUND, null);
		
	}

	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void dividendsAndSplits_post_MthdNtAlwd405() {
		
		marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void dividendsAndSplits_put_MthdNtAlwd405() {
		
		marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void dividendsAndSplits_delete_MthdNtAlwd405() {
		
		marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketLatestDividendsAndSplits_SchemaValidation() {
		
		//Request specification with query parameters
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-12-26");
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		
		//Basic schema validations for Latest Events Filings end point
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, respSB);


	}
	
	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------

	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketLatestDividendsAndSplits_SchemaValidationDetailed() {
		
		//Request specification with query parameters
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-12-26");
		
		String latestDividendsAndSplitsSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/latest/dividends_splits_combined-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(latestDividendsAndSplitsSchemaLocation)));
		
		
		//Detailed schema validation
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, respSpecBuilder);


	}
	
	
	
	
	
	
	
	
	

}
