package tests.marketData.latest;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import api.migration.IMigrationRequest;


public class News {

	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	
	IMarketDataRequest marketRequest;
	IMigrationRequest MarketRqst_IncompleteRoute;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Latest/news");
		MarketRqst_IncompleteRoute = (IMigrationRequest) RequestFactory.Get(ApiRequestType.Migration, "Latest/new");
	}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "marketLatest"})
	public void marketLatestNews200() {
		
		//200 - OK test for latest News end point
		//with valid minDate
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-10-02");
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void marketLatestNews401() {
		marketRequest.validateUnauthorizedStatus();		
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void marketLatestNews403() {
		marketRequest.validateForbiddenStatus();
	}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void marketLatestNewsInvalidClient400() {
		
		//with Invalid client id
		RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
		reqSpecInvalidClient.addQueryParam("minDate", "2015-10-02");
		marketRequest.get(badClient, "", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestNewsInvalidMinDate400() {
		
		//with invalid minDate
		RequestSpecBuilder reqSpecInvalidMinDate = new RequestSpecBuilder();
		reqSpecInvalidMinDate.addQueryParam("minDate", "2009-021-022");
		marketRequest.get("", reqSpecInvalidMinDate, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestNewsWithoutMinDate400() {
		
		//without minDate
		marketRequest.get("", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	//-------------------------- 404 - Not Found Response validations--------------------
		//Added by Puneeth
	
			@Test(groups={"notFound","smoke","full"})
			public void marketNews_InvalidAPIroute404() {
				
				// For Invalid API route
				RequestSpecBuilder reqSpec = new RequestSpecBuilder();
				reqSpec.addQueryParam("minDate", "2015-10-02");
				marketRequest.get("/zzz", reqSpec, HttpStatus.SC_NOT_FOUND, null);
				
			}
			
			@Test(groups={"notFound","smoke","full"})
			public void marketNews_IncompleteAPIroute404() {
				//Incomplete API Route
				RequestSpecBuilder reqSB = new RequestSpecBuilder();
				reqSB.addQueryParam("minDate", "2015-10-02");
				MarketRqst_IncompleteRoute.get("", reqSB, HttpStatus.SC_NOT_FOUND, null);
				
			}
			
	
	
	
	
	
	//Added By Puneeth on 2016 Ap 19
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketLatestNews_post_MthdNtAlwd405() {
		
		marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketLatestNews_put_MthdNtAlwd405() {
		
		marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketLatestNews_delete_MthdNtAlwd405() {
		
		marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketLatestNewsSchemaValidation() {
		
		//Request specification with query parameters
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-10-02");
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		
		//Basic schema validations for Latest News Filings end point
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, respSB);

	}
	

	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketLatestNews_SchemaValidationDetailed() {
		
		//Request specification with query parameters
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("minDate", "2015-10-02");
		
		String latestNewsSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/latest/latest-news-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(latestNewsSchemaLocation)));
		
		
		//Basic schema validations for Latest News Filings end point
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, respSpecBuilder);

	}

	
}
