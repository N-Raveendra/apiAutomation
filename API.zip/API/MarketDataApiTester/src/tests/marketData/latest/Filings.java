package tests.marketData.latest;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class Filings {
	
	String badClient = "999999";	
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;
	
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Latest/secFilings");
	}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "marketLatest"})
	public void marketLatestSecWithCIKList200() {
		
		//200 - OK test for latest SEC end point
		//with CIK list (2 CIKs) and minDate
		RequestSpecBuilder reqSpecCIKList = new RequestSpecBuilder();
		reqSpecCIKList.addQueryParam("CIKs", "77476||36104").and()
					  .addQueryParam("minDate", "2016-01-02T23:13:48.500");
		marketRequest.get("", reqSpecCIKList, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "marketLatest"})
	public void marketLatestSecWithSingleCIK200() {
		
		//200 - OK test for latest SEC end point		
		//with Single CIK and minDate
		RequestSpecBuilder reqSpecSingleCIK = new RequestSpecBuilder();
		reqSpecSingleCIK.addQueryParam("CIKs", "1018724").and()
						.addQueryParam("minDate", "2016-01-02T23:13:48.500");
		marketRequest.get("", reqSpecSingleCIK, HttpStatus.SC_OK, null);

	}
	
	
	@Test(groups={"getOk","smoke","full", "marketLatest"})
	public void marketLatestSecWithMultipleCIK200() {
		
		//with multiple CIKs and minDate
		RequestSpecBuilder reqSpecMultipleCIK = new RequestSpecBuilder();
		reqSpecMultipleCIK.addQueryParam("CIKs", "77476||36104||1018724").and()
						  .addQueryParam("minDate", "2016-01-02T23:13:48.500");
		marketRequest.get("", reqSpecMultipleCIK, HttpStatus.SC_OK, null);

	}

	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void marketLatestSec401() {
		marketRequest.validateUnauthorizedStatus();
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void marketLatestSec403() {
		marketRequest.validateForbiddenStatus();
	}

	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void marketLatestSecInvalidClient400() {
		
		//with Invalid client id, valid CIKs and valid minDate
		RequestSpecBuilder reqSpecInvalidClient = new RequestSpecBuilder();
		reqSpecInvalidClient.addQueryParam("CIKs", "77476||36104").and()
					  .addQueryParam("minDate", "2016-01-02T23:13:48.500");
		marketRequest.get(badClient, "", reqSpecInvalidClient, HttpStatus.SC_BAD_REQUEST, null);
			
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestSecInvalidMinDate400() {
		
		//with invalid minDate and valid CIKs
		RequestSpecBuilder reqSpecInvalidMinDate = new RequestSpecBuilder();
		reqSpecInvalidMinDate.addQueryParam("CIKs", "77476||36104").and()
					  .addQueryParam("minDate", "2009-021-022");
		marketRequest.get("", reqSpecInvalidMinDate, HttpStatus.SC_BAD_REQUEST, null);
			
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestSeWithoutMinDatec400() {
		
		//without minDate and with CIKs
		RequestSpecBuilder reqSpecNoMinDate = new RequestSpecBuilder();
		reqSpecNoMinDate.addQueryParam("CIKs", "77476||36104");
		marketRequest.get("", reqSpecNoMinDate, HttpStatus.SC_BAD_REQUEST, null);
			
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestSecWithoutCIK400() {
		
		//without CIK and with minDate
		RequestSpecBuilder reqSpecNoCIK = new RequestSpecBuilder();
		reqSpecNoCIK.addQueryParam("minDate", "2009-01-02");
		marketRequest.get("", reqSpecNoCIK, HttpStatus.SC_BAD_REQUEST, null);
			
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketLatestSecWithoutQueryParm400() {
		
		//without CIK and minDate
		marketRequest.get("", null, HttpStatus.SC_BAD_REQUEST, null);
			
	}

	//-------------------------- 404 - Not Found Response validations--------------------
	
		@Test(groups={"notFound","full"})
		public void latestFilings_InvalidRoute404() {
			
			//with Invalid API Route 
			RequestSpecBuilder reqSpecInvalidRoute = new RequestSpecBuilder();
			reqSpecInvalidRoute.addQueryParam("minDate", "2015-10-02").and()
								.addQueryParam("minDate", "2009-01-02");
			
			marketRequest.get("/abc", reqSpecInvalidRoute, HttpStatus.SC_NOT_FOUND, null);
			
		}
		

	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
		@Test(groups={"mthdNtAlwd","full"})
		public void latestFilings_post_MthdNtAlwd405() {
			
			marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void latestFilings_put_MthdNtAlwd405() {
			
			marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
		
		@Test(groups={"mthdNtAlwd","full"})
		public void latestFilings_delete_MthdNtAlwd405() {
			
			marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
			
		}
		
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketLatestSecSchemaValidation() {
		
		RequestSpecBuilder reqSpecCIKList = new RequestSpecBuilder();
		reqSpecCIKList.addQueryParam("CIKs", "77476||36104").and()
					  .addQueryParam("minDate", "2016-01-02T23:13:48.500");
		
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		
		//Basic schema validations for Latest SEC Filings end point
		marketRequest.get("", reqSpecCIKList, HttpStatus.SC_OK, respSB);


	}

	
	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketLatestSec_SchemaValidationDetailed() {
		
		RequestSpecBuilder reqSpecCIKList = new RequestSpecBuilder();
		reqSpecCIKList.addQueryParam("CIKs", "77476||36104").and()
					  .addQueryParam("minDate", "2016-01-02T23:13:48.500");
		
		
		String latestFIlingsSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/latest/latest-secFilings-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(latestFIlingsSchemaLocation)));
		
		
		//Basic schema validations for Latest SEC Filings end point
		marketRequest.get("", reqSpecCIKList, HttpStatus.SC_OK, respSpecBuilder);


	}

}
