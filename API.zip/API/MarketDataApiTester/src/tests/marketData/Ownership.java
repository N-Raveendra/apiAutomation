package tests.marketData;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class Ownership {
	
	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;	
	IMarketDataRequest marketRequestFrBdnUnAuth;	
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Ownership");
		
		//For Unauthorized and Forbidden cases
		marketRequestFrBdnUnAuth = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Ownership/ShareholderBreakdown");
	}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketOwnershipShareholderBreakdown200() {
		
		marketRequest.get("/ShareholderBreakdown", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketOwnershipInvestorRotation200() {
		
		marketRequest.get("/InvestorRotation", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketOwnershipInvestorConcentration200() {
		
		marketRequest.get("/InvestorConcentration", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketOwnershipInvestorStyles200() {
		
		marketRequest.get("/InvestorStyles", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketOwnershipTopInstitutions200() {
		
		marketRequest.get("/TopInstitutions", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketOwnershipTopMutualFunds200() {
		
		marketRequest.get("/TopMutualFunds", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketOwnershipByRegion200() {
		
		marketRequest.get("/ByRegion", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketOwnershipByCountry200() {
		
		marketRequest.get("/ByCountry", null, HttpStatus.SC_OK, null);

	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void marketOwnership401() {
		marketRequestFrBdnUnAuth.validateUnauthorizedStatus();
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void marketOwnership403() {
		marketRequestFrBdnUnAuth.validateForbiddenStatus();
	}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void marketOwnershipShareholderBreakdown400() {
		
		marketRequest.get(badClient, "/ShareholderBreakdown", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketOwnershipInvestorRotation400() {
		
		marketRequest.get(badClient, "/InvestorRotation", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketOwnershipInvestorConcentration400() {
		
		marketRequest.get(badClient, "/InvestorConcentration", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketOwnershipInvestorStyles400() {
		
		marketRequest.get(badClient, "/InvestorStyles", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketOwnershipTopInstitutions400() {
		
		marketRequest.get(badClient, "/TopInstitutions", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketOwnershipTopMutualFunds400() {
		
		marketRequest.get(badClient, "/TopMutualFunds", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketOwnershipByRegion400() {
		
		marketRequest.get(badClient, "/ByRegion", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketOwnershipByCountry400() {
		
		marketRequest.get(badClient, "/ByCountry", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}

	//-------------------------- 404 - Not Found validations------------------------------
	//404 Validations are added by Madhu
	
	// Invalid API route for /Ownership
	@Test(groups={"notFound","full"})
	public void marketOwnership404() {
		
		marketRequest.get("", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Invalid API route for /ShareholderBreakdown
	@Test(groups={"notFound","full"})
	public void marketOwnership_ShareholderBreakdown_404() {
		
		marketRequest.get("/ShareholderBreakdown/zzz", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Invalid API route for /InvestorRotation
	@Test(groups={"notFound","full"})
	public void marketOwnership_InvestorRotation_404() {
		
		marketRequest.get("/InvestorRotation/zzz", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Invalid API route for /InvestorConcentration
	@Test(groups={"notFound","full"})
	public void marketOwnership_InvestorConcentration_404() {
		
		marketRequest.get("/InvestorConcentration/zzz", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	
	// Invalid API route for /InvestorStyles
	@Test(groups={"notFound","full"})
	public void marketOwnership_InvestorStyles_404() {
		
		marketRequest.get("/InvestorStyles/zzz", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Invalid API route for /TopInstitutions
	@Test(groups={"notFound","full"})
	public void marketOwnership_TopInstitutions_404() {
		
		marketRequest.get("/TopInstitutions/zzz", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Invalid API route for /TopMutualFunds
	@Test(groups={"notFound","full"})
	public void marketOwnership_TopMutualFunds_404() {
		
		marketRequest.get("/TopMutualFunds/zzz", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Invalid API route for /ByRegion
	@Test(groups={"notFound","full"})
	public void marketOwnership_ByRegion_404() {
		
		marketRequest.get("/ByRegion/zzz", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Invalid API route for /ByCountry
	@Test(groups={"notFound","full"})
	public void marketOwnership_ByCountry_404() {
		
		marketRequest.get("/ByCountry/zzz", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	
	
	//-------------------------- 405 - POST - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipShareholderBreakdown_post_MthdNtAlwd405() {
		
		marketRequest.post("/ShareholderBreakdown",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipInvestorRotation_post_MthdNtAlwd405() {
		
		marketRequest.post("/InvestorRotation",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipInvestorConcentration_post_MthdNtAlwd405() {
		
		marketRequest.post("/InvestorConcentration",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipInvestorStyles_post_MthdNtAlwd405() {
		
		marketRequest.post("/InvestorStyles",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipTopInstitutions_post_MthdNtAlwd405() {
		
		marketRequest.post("/TopInstitutions",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipTopMutualFunds_post_MthdNtAlwd405() {
		
		marketRequest.post("/TopMutualFunds",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipByRegion_post_MthdNtAlwd405() {
		
		marketRequest.post("/ByRegion",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipByCountry_post_MthdNtAlwd405() {
		
		marketRequest.post("/ByCountry",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	

	
	
	//-------------------------- 405 - PUT - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipShareholderBreakdown_put_MthdNtAlwd405() {
		
		marketRequest.put("/ShareholderBreakdown",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipInvestorRotation_put_MthdNtAlwd405() {
		
		marketRequest.put("/InvestorRotation",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipInvestorConcentration_put_MthdNtAlwd405() {
		
		marketRequest.put("/InvestorConcentration",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipInvestorStyles_put_MthdNtAlwd405() {
		
		marketRequest.put("/InvestorStyles",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipTopInstitutions_put_MthdNtAlwd405() {
		
		marketRequest.put("/TopInstitutions",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipTopMutualFunds_put_MthdNtAlwd405() {
		
		marketRequest.put("/TopMutualFunds",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipByRegion_put_MthdNtAlwd405() {
		
		marketRequest.put("/ByRegion",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipByCountry_put_MthdNtAlwd405() {
		
		marketRequest.put("/ByCountry",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	
	//-------------------------- 405 - DELETE - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipShareholderBreakdown_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/ShareholderBreakdown", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipInvestorRotation_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/InvestorRotation", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipInvestorConcentration_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/AnnualCashFlow", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipInvestorStyles_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/InvestorStyles", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipTopInstitutions_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/TopInstitutions", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipTopMutualFunds_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/TopMutualFunds", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipByRegion_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/ByRegion", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void ownershipByCountry_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/ByCountry", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	

	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketOwnershipShareholderBreakdownSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/ShareholderBreakdown", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketOwnershipInvestorRotationSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/InvestorRotation", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketOwnershipInvestorConcentrationSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/InvestorConcentration", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketOwnershipInvestorStylesSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/InvestorStyles", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketOwnershipTopInstitutionsSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/TopInstitutions", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketOwnershipTopMutualFundsSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/TopMutualFunds", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketOwnershipByRegionSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/ByRegion", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketOwnershipByCountrySchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/ByCountry", null, HttpStatus.SC_OK, respSB);

	}
	
	

	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketOwnershipShareholderBreakdown_SchemaValidationDetailed() {
		
		String ownrshpShareHolderBrkdwnSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/ownership/ownership_ShareHolderBreakdown.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(ownrshpShareHolderBrkdwnSchemaLocation)));
		
		marketRequest.get("/ShareholderBreakdown", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketOwnershipInvestorRotation_SchemaValidationDetailed() {
		
		String ownrshpInvestorRotationSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/ownership/ownership_InvestorRotation.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(ownrshpInvestorRotationSchemaLocation)));
		
		marketRequest.get("/InvestorRotation", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketOwnershipInvestorConcentration_SchemaValidationDetailed() {
		
		String ownrshpInvestorConcentrationSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/ownership/ownership_InvestorConcentration.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(ownrshpInvestorConcentrationSchemaLocation)));
		
		marketRequest.get("/InvestorConcentration", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketOwnershipInvestorStyles_SchemaValidationDetailed() {
		
		String ownrshpInvestorStylesSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/ownership/ownership_InvestorStyles.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(ownrshpInvestorStylesSchemaLocation)));
		
		marketRequest.get("/InvestorStyles", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketOwnershipTopInstitutions_SchemaValidationDetailed() {
		
		String ownrshpTopInsSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/ownership/ownership_TopInstitutions.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(ownrshpTopInsSchemaLocation)));
		
		marketRequest.get("/TopInstitutions", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketOwnershipTopMutualFunds_SchemaValidationDetailed() {
		
		String ownrshpTopMtlFndsSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/ownership/ownership_TopMutualFunds.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(ownrshpTopMtlFndsSchemaLocation)));
		
		marketRequest.get("/TopMutualFunds", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketOwnershipByRegion_SchemaValidationDetailed() {
		
		String ownrshpByRegionSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/ownership/ownership_ByRegion.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(ownrshpByRegionSchemaLocation)));
		
		marketRequest.get("/ByRegion", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketOwnershipByCountry_SchemaValidationDetailed() {
		
		String ownrshpByCountrySchemaLocation = Paths.get(marketRequest.buildSchemaPath("/ownership/ownership_ByCountry.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(ownrshpByCountrySchemaLocation)));
		
		marketRequest.get("/ByCountry", null, HttpStatus.SC_OK, respSpecBuilder);

	}

}
