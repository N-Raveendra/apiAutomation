package tests.marketData;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;


public class InsiderTransactions {

	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;	
	IMarketDataRequest marketRequest_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Insiders/Transactions");
		marketRequest_IncompleteSeg = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Insiders");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void insiderTransactions_GrpByFiler200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("group", "filer").and()
			   .addQueryParam("cik", "899051");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void insiderTransactions_GrpByDate200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("group", "date").and()
			   .addQueryParam("cik", "899051");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void insiderTransactions_NoGroup200() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("cik", "899051");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void insiderTransactions401() {
		marketRequest.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void insiderTransactions403() {
		marketRequest.validateForbiddenStatus();
	}
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void insiderTransactions_InvalidClientId400() {
		
		//For invalid client id
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("group", "filer").and()
			   .addQueryParam("cik", "899051");
		
		marketRequest.get(badClient, "", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void insiderTransactions_GrpByFilerAndInvalidCIK400() {
		
		//With GroupBy Filer and invalid CIK
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("group", "filer").and()
			   .addQueryParam("cik", "899051_invalid");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void insiderTransactions_GrpByDateAndInvalidCIK400() {
		
		//With GroupBy Date and Invalid CIK
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("group", "date").and()
			   .addQueryParam("cik", "899051_invalid");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void insiderTransactions_GrpByFilerAndWithoutCIK400() {
		
		//With GroupBy file and without CIK
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("group", "filer");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void insiderTransactions_GrpByDateAndWithoutCIK400() {
		
		//With GroupBy Date and without CIK
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("group", "date");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void insiderTransactions_InvalidGroupBy400() {
		
		//With CIK and Invalid GroupBy
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();		
		reqSpec.addQueryParam("group", "abcXYZ_invalid").and()
			   .addQueryParam("cik", "899051");
		
		marketRequest.get("", reqSpec, HttpStatus.SC_BAD_REQUEST, null);
		 
	}
	
	
	@Test(groups={"badRequests","full"})
	public void insiderTransactions_WithoutQueryParms400() {
		
		marketRequest.get("", null, HttpStatus.SC_BAD_REQUEST, null);
		 
	}

	//-------------------------- 404 - Not Found validations-----------------------
	// 404 validations are added by Madhu
	
	// Invalid API Route
	@Test(groups={"notFound","full"})
	public void insiderTransactions_Invalid_API_Route_404() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("group", "filer").and()
			   .addQueryParam("cik", "899051");
		
		marketRequest.get("/zzz", reqSpec, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Incomplete API Segment
	@Test(groups={"notFound","full"})
	public void insiderTransactions_Incomplete_API_Route_404() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("group", "filer").and()
			   .addQueryParam("cik", "899051");
		
		marketRequest_IncompleteSeg.get("", reqSpec, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
		
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void insiderTransactions_post_MthdNtAlwd405() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("group", "filer").and()
			   .addQueryParam("cik", "899051");
		
		marketRequest.post("",inputJSON405, reqSpec, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void insiderTransactions_put_MthdNtAlwd405() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("group", "filer").and()
			   .addQueryParam("cik", "899051");
		
		marketRequest.put("",inputJSON405, reqSpec, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void insiderTransactions_delete_MthdNtAlwd405() {
		
		RequestSpecBuilder reqSpec = new RequestSpecBuilder();
		reqSpec.addQueryParam("group", "filer").and()
			   .addQueryParam("cik", "899051");
		
		marketRequest.delete("", reqSpec, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void insiderTransactionsGrpByFilerSchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("group", "filer").and()
			 .addQueryParam("cik", "899051");

		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void insiderTransactionsGrpByDateSchemaValidation() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("group", "date").and()
			 .addQueryParam("cik", "899051");

		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSB);
	}
	
	

	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void insiderTransactionsGrpByFiler_SchemaValidationDetailed() {
		
		//Building request specifications with the query parameters
		RequestSpecBuilder reqSB = new RequestSpecBuilder();
		reqSB.addQueryParam("group", "filer").and()
			 .addQueryParam("cik", "899051");

		String insiderTransactionSchemaLocation = Paths.get(marketRequest.buildSchemaPath("insiderTransactions-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(insiderTransactionSchemaLocation)));
		
		marketRequest.get("", reqSB, HttpStatus.SC_OK, respSpecBuilder);
	}

	
	
}
