package tests.marketData;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class Estimates{
	
	String badClient = "999999";	
	String inputJSON405 = "input for JSON - 405 status code";

	//MarketDataRequest<MarketBase> quotes = new MarketDataRequest<MarketBase>(new MarketBase(TestInitializer.getInstance().getApiTestSession(), "quotes"));
	
	IMarketDataRequest marketRequest;	
	IMarketDataRequest marketRequest_InvalidRoute; 
	
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Estimates");
		marketRequest_InvalidRoute = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "EstimateInvalid");
	}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketEstimatesCombined200() {	

		marketRequest.get( "", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketEstimatesStockInfo200() {	
			
		marketRequest.get( "/StockInfo", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketEstimatesGrowthAndPERatios200() {	
			
		marketRequest.get( "/GrowthAndPERatios", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketEstimatesReference200() {	
		
		marketRequest.get( "/Reference", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketEstimatesForecasts200() {	
			
		marketRequest.get( "/Forecasts", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketEstimatesActuals200() {	
		
		marketRequest.get( "/Actuals", null, HttpStatus.SC_OK, null);
	}
	
	//-------------------------- 401 - Unauthorized Response validations---------------------
	
	@Test(groups={"unAuthorized","full"})
	public void marketEstimates401() {
		marketRequest.validateUnauthorizedStatus();		
	}
	
	//-------------------------- 403 - Forbidden Response validations------------------------
	
	@Test(groups={"forbidden","full"})
	public void marketEstimates403() {
		marketRequest.validateForbiddenStatus();		
	}
		
	//-------------------------- 400 - Bad Request Response validations----------------------
	
	@Test(groups={"badRequests","full"})
	public void marketEstimatesCombined400() {
		
		marketRequest.get(badClient, "", null, HttpStatus.SC_BAD_REQUEST, null);	
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketEstimatesStockInfo400() {
		
		marketRequest.get(badClient, "/StockInfo", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketEstimatesGrowthAndPERatios400() {
		
		marketRequest.get(badClient, "/GrowthAndPERatios", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketEstimatesReference400() {
		
		marketRequest.get(badClient, "/Reference", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketEstimatesForecasts400() {
		
		marketRequest.get(badClient, "/Forecasts", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketEstimatesActuals400() {
		
		marketRequest.get(badClient, "/Actuals", null, HttpStatus.SC_BAD_REQUEST, null);

	}
	
	//------------------------------------404 Not Found - Validations--------------------------------	
	// 404 validations are added by Madhu
	
	// Invalid API Route for /Estimates (Combined)
	@Test(groups={"notFound","full"})
	public void marketEstimates_404() {
		
		marketRequest_InvalidRoute.get("", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	
	// Invalid API Route for /StockInfo
	@Test(groups={"notFound","full"})
	public void marketEstimates_StockInfo_404() {
		
		marketRequest_InvalidRoute.get("/StockInfo", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	
	// Invalid API Route for /GrowthAndPERatios
	@Test(groups={"notFound","full"})
	public void marketEstimates_GrowthAndPERatios_404() {
		
		marketRequest_InvalidRoute.get("/GrowthAndPERatios", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	
	
	// Invalid API Route for /reference
	@Test(groups={"notFound","full"})
	public void marketEstimates_reference_404() {
		
		marketRequest_InvalidRoute.get("/reference", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	
	// Invalid API Route for /Forecasts
	@Test(groups={"notFound","full"})
	public void marketEstimates_Forecasts_404() {
		
		marketRequest_InvalidRoute.get("/Forecasts", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	
	// Invalid API Route for /Actuals
	@Test(groups={"notFound","full"})
	public void marketEstimates_Actuals_404() {
		
		marketRequest_InvalidRoute.get("/Actuals", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	
		
	//Added By Puneeth on 2016 Ap 19 | Added by Puneeth(20160430)
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	//=========POST================
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesCombined_post_MthdNtAlwd405() {
		
		marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesStockInfo_post_MthdNtAlwd405() {	
		
		marketRequest.post( "/StockInfo", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesGrowthAndPERatios_post_MthdNtAlwd405() {	
			
		marketRequest.post( "/GrowthAndPERatios", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesReference_post_MthdNtAlwd405() {	
		
		marketRequest.post( "/Reference", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesForecasts_post_MthdNtAlwd405() {	
			
		marketRequest.post( "/Forecasts", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesActuals_post_MthdNtAlwd405() {	
		
		marketRequest.post( "/Actuals", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
	}
	
	//=========PUT================
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesCombined_put_MthdNtAlwd405() {
		
		marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesStockInfo_put_MthdNtAlwd405() {	
		
		marketRequest.put( "/StockInfo", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesGrowthAndPERatios_put_MthdNtAlwd405() {	
			
		marketRequest.put( "/GrowthAndPERatios", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesReference_put_MthdNtAlwd405() {	
		
		marketRequest.put( "/Reference", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesForecasts_put_MthdNtAlwd405() {	
			
		marketRequest.put( "/Forecasts", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesActuals_put_MthdNtAlwd405() {	
		
		marketRequest.put( "/Actuals", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
	}
	
	//=========DELETE================
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesCombined_delete_MthdNtAlwd405() {
		
		marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesStockInfo_delete_MthdNtAlwd405() {	
		
		marketRequest.delete( "/StockInfo", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesGrowthAndPERatios_delete_MthdNtAlwd405() {	
			
		marketRequest.delete( "/GrowthAndPERatios", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesReference_delete_MthdNtAlwd405() {	
		
		marketRequest.delete( "/Reference", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesForecasts_delete_MthdNtAlwd405() {	
			
		marketRequest.delete( "/Forecasts", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketEstimatesActuals_delete_MthdNtAlwd405() {	
		
		marketRequest.delete( "/Actuals", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
	}

	
	//-------------------------- JSON SCHEMA Validations-----------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketEstimatesCombinedSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get( "", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketEstimatesStockInfoSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
	
		marketRequest.get("/StockInfo", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketEstimatesGrowthAndPERatiosSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/GrowthAndPERatios", null, HttpStatus.SC_OK, respSB);
		
		}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketEstimatesReferenceSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/Reference", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketEstimatesForecastsSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/Forecasts", null, HttpStatus.SC_OK, respSB);

	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketEstimatesActualsSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
	
		marketRequest.get("/Actuals", null, HttpStatus.SC_OK, respSB);
	
	}
	
	
	
	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketEstimatesStockInfo_SchemaValidationDetailed() {
		
		String estimatesStockInfoSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/estimates/estimates_StockInfo-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(estimatesStockInfoSchemaLocation)));
		
		marketRequest.get("/StockInfo", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketEstimatesGrowthAndPERatios_SchemaValidationDetailed() {
		
		String estimatesGrwthAndPERtioSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/estimates/estimates_GrwthPERatios-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(estimatesGrwthAndPERtioSchemaLocation)));
		
		marketRequest.get("/GrowthAndPERatios", null, HttpStatus.SC_OK, respSpecBuilder);
		
		}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketEstimatesReference_SchemaValidationDetailed() {
		
		String estimatesReferenceSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/estimates/estimates_Reference-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(estimatesReferenceSchemaLocation)));
		
		marketRequest.get("/Reference", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketEstimatesForecasts_SchemaValidationDetailed() {
		
		String estimatesForecastsSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/estimates/estimates_Forecasts-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(estimatesForecastsSchemaLocation)));
		
		marketRequest.get("/Forecasts", null, HttpStatus.SC_OK, respSpecBuilder);

	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketEstimatesActuals_SchemaValidationDetailed() {
		
		String estimatesActualsSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/estimates/estimates_Actuals-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(estimatesActualsSchemaLocation)));
		
		marketRequest.get("/Actuals", null, HttpStatus.SC_OK, respSpecBuilder);
	
	}

	
}