package tests.marketData;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class Quotes{
	
	String badClient = "999999";	

	String inputJSON405 = "input for JSON - 405 status code";
	
	
	//MarketDataRequest<MarketBase> quotes = new MarketDataRequest<MarketBase>(new MarketBase(TestInitializer.getInstance().getApiTestSession(), "quotes"));
	
	IMarketDataRequest marketRequest;	
	IMarketDataRequest marketRequest_IncompleteSeg;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "quotes");
		marketRequest_IncompleteSeg = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void QuotesOkTest() {
		//String target = String.format("%s/%s", testClientId, quotes.basePath);
		marketRequest.get( "", null, HttpStatus.SC_OK, null);				
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void QuotesUnauthorizedTest() {
		marketRequest.validateUnauthorizedStatus();		
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void QuotesForbidenTest() {
		marketRequest.validateForbiddenStatus();		
	}
		
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void QuotesBadTest() {
		marketRequest.get(badClient, "", null, HttpStatus.SC_BAD_REQUEST, null);				
	}
	
	
	//-------------------------- 404 - Not Found Response validations--------------------
	
	//Invalid API Route
	@Test(groups={"notFound","smoke","full"})
	public void Quotes_InvalidAPIroute404() {
		
		// For Invalid API route
		RequestSpecBuilder reqSpecAssetsList = new RequestSpecBuilder();
		marketRequest.get("/zzz", reqSpecAssetsList, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	//Incomplete API segment
	@Test(groups={"notFound","smoke","full"})
	public void Quotes_IncompleteSeg404() {
		
		// For Incomplete API segment
		RequestSpecBuilder reqSpecAssetsList = new RequestSpecBuilder();
		marketRequest_IncompleteSeg.get("", reqSpecAssetsList, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void quotes_post_MthdNtAlwd405() {
		
		marketRequest.post("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void quotes_put_MthdNtAlwd405() {
		
		marketRequest.put("",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void quotes_delete_MthdNtAlwd405() {
		
		marketRequest.delete("", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void QuotesSchemaValidation() {
		
		String quotesSchemaLocation = Paths.get(marketRequest.buildSchemaPath("quotes-schema.json")).toString();		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())))
				.expectBody(matchesJsonSchema(new File(quotesSchemaLocation)));
		
		marketRequest.get("", null, HttpStatus.SC_OK, respSpecBuilder);
		
		
		
	}
	
	
	//-------------------------- Detailed JSON SCHEMA Validations--------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void Quotes_SchemaValidationDetailed() {
		
		String quotesSchemaLocation = Paths.get(marketRequest.buildSchemaPath("quotes-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(quotesSchemaLocation)));
		
		marketRequest.get("", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}

}