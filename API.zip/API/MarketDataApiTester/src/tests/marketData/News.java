package tests.marketData;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;


public class News {
	
	String badClient = "999999";	
	
	String validNewsId = "2104492";
	String invalidNewsId = "09090909";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;
	IMarketDataRequest marketRequestFrBdnUnAuth;
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "News");
		
		//For Unauthorized and Forbidden cases
		marketRequestFrBdnUnAuth = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "News/"+validNewsId+"/Body");
	}
	
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketNews200() {
		
		marketRequest.get("/"+validNewsId+"/Body", null, HttpStatus.SC_OK, null);
		
	}
	
	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void marketNews401() {
		marketRequestFrBdnUnAuth.validateUnauthorizedStatus();	
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void marketNews403() {
		marketRequestFrBdnUnAuth.validateForbiddenStatus();
	}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void marketNews_InvalidClientId400() {
		
	
		marketRequest.get(badClient, "/"+validNewsId+"/Body", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}

	
	//-------------------------- 404 - Not Found Response validations--------------------
	
	// Invalid News ID
	@Test(groups={"notFound","full"})
	public void marketNews_InvalidNewsId404() {
				
		marketRequest.get("/"+invalidNewsId+"/Body", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Invalid API Route
	@Test(groups={"notFound","full"})
	public void marketNews_Invalid_API_Route_404() {
				
		marketRequest.get("/"+validNewsId+"/zzz/Body", null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	// Incomplete API segment
	@Test(groups={"notFound","full"})
	public void marketNews_IncompleteSeg_404() {
					
		marketRequest.get("/"+validNewsId, null, HttpStatus.SC_NOT_FOUND, null);
		
	}
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketNews_post_MthdNtAlwd405() {
		
		marketRequest.post("/"+validNewsId+"/Body", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketNews_put_MthdNtAlwd405() {
		
		marketRequest.put("/"+validNewsId+"/Body", inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void marketNews_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/"+validNewsId+"/Body", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);
		
	}

}
