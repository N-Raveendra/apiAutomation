package tests.marketData;

import java.io.File;
import java.nio.file.Paths;

import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.ValidatableResponse;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;

public class Fundamentals {

	String badClient = "999999";
	
	String inputJSON405 = "input for JSON - 405 status code";
	
	IMarketDataRequest marketRequest;	
	IMarketDataRequest marketRequestFrBdnUnAuth;	
	
	
	@BeforeClass(alwaysRun=true)
	public void Init() {
		marketRequest = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Fundamentals");
		
		//For Unauthorized and Forbidden cases
		marketRequestFrBdnUnAuth = (IMarketDataRequest) RequestFactory.Get(ApiRequestType.MarketData, "Fundamentals/Annualbalancesheet");
	}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketFundamentalsAnnualbalancesheet200() {
		
		marketRequest.get("/Annualbalancesheet", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketFundamentalsQuarterlyBalanceSheet200() {
		
		marketRequest.get("/QuarterlyBalanceSheet", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketFundamentalsAnnualCashFlow200() {
		
		marketRequest.get("/AnnualCashFlow", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketFundamentalsQuarterlyCashFlow200() {
		
		marketRequest.get("/QuarterlyCashFlow", null, HttpStatus.SC_OK, null);
			
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketFundamentalsAnnualIncomeStatement200() {
		
		marketRequest.get("/AnnualIncomeStatement", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketFundamentalsQuarterlyIncomeStatement200() {
		
		marketRequest.get("/QuarterlyIncomeStatement", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketFundamentalsRatios200() {
		
		marketRequest.get("/Ratios", null, HttpStatus.SC_OK, null);
			
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketFundamentalsSnapshot200() {
		
		marketRequest.get("/Snapshot", null, HttpStatus.SC_OK, null);
		
	}
	
	
	@Test(groups={"getOk","smoke","full", "market"})
	public void marketFundamentalsTradingStatistics200() {
		
		marketRequest.get("/TradingStatistics", null, HttpStatus.SC_OK, null);
	
	}

	
	//-------------------------- 401 - Unauthorized Response validations-------------------
	
	@Test(groups={"unAuthorized","full"})
	public void marketFundamentals401() {
		marketRequestFrBdnUnAuth.validateUnauthorizedStatus();;		
	}
	
	
	//-------------------------- 403 - Forbidden Response validations----------------------
	
	@Test(groups={"forbidden","full"})
	public void marketFundamentals403() {
		marketRequestFrBdnUnAuth.validateForbiddenStatus();;
	}
	
	
	//-------------------------- 400 - Bad Request Response validations--------------------
	
	@Test(groups={"badRequests","full"})
	public void marketFundamentalsAnnualbalancesheet400() {
		
		marketRequest.get(badClient, "/Annualbalancesheet", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketFundamentalsQuarterlyBalanceSheet400() {
		
		marketRequest.get(badClient, "/QuarterlyBalanceSheet", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketFundamentalsAnnualCashFlow400() {
		
		marketRequest.get(badClient, "/AnnualCashFlow", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketFundamentalsQuarterlyCashFlow400() {
		
		marketRequest.get(badClient, "/QuarterlyCashFlow", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketFundamentalsAnnualIncomeStatement400() {
		
		marketRequest.get(badClient, "/AnnualIncomeStatement", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketFundamentalsQuarterlyIncomeStatement400() {
		
		marketRequest.get(badClient, "/QuarterlyIncomeStatement", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketFundamentalsRatios400() {
		
		marketRequest.get(badClient, "/Ratios", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketFundamentalsSnapshot400() {
		
		marketRequest.get(badClient, "/Snapshot", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	
	@Test(groups={"badRequests","full"})
	public void marketFundamentalsTradingStatistics400() {
		
		marketRequest.get(badClient, "/TradingStatistics", null, HttpStatus.SC_BAD_REQUEST, null);
		
	}
	
	//------------------------------------ 404 - Not Found Validations--------------------------------
	// 404 validations are added by Madhu
	
	// Invalid API Route for /Fundamentals
	@Test(groups={"notFound","full"})
	public void marketFundamentals_404() {
		
		marketRequest.get("", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
		
	// Invalid API Route for /AnnualBalanceSheet
	@Test(groups={"notFound","full"})
	public void marketFundamentals_AnnualBalanceSheet_404() {
		
		marketRequest.get("/AnnualBalanceSheet/zzz", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}

	// Invalid API Route for /QuarterlyBalanceSheet
	@Test(groups={"notFound","full"})
	public void marketFundamentals_QuarterlyBalanceSheet_404() {
		
		marketRequest.get("/QuarterlyBalanceSheet/zzz", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	
	// Invalid API Route for /AnnualCashFlow
	@Test(groups={"notFound","full"})
	public void marketFundamentals_AnnualCashFlow_404() {
		
		marketRequest.get("/AnnualCashFlow/zzz", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	// Invalid API Route for /QuarterlyCashFlow
	@Test(groups={"notFound","full"})
	public void marketFundamentals_QuarterlyCashFlow_404() {
		
		marketRequest.get("/QuarterlyCashFlow/zzz", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	// Invalid API Route for /AnnualIncomeStatement
	@Test(groups={"notFound","full"})
	public void marketFundamentals_AnnualIncomeStatement_404() {
		
		marketRequest.get("/AnnualIncomeStatement/zzz", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	// Invalid API Route for /QuarterlyIncomeStatement
	@Test(groups={"notFound","full"})
	public void marketFundamentals_QuarterlyIncomeStatement_404() {
		
		marketRequest.get("/QuarterlyIncomeStatement/zzz", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}

	// Invalid API Route for /Ratios
	@Test(groups={"notFound","full"})
	public void marketFundamentals_Ratios_404() {
		
		marketRequest.get("/Ratios/zzz", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	
	// Invalid API Route for /Snapshot
	@Test(groups={"notFound","full"})
	public void marketFundamentals_Snapshot_404() {
		
		marketRequest.get("/Snapshot/zzz", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
	
	// Invalid API Route for /TradingStatistics
	@Test(groups={"notFound","full"})
	public void marketFundamentals_TradingStatistics_404() {
		
		marketRequest.get("/TradingStatistics/zzz", null, HttpStatus.SC_NOT_FOUND, null);	
		
	}
		
		
	//-------------------------- 405 - POST - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsAnnualbalancesheet_post_MthdNtAlwd405() {
		
		marketRequest.post("/Annualbalancesheet",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsQuarterlyBalanceSheet_post_MthdNtAlwd405() {
		
		marketRequest.post("/QuarterlyBalanceSheet",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsAnnualCashFlow_post_MthdNtAlwd405() {
		
		marketRequest.post("/AnnualCashFlow",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsQuarterlyCashFlow_post_MthdNtAlwd405() {
		
		marketRequest.post("/QuarterlyCashFlow",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsAnnualIncomeStatement_post_MthdNtAlwd405() {
		
		marketRequest.post("/AnnualIncomeStatement",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsQuarterlyIncomeStatement_post_MthdNtAlwd405() {
		
		marketRequest.post("/QuarterlyIncomeStatement",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsRatios_post_MthdNtAlwd405() {
		
		marketRequest.post("/Ratios",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsSnapshot_post_MthdNtAlwd405() {
		
		marketRequest.post("/Snapshot",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsTradingStatistics_post_MthdNtAlwd405() {
		
		marketRequest.post("/TradingStatistics",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}

	
	
	
	//-------------------------- 405 - PUT - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsAnnualbalancesheet_put_MthdNtAlwd405() {
		
		marketRequest.put("/Annualbalancesheet",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsQuarterlyBalanceSheet_put_MthdNtAlwd405() {
		
		marketRequest.put("/QuarterlyBalanceSheet",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsAnnualCashFlow_put_MthdNtAlwd405() {
		
		marketRequest.put("/AnnualCashFlow",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsQuarterlyCashFlow_put_MthdNtAlwd405() {
		
		marketRequest.put("/QuarterlyCashFlow",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsAnnualIncomeStatement_put_MthdNtAlwd405() {
		
		marketRequest.put("/AnnualIncomeStatement",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsQuarterlyIncomeStatement_put_MthdNtAlwd405() {
		
		marketRequest.put("/QuarterlyIncomeStatement",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsRatios_put_MthdNtAlwd405() {
		
		marketRequest.put("/Ratios",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsSnapshot_put_MthdNtAlwd405() {
		
		marketRequest.put("/Snapshot",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsTradingStatistics_put_MthdNtAlwd405() {
		
		marketRequest.put("/TradingStatistics",inputJSON405, null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
		
	
	//-------------------------- 405 - DELETE - Method Not Allowed validations-----------------------
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsAnnualbalancesheet_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/Annualbalancesheet", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsQuarterlyBalanceSheet_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/QuarterlyBalanceSheet", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsAnnualCashFlow_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/AnnualCashFlow", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsQuarterlyCashFlow_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/QuarterlyCashFlow", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsAnnualIncomeStatement_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/AnnualIncomeStatement", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsQuarterlyIncomeStatement_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/QuarterlyIncomeStatement", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsRatios_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/Ratios", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsSnapshot_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/Snapshot", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	
	@Test(groups={"mthdNtAlwd","full"})
	public void fundamentalsTradingStatistics_delete_MthdNtAlwd405() {
		
		marketRequest.delete("/TradingStatistics", null, HttpStatus.SC_METHOD_NOT_ALLOWED, null);	
		
	}
	
	

	
	//-------------------------- JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketFundamentalsAnnualbalancesheetSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/Annualbalancesheet", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketFundamentalsQuarterlyBalanceSheetSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/QuarterlyBalanceSheet", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketFundamentalsAnnualCashFlowSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/AnnualCashFlow", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketFundamentalsQuarterlyCashFlowSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/QuarterlyCashFlow", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketFundamentalsAnnualIncomeStatementSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/AnnualIncomeStatement", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketFundamentalsQuarterlyIncomeStatementSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/QuarterlyIncomeStatement", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketFundamentalsRatiosSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/Ratios", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketFundamentalsSnapshotSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/Snapshot", null, HttpStatus.SC_OK, respSB);
		
	}
	
	
	@Test(groups={"schemaValidation","smoke","full"})
	public void marketFundamentalsTradingStatisticsSchemaValidation() {
		
		//Response specification with response body validations
		ResponseSpecBuilder  respSB = new ResponseSpecBuilder();
		respSB.expectBody(matchesJsonSchema(new File(marketRequest.getBasicLF_SchemaPath())));
		
		marketRequest.get("/TradingStatistics", null, HttpStatus.SC_OK, respSB);

	}

	
	
	//-------------------------- Detailed JSON SCHEMA Validations-----------------------------------
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketFundamentalsAnnualbalancesheet_SchemaValidationDetailed() {
		
		String fundiesAnnualSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/fundamentals/fundamentals-AnnualSegments-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(fundiesAnnualSchemaLocation)));
		
		marketRequest.get("/Annualbalancesheet", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketFundamentalsQuarterlyBalanceSheet_SchemaValidationDetailed() {
		
		String fundiesQuarterlySchemaLocation = Paths.get(marketRequest.buildSchemaPath("/fundamentals/fundamentals-QuarterlySegments-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(fundiesQuarterlySchemaLocation)));
		
		marketRequest.get("/QuarterlyBalanceSheet", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketFundamentalsAnnualCashFlow_SchemaValidationDetailed() {
		
		String fundiesAnnualSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/fundamentals/fundamentals-AnnualSegments-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(fundiesAnnualSchemaLocation)));
		
		marketRequest.get("/AnnualCashFlow", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketFundamentalsQuarterlyCashFlow_SchemaValidationDetailed() {
		
		String fundiesQuarterlySchemaLocation = Paths.get(marketRequest.buildSchemaPath("/fundamentals/fundamentals-QuarterlySegments-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(fundiesQuarterlySchemaLocation)));
		
		marketRequest.get("/QuarterlyCashFlow", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketFundamentalsAnnualIncomeStatement_SchemaValidationDetailed() {
		
		String fundiesAnnualSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/fundamentals/fundamentals-AnnualSegments-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(fundiesAnnualSchemaLocation)));
		
		marketRequest.get("/AnnualIncomeStatement", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketFundamentalsQuarterlyIncomeStatement_SchemaValidationDetailed() {
		
		String fundiesQuarterlySchemaLocation = Paths.get(marketRequest.buildSchemaPath("/fundamentals/fundamentals-QuarterlySegments-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(fundiesQuarterlySchemaLocation)));
		
		marketRequest.get("/QuarterlyIncomeStatement", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketFundamentalsRatios_SchemaValidationDetailed() {
		
		String fundiesRatiosSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/fundamentals/fundamentals-Ratios-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(fundiesRatiosSchemaLocation)));
		
		marketRequest.get("/Ratios", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketFundamentalsSnapshot_SchemaValidationDetailed() {
		
		String fundiesSnapshotSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/fundamentals/fundamentals-Snapshot-schema.json")).toString();		
		
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(fundiesSnapshotSchemaLocation)));
		
		marketRequest.get("/Snapshot", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
	@Test(groups={"schemaValidationDetailed","full"})
	public void marketFundamentalsTradingStatistics_SchemaValidationDetailed() {
		
		String fundiesTradingStatisticsSchemaLocation = Paths.get(marketRequest.buildSchemaPath("/fundamentals/fundamentals-TradingStatistics-schema.json")).toString();		
		                     
		ResponseSpecBuilder  respSpecBuilder = new ResponseSpecBuilder();
		respSpecBuilder.expectBody(matchesJsonSchema(new File(fundiesTradingStatisticsSchemaLocation)));
		
		marketRequest.get("/TradingStatistics", null, HttpStatus.SC_OK, respSpecBuilder);
		
	}
	
	
}
