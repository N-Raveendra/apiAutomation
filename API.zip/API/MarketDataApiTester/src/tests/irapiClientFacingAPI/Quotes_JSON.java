package tests.irapiClientFacingAPI;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import org.Data;
import java.io.File;
import java.util.Properties;



public class Quotes_JSON extends Data {
	
	String siteURL = "";
	String irAPIToken = "";
	String inputJsonLocation  = "./schemas/irData/";	
	String fileName = "irdata_quotes_json_schema.json";
	String schemaPath = inputJsonLocation + fileName;
	String proxyAddress = "";
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		Properties globalValues = ReadGlobalFileData();
		siteURL = globalValues.getProperty("clientapigcsDataURL");
		irAPIToken = globalValues.getProperty("irAPIToken");
		proxyAddress=globalValues.getProperty("proxyAddress");
	
		System.out.println("Quotes URL :"+siteURL);
		}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuotesJSON_200(){
	 	 
			Response response = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
//						    .log().all().
						when()			
							.get(siteURL + "/"+irAPIToken+"/quotes").				
						then().	
						extract()
							.response();
			
						response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}
	
	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuotesJSON_404(){
	 	 
			Response response = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL + "/"+irAPIToken+"/quotes_invalid").				
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
		
	//-------------------------- Unsupported media type-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuotesJSON_InvalidAPI_401(){
	 	 
			Response response = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL + "/"+irAPIToken+"ssdfdsf/quotes").							
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_UNAUTHORIZED);			
		}
	
	
	//-------------------------- Basic Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuotesJSON_BasicSchemaValidations(){
		String fileName1 = "lfBasic-schema_IRAPIData.json";
		String schemaPath = inputJsonLocation + fileName1;
		
				ValidatableResponse valResp = 
				given()
				    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
				when()			
					.get(siteURL + "/"+irAPIToken+"/quotes").	
				then().
					assertThat().body(matchesJsonSchema(new File(schemaPath)));
			}
	
	
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuotesJSON_SchemaValidations(){
	 	 
		
						ValidatableResponse valResp = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL + "/"+irAPIToken+"/quotes").				
						then().
						assertThat().body(matchesJsonSchema(new File(schemaPath)));	
//							body(matchesJsonSchemaInClasspath("JSONIRAPIData_Quotes.json"));

		}

}	
	
	
	
	
	
	
	
