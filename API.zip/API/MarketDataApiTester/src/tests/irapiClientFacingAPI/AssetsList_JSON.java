package tests.irapiClientFacingAPI;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import org.Data;
import java.io.File;
import java.util.Properties;

public class AssetsList_JSON extends Data{
	
	String clientApiGCSDataURL = "";
	String siteURL = "";
	String irAPIToken = "";
	String proxyAddress = "";
	String invalidAPI_URL="";
	String invalidAPIToken_URL="";
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		
		Properties globalValues = ReadGlobalFileData();
		clientApiGCSDataURL = globalValues.getProperty("clientapigcsDataURL");
		irAPIToken = globalValues.getProperty("irAPIToken");
		proxyAddress=globalValues.getProperty("proxyAddress");
		siteURL=clientApiGCSDataURL + "/"+irAPIToken+"/assets";
		invalidAPI_URL=clientApiGCSDataURL + "/"+irAPIToken+"/assetsInvalid";
		invalidAPIToken_URL=clientApiGCSDataURL + "/"+irAPIToken+"ssdfdsf/assets";
		
		}
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetsListLookup_200(){
	 	 
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
//						    .log().all().
						when()			
							.get(siteURL).				
						then().	
						extract()
							.response();
			
						response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}
	
	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetsListLookup_404(){
	 	 
		
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPI_URL).				
						then().	
						extract()
							.response();
						response.prettyPeek();
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
		
	//-------------------------- Unsupported media type-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetsListLookup_InvalidAPI_401(){
		
	
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPIToken_URL).							
						then().	
						extract()
							.response();
						response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_UNAUTHORIZED);			
		}
	
	
	//-------------------------- Basic Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetsListLookup_BasicSchemaValidations(){
	 	 
				ValidatableResponse valResp = 
				given()
				.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
				when()			
					.get(siteURL).	
				then().
					body(matchesJsonSchemaInClasspath("lfBasic-schema_IRAPIData.json"));
			}
	
	
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetsListLookup_SchemaValidations(){
	 	 
		
						ValidatableResponse valResp = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL).				
						then().
							body(matchesJsonSchemaInClasspath("JSONIRAPIData_AssestList.json"));

		}

}	
	
	
	
	
	
	
	
