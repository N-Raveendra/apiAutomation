package tests.irapiClientFacingAPI;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import org.Data;
import java.io.File;
import java.util.Properties;

public class QuoteDateLookup_JSON extends Data{
	
	String clientApiGCSDataURL = "";
	String siteURL = "";
	String irAPIToken = "";
	String tickerID = "";
	String quotesLookupDate = "";
	String invalidAPIQuotes_URL="";
	String invalidAPIToken_URL="";
	String proxyAddress = "";
	
	String inputJsonLocation  = "./schemas/irData/";	
	String fileName = "JSONIRAPIData_QuoteDateLookUp.json";
	String schemaPath = inputJsonLocation + fileName;
	
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		
		Properties globalValues = ReadGlobalFileData();
		clientApiGCSDataURL = globalValues.getProperty("clientapigcsDataURL");
		irAPIToken = globalValues.getProperty("irAPIToken");
		tickerID = globalValues.getProperty("tickerID");
		quotesLookupDate = globalValues.getProperty("quotesLookupDate");
		proxyAddress=globalValues.getProperty("proxyAddress");
//		https://clientapi-qa.gcs-web.com/data/d3fc04e8-b62a-4759-9dac-ba5369cd7f11/quotes/lookup?date=2017-04-12&symbol=BMCH
		
		siteURL=clientApiGCSDataURL + "/"+irAPIToken+"/quotes/lookup?date="+quotesLookupDate+"&symbol="+tickerID;
		invalidAPIQuotes_URL=clientApiGCSDataURL + "/"+irAPIToken+"/quoteInvalid/lookup?date="+quotesLookupDate+"&symbol="+tickerID;
		invalidAPIToken_URL=clientApiGCSDataURL + "/"+irAPIToken+"ssdfdsf/quotes/lookup?date="+quotesLookupDate+"&symbol="+tickerID;
		
		System.out.println("Quote Date URL : "+siteURL);
		
		}
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteDateLookup_200(){
	 	 
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
//						    .log().all().
						when()			
							.get(siteURL).				
						then().	
						extract()
							.response();
			
						response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}
	
	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteDateLookup_404(){
	 	 
		
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPIQuotes_URL).				
						then().	
						extract()
							.response();
//						response.prettyPeek();
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
		
	//-------------------------- Unsupported media type-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteDateLookup_InvalidAPI_401(){
		
	
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPIToken_URL).							
						then().	
						extract()
							.response();
//						response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_UNAUTHORIZED);			
		}
	
	
	//-------------------------- Basic Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteDateLookup_BasicSchemaValidations(){
		String fileName1 = "lfBasic-schema_IRAPIData.json";
		String schemaPath = inputJsonLocation + fileName1;
		
				ValidatableResponse valResp = 
				given()
					.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
				when()			
					.get(siteURL).	
				then().
					assertThat().body(matchesJsonSchema(new File(schemaPath)));	
			}
	
	
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteDateLookup_SchemaValidations(){
	 	 
		
						ValidatableResponse valResp = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL).				
						then().
							assertThat().body(matchesJsonSchema(new File(schemaPath)));	
						
//							body(matchesJsonSchemaInClasspath("JSONIRAPIData_QuoteDateLookUp.json"));

		}

}	
	
	
	
	
	
	
	
