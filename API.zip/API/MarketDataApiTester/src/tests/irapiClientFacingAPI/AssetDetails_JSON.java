package tests.irapiClientFacingAPI;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import org.Data;
import java.io.File;
import java.util.Properties;

public class AssetDetails_JSON extends Data{
	
	String clientApiGCSDataURL = "";
	String siteURL = "";
	String irAPIToken = "";
	String assetID="";
	String invalidAPI_URL="";
	String invalidAPIToken_URL="";
	String proxyAddress="";
	String inputJsonLocation  = "./schemas/irData/";	
	String fileName = "irapi_assets_detail_json_schema.json";
	String schemaPath = inputJsonLocation + fileName;
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		
		Properties globalValues = ReadGlobalFileData();
		clientApiGCSDataURL = globalValues.getProperty("clientapigcsDataURL");
		irAPIToken = globalValues.getProperty("irAPIToken");
		assetID = globalValues.getProperty("assetID");
		proxyAddress=globalValues.getProperty("proxyAddress");
		siteURL=clientApiGCSDataURL + "/"+irAPIToken+"/assets/"+assetID;
		invalidAPI_URL=clientApiGCSDataURL + "/"+irAPIToken+"/assetsInvalid/"+assetID;
		invalidAPIToken_URL=clientApiGCSDataURL + "/"+irAPIToken+"ssdfdsf/assets/"+assetID;
		
		}
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetDetailsLookup_200(){
	 	 
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
//						    .log().all().
						when()			
							.get(siteURL).				
						then().	
						extract()
							.response();
			
						response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}
	
	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetDetailsLookup_404(){
	 	 
		
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPI_URL).				
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
		
	//-------------------------- Unsupported media type-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetDetailsLookup_InvalidAPI_401(){
		
	
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPIToken_URL).							
						then().	
						extract()
							.response();
						
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_UNAUTHORIZED);			
		}
	
	
	//-------------------------- Basic Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetDetailsLookup_BasicSchemaValidations(){
		String fileName1 = "lfBasic-schema_IRAPIData.json";
		String schemaPath = inputJsonLocation + fileName1;
		
				ValidatableResponse valResp = 
				given()
					.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
				when()			
					.get(siteURL).	
				then().
					assertThat().body(matchesJsonSchema(new File(schemaPath)));
			}
	
	
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiAssetDetailsLookup_SchemaValidations(){
	 	 
		
						ValidatableResponse valResp = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL).				
						then().
							 assertThat().body(matchesJsonSchema(new File(schemaPath)));	
//							body(matchesJsonSchemaInClasspath("JSONIRAPIData_AssestDetails.json"));

		}

}	
	
	
	
	
	
	
	
