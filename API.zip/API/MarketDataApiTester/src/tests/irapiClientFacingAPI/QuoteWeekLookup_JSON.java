package tests.irapiClientFacingAPI;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import org.Data;
import java.io.File;
import java.util.Properties;



public class QuoteWeekLookup_JSON extends Data{
	
	String clientApiGCSDataURL = "";
	String siteURL = "";
	String irAPIToken = "";
	String tickerID = "";
	String quotesLookupDate = "";
	String invalidAPIQuotes_URL="";
	String invalidAPIToken_URL="";
	String inputJsonLocation  = "./schemas/irapi/";	
	String fileName = "irapi_historical_quotes_daily_weekly_json_schema.json";
	String schemaPath = inputJsonLocation + fileName;
	String proxyAddress = "";
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		
		Properties globalValues = ReadGlobalFileData();
		clientApiGCSDataURL = globalValues.getProperty("clientapigcsDataURL");
		irAPIToken = globalValues.getProperty("irAPIToken");
		tickerID = globalValues.getProperty("tickerID");
		quotesLookupDate = globalValues.getProperty("quotesLookupDate");
		proxyAddress=globalValues.getProperty("proxyAddress");

		
		siteURL=clientApiGCSDataURL + "/"+irAPIToken+"/quotes/lookup/weekof?date="+quotesLookupDate+"&symbol="+tickerID;
		invalidAPIQuotes_URL=clientApiGCSDataURL + "/"+irAPIToken+"/quoteInvalid/lookup/weekof?date="+quotesLookupDate+"&symbol="+tickerID;
		invalidAPIToken_URL=clientApiGCSDataURL + "/"+irAPIToken+"ssdfdsf/quotes/lookup/weekof?date="+quotesLookupDate+"&symbol="+tickerID;
		
		System.out.println("Quotes week lookup url : "+siteURL);
		
		}
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteWeekLookup_200(){
	 	 
			Response response = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
//						    .log().all().
						when()			
							.get(siteURL).				
						then().	
						extract()
							.response();
			
						response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}
	
	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteWeekLookup_404(){
	 	 
		
			Response response = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPIQuotes_URL).				
						then().	
						extract()
							.response();
//						response.prettyPeek();
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
		
	//-------------------------- Unsupported media type-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteWeekLookup_InvalidAPI_401(){
		
			Response response = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(invalidAPIToken_URL).							
						then().	
						extract()
							.response();
//						response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_UNAUTHORIZED);			
		}
	
	
	//-------------------------- Basic Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteWeekLookup_BasicSchemaValidations(){
		String fileName1 = "lfBasic-schema_IRAPIData.json";
		String schemaPath = inputJsonLocation + fileName1;
		
				ValidatableResponse valResp = 
				given()
				    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
				when()			
					.get(siteURL).	
				then().
					assertThat().body(matchesJsonSchema(new File(schemaPath)));	
			}
	
	
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiQuoteWeekLookup_SchemaValidations(){
	 	 
		
						ValidatableResponse valResp = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL).				
						then().
						assertThat().body(matchesJsonSchema(new File(schemaPath)));	
//							body(matchesJsonSchemaInClasspath("JSONIRAPIData_QuoteDateLookUp.json"));

		}

}	
	
	
	
	
	
	
	
