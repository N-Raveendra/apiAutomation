package tests.irapiClientFacingAPI;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import java.util.Properties;
import org.Data;



public class EventDetails_JSON extends Data {
	
	String siteURL = "";
	String irAPIToken = "";
	String eventsID = "";
	String proxyAddress = "";
	String inputJsonLocation  = "./schemas/irData/";	
	String fileName = "irdata_event_details_json_schema.json";
	String schemaPath = inputJsonLocation + fileName;
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		Properties globalValues = ReadGlobalFileData();
		siteURL = globalValues.getProperty("clientapigcsDataURL");
		irAPIToken = globalValues.getProperty("irAPIToken");
		eventsID = globalValues.getProperty("eventsID");
		proxyAddress=globalValues.getProperty("proxyAddress");
		
		}
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiEventsDetailsJSON_200(){
	 	 
			Response response = 
						given()
						.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
//						    .log().all().
						when()			
							.get(siteURL + "/"+irAPIToken+"/events/"+eventsID).				
						then().	
						extract()
							.response();
			
						response.prettyPeek();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}
	
	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiEventsDetailsJSON_404(){
	 	 
			Response response = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL + "/"+irAPIToken+"/events_invalid/"+eventsID).				
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
		
	//-------------------------- Unsupported media type-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiEventsDetailsJSON_InvalidAPI_404(){
	 	 
			Response response = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL + "/"+irAPIToken+"ssdfdsf/"+eventsID).							
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
	
	//-------------------------- Basic Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiEventsDetailsJSON_BasicSchemaValidations(){
		String fileName1 = "lfBasic-schema_IRAPIData.json";
		String schemaPath = inputJsonLocation + fileName1;
		
				ValidatableResponse valResp = 
				given()
				    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
				when()			
					.get(siteURL + "/"+irAPIToken+"/events/"+eventsID).		
				then().
					assertThat().body(matchesJsonSchema(new File(schemaPath)));	
			}
	
	
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiEventsDetailsJSON_SchemaValidations(){
		
						ValidatableResponse valResp = 
						given()
						    .relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(siteURL + "/"+irAPIToken+"/events/"+eventsID).					
						then().
//							body(matchesJsonSchemaInClasspath("JSONIRAPIData_EventsDetails.json"));
							assertThat().body(matchesJsonSchema(new File(schemaPath)));	

		}

}	
	
	
	
	
	
	
	
