package tests.irapiCMSOrigin;

import org.Data;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import java.util.Properties;

public class newsList_CMSOrigin_JSON extends Data{
	
	String CMSOriginURL = "";
	String irAPIToken = "";
	String invalidAPI_URL="";
	String invalidAPIToken_URL="";
	String proxyAddress="";
	String inputJsonLocation  = "./schemas/irapi/";	
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		
		Properties globalValues = ReadGlobalFileData();
		CMSOriginURL = globalValues.getProperty("CMSOriginURL");
		irAPIToken = globalValues.getProperty("irAPIToken");
		proxyAddress=globalValues.getProperty("proxyAddress");

		
		}
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"irapi", "getOk", "smoke","full"})
	public void irapiNewsListJSON_200(){
	 	 
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(CMSOriginURL + "/v1/content/news?_format=json").				
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}
	
	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"irapi", "notFound", "full"})
	public void irapiNewsListJSON_404(){
	 	 
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
						.get(CMSOriginURL + "/abc/v1/contentnews?_format=json").				
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
		
	//-------------------------- Unsupported media type-----------------------------
	@Test(groups={"irapi", "notFound", "full"})
	public void irapiNewsListJSON_415(){
	 	 
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
						.get(CMSOriginURL + "/v1/content/news").						
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_UNSUPPORTED_MEDIA_TYPE);			
		}
	
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"irapi", "schemaValidationDetailed", "full"})
	public void irapiNewsListJSON_SchemaValidations(){
		String fileName = "JSONIRAPI_NewsListing.json";
		String schemaPath = inputJsonLocation + fileName;
		
		ValidatableResponse valResp = 
		given()
			.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
		when()			
			.get(CMSOriginURL + "/v1/content/news?_format=json").			
		then().
			assertThat().statusCode(HttpStatus.SC_OK).
			assertThat().body(matchesJsonSchema(new File(schemaPath)));
		}
	
	
	
	@Test(groups={"irapi", "getOk", "schemaValidationDetailed", "full"})
	public void irapiNewsListJSON_V2_SchemaValidations(){
		String fileName = "JSONIRAPI_NewsListing_V2.json";
		String schemaPath = inputJsonLocation + fileName;
		
		ValidatableResponse valResp = 
		given()
			.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
		when()			
			.get(CMSOriginURL + "/v2/content/news?_format=json").			
		then().
			assertThat().statusCode(HttpStatus.SC_OK).
			assertThat().body(matchesJsonSchema(new File(schemaPath)));
		}
}	
	
	
	
	
	
	
	
