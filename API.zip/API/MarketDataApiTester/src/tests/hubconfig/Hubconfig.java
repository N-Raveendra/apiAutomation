package tests.hubconfig;

import org.Data;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.sun.org.apache.bcel.internal.util.ClassPath;

import static com.jayway.restassured.RestAssured.given;
import api.ApiRequestType;
import api.RequestFactory;
import api.market.IMarketDataRequest;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.builder.ResponseSpecBuilder;

import static com.jayway.restassured.module.jsv.JsonSchemaValidator.*;


import java.io.File;
import java.util.Properties;

public class Hubconfig extends Data{
	
	String HubConfigURL = "";
	String inputJsonLocation = "./schemas/irapi/";	
	String proxyAddress = "";
	
	
	@BeforeClass(alwaysRun = true)
	public void readGlobalData() {
		
		Properties globalValues = ReadGlobalFileData();

		HubConfigURL=globalValues.getProperty("HubConfigURL");
		proxyAddress=globalValues.getProperty("proxyAddress");

		
		}
	
	//-------------------------- 200 - OK Response validations-----------------------------
	@Test(groups={"hubconfig", "getOk", "smoke","full"})
	public void HubConfig_200(){
	 	 
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).

//						    .relaxedHTTPSValidation().
						when()			
							.get(HubConfigURL + "/hub-config").				
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_OK);	
		}
	
	//-------------------------- 404 - Not Found Response validations-----------------------------
	@Test(groups={"hubconfig", "getOk", "smoke","full"})
	public void HubConfig_404(){
	 	 
			Response response = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
						.get(HubConfigURL + "/hub-config/abc").				
						then().	
						extract()
							.response();
						
						int statusCode = response.getStatusCode();	
						Assert.assertEquals(statusCode, HttpStatus.SC_NOT_FOUND);			
		}
	
	
	
	//-------------------------- 405 - Method Not Allowed validations-----------------------
	@Test(groups={"hubconfig", "getOk", "smoke","full"})
		public void HubConfig_405put(){
		 	 
				Response response = 
							given()
								.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
							when()			
								.put(HubConfigURL + "/hub-config").				
							then().	
							extract()
								.response();
							
							int statusCode = response.getStatusCode();	
							Assert.assertEquals(statusCode, HttpStatus.SC_METHOD_NOT_ALLOWED);			
			}
		
		
	@Test(groups={"hubconfig", "getOk", "smoke","full"})
		public void HubConfig_405post(){
		 	 
				Response response = 
							given()
								.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
							when()			
								.post(HubConfigURL + "/hub-config").				
							then().	
							extract()
								.response();
							
							int statusCode = response.getStatusCode();	
							Assert.assertEquals(statusCode, HttpStatus.SC_METHOD_NOT_ALLOWED);			
			}
		
		
	@Test(groups={"hubconfig", "getOk", "smoke","full"})
		public void HubConfig_405delete(){
		 	 
				Response response = 
							given()
								.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
							when()			
								.delete(HubConfigURL + "/hub-config").				
							then().	
							extract()
								.response();
							
							int statusCode = response.getStatusCode();	
							Assert.assertEquals(statusCode, HttpStatus.SC_METHOD_NOT_ALLOWED);			
			}
	
	
	//-------------------------- Schema validations-----------------------------
	@Test(groups={"hubconfig", "getOk", "smoke","full"})
	public void HubConfig_SchemaValidations(){
		String fileName = "HubConfig-Schema.json";
		String schemaPath = inputJsonLocation + fileName;
		
						ValidatableResponse valResp = 
						given()
							.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
						when()			
							.get(HubConfigURL + "/hub-config").			
						then().
							//body(matchesJsonSchemaInClasspath("HubConfig-Schema.json"));
							assertThat().statusCode(HttpStatus.SC_OK).
							assertThat().body(matchesJsonSchema(new File(schemaPath)));	
						
						System.out.println("Response is ---->"+valResp);
		}
	
	//-------------------------- Basic Schema validations-----------------------------
	@Test(groups={"hubconfig", "getOk", "smoke","full"})
	public void HubConfig_BasicSchemaValidations(){
		String fileName = "lfBasic-schema.json";
		String schemaPath = inputJsonLocation + fileName;
		
				ValidatableResponse valResp = 
				given()
					.relaxedHTTPSValidation().proxy(proxyAddress, 8080).
				when()			
					.get(HubConfigURL + "/hub-config").			
				then().
					//body(matchesJsonSchemaInClasspath("lfBasic-schema.json"));
					assertThat().statusCode(HttpStatus.SC_OK).
					assertThat().body(matchesJsonSchema(new File(schemaPath)));	
		}
}	
	
	
	
	
	
	
	
